package com.bingcoo.rxjava2.group;

/*
    参考：Rxjava2总结 -- https://luhaoaimama1.github.io/2017/07/31/rxjava/
 */

import org.junit.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;

import com.bingcoo.rxjava2.Utils;

public class BlockingObservableOperators {
    @Test
    public void toList_001() {
        Observable.just(1, 2, 3)
                .toList()
                /*
                Waits in a blocking fashion until the current Single signals a success value (which is returned) or
                an exception (which is propagated).
                 */
                .blockingGet()
                .forEach(Utils::log);
    }

    @Test
    public void toSortList_001() {
        Observable.just(5, 2, 3)
                .toSortedList()
                .blockingGet()
                .forEach(Utils::log);
    }

    @Test
    public void toMap_001() {
        Map<String, Integer> map = Observable.just(5, 2, 3)
                //                .toMap(integer -> integer + "_")
                //key 就是5_,value就是5+10   mapSupplier map提供者
                .toMap(integer -> integer + "_"
                        , integer -> integer + 10
                        , HashMap::new)
                .blockingGet();

        Utils.log(map);
    }

    @Test
    public void toFuture_001() {
        /*
        这个操作符将Observable转换为一个返 回单个数据项的 Future 带有返回值的任务
        如果原始Observable发射多个数据项， Future 会收到1个 IllegalArgumentException
        如果原始Observable没有发射任何数据， Future 会收到一 个 NoSuchElementException
        如果你想将发射多个数据项的Observable转换为 Future ,可以这样 用: myObservable.toList().toFuture()
         */
        try {
            Observable.just(1, 2, 3).toList()//转换成Single<List<T>> 这样就变成一个数据了
                    .toFuture()
                    .get()
                    .forEach(Utils::log);
        } catch (Exception e) {

        }
    }

    @Test
    public void blockingSubscribe_001() {
        /*
        Subscribes to the source and calls the given callbacks on the current thread.
         */
        Observable.just(1, 2, 3)
                .blockingSubscribe(System.out::println);
    }

    @Test
    public void blockingForEach_001() {
        /*
        blockingForEach:对BlockingObservable发射的每一项数据调用一个方法，会阻塞直到Observable完成。
         */
        Observable.interval(100, TimeUnit.MILLISECONDS)
                .doOnNext(aLong -> {
                    if (aLong == 10)
                        throw new RuntimeException();
                })
                .onErrorReturnItem(-1L)
                .blockingForEach(Utils::log);
    }

    @Test
    public void blockingIterable_001() {
        /*
        Converts this {Observable} into an {Iterable}.
         */
        Observable.just(1, 2, 3)
                .blockingIterable()
                // .blockingIterable(5);
                .forEach(Utils::log);
    }

    @Test
    public void blockingFirst_001() {
        /*
        Returns the first item emitted by this {Observable}, or a default value if it emits no items.
         */
        Utils.log(
                Observable.empty()
                // .blockingFirst();
                //带默认值版本
                .blockingFirst(-1)
                 );
    }

    @Test
    public void blockLast_001() {
        Utils.log(
            Observable.just(1,2,3)
                    // .blockingLast();
                    //带默认值版本
                    .blockingLast(-1)
                 );
    }

    @Test
    public void blockingMostRecent_001() {
        // blockingMostRecent:返回一个总是返回Observable最近发射的数据的Iterable,类似于while的感觉
        Iterable<Long> c = Observable.interval(3, TimeUnit.MILLISECONDS)
                .doOnNext(aLong -> {
                    if (aLong == 3)
                        throw new RuntimeException();
                }).onErrorReturnItem(-1L)
                .blockingMostRecent(-3L);

        for (Long aLong : c) {
            System.out.println("aLong:" + aLong);
        }
    }

    @Test
    public void blockingSingle_001() {
        /*
        If this {Observable} completes after emitting a single item, return that item, otherwise
        throw a {NoSuchElementException}

        终止时只发射了一个值，返回那个值
        empty 无默认值 报错， 默认值的话显示默认值
        多个值的话 有无默认值都报错
         */
        System.out.println("emit 1 value:" + Observable.just(1).blockingSingle());
        System.out.println("default empty single:" + Observable.empty().blockingSingle(-1));
        System.out.println("default emit 1 value:" + Observable.just(1).blockingSingle(-1));
        try {
            System.out.println("empty single:" + Observable.empty().blockingSingle());
            System.out.println("emit many value:" + Observable.just(1, 2).blockingSingle());
            System.out.println("default emit many value:" + Observable.just(1, 2)
                    .blockingSingle(-1));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
