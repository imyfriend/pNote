package com.bingcoo.rxjava2.group;

/*
    参考：Rxjava2总结 -- https://luhaoaimama1.github.io/2017/07/31/rxjava/
 */

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import io.reactivex.Notification;
import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.BooleanSupplier;
import io.reactivex.schedulers.Timed;

import com.bingcoo.rxjava2.TestObserverEx;
import com.bingcoo.rxjava2.Utils;

public class UtilityOperators {

    @Test
    public void repeat_001() {
        /*
        repeat:不是创建一个Observable,而是重复发射原始Observable的数据序列，这个序列或者是无限的，
        或者通过 repeat(n) 指定重复次数
         */
        Observable.just("Love", "For", "You!")
                .repeat(3)//重复三次
                .subscribe(Utils::log);
    }

    @Test
    public void repeatUntil_001() {
        /*
        repeatUntil:getAsBoolean 如果返回 true则不repeat false则repeat.主要用于动态控制
         */
        Observable.just("Love", "For", "You!")
                .repeatUntil(new BooleanSupplier() {
                    int count;

                    @Override
                    public boolean getAsBoolean() throws Exception {
                        System.out.println("getAsBoolean");
                        count++;
                        if (count == 3)
                            return true;
                        else
                            return false;
                    }
                })
                .subscribe(Utils::log);
    }

    @Test
    public void delay_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        /*
        delay:延迟一段指定的时间再发射来自Observable的发射物
        注意：
        delay 不会平移 onError 通知，它会立即将这个通知传递给订阅者，同时丢弃任何待发射的 onNext 通知。
        然而它会平移一个 onCompleted 通知
         */
        Observable.range(0, 3)
                .delay(1400, TimeUnit.MILLISECONDS)
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void delaySubscription_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        // delaySubscription:让你你可以延迟订阅原始Observable
        Observable.just(1)
                .doOnSubscribe(disposable -> Utils.log("OnSubscribe"))
                .delaySubscription(2000, TimeUnit.MILLISECONDS)
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void doOnEach_001() {
        // doOnEach:注册一个回调，它产生的Observable每发射一项数据就会调用它一次
        Observable.range(0, 3)
                .doOnEach(integerNotification -> Utils.log(integerNotification.getValue()))
                .subscribe();
    }

    /*
    doOnNext:注类似doOnEach 不是接受一个 Notification 参数，而是接受发射的数据项。
    doOnSubscribe:注册一个动作，在观察者订阅时使用
    doOnComplete:注册一个动作，在观察者OnComplete时使用
    doOnError:注册一个动作，在观察者doOnError时使用
     */

    @Test
    public void doOnTerminate_001() {
        // doOnTerminate:注册一个动作，Observable终止之前会被调用，无论是正 常还是异常终止。
        Observable.range(0, 3)
                .doOnTerminate(() -> Utils.log("doOnTerminate"))
                .subscribe();
    }

    @Test
    public void doFinally_001() {
        // doFinally:注册一个动作,当它产生的Observable终止之后会被调用，无论是正常还 是异常终止。在doOnTerminate之后执行
        Observable.range(0, 3)
                .doFinally(() -> Utils.log("doFinally"))
                .doOnTerminate(() -> Utils.log("doOnTerminate"))
                .subscribe();
    }

    @Test
    public void doOnDispose() {
        // doOnDispose:注册一个动作,当【观察者取消】订阅它生成的Observable它就会被调
        Disposable ab = Observable.interval(1, TimeUnit.SECONDS)
                .take(3)
                .doOnDispose(() -> System.out.println("解除订阅"))
                .subscribe(o -> System.out.print("===>" + o + "\t"));
        ab.dispose();
    }

    @Test
    public void materialize_001() {
        // materialize() convert an Observable into a list of Notifications
        TestObserverEx<Notification<Integer>> observer = new TestObserverEx<>();
        Observable.just(1, 2, 3, 4).materialize().subscribe(observer);
    }

    @Test
    public void dematerialize_001() {
        // dematerialize:materialize相反
        Observable.range(0, 3)
                //将Observable转换成一个通知列表。
                .materialize()
                //与上面的作用相反，将通知逆转回一个Observable
                .dematerialize()
                .subscribe(Utils::log);
    }

    /*
    observeOn:指定一个观察者在哪个调度器上观察这个Observable
    subscribeOn:指定Observable自身在哪个调度器上执行
    subscribe:操作来自Observable的发射物和通知
     */

    @Test
    public void forEach_001() {
        /*
        foreach:forEach 方法是简化版的 subscribe ，你同样可以传递一到三个函数给它，解释和传递给 subscribe 时一样
         */
        Observable.range(0, 3)
                .forEach(Utils::log);
    }

    @Test
    public void serialize_001() {
        /*
        一个Observable可以异步调用它的观察者的方法，可能是从不同的线程调用。
        这可能会让Observable行为不正确，它可能会在某一个onNext调用之前尝试调用onCompleted或onError方法，
        或者从两个不同的线程同时调用onNext方法。使用Serialize操作符，你可以纠正这个Observable的行为，
        保证它的行为是正确的且是同步的。
         */
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        Observable.<Integer>create(e -> {
            new Thread() {
                @Override
                public void run() {
                    e.onNext(2);
                    e.onNext(3);
                    Utils.sleep(10, TimeUnit.MILLISECONDS);
                    e.onNext(5);
                }
            }.start();

            e.onNext(1);
            Utils.sleep(300, TimeUnit.MILLISECONDS);
            e.onComplete();
        })
                .serialize()
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void timestamp_001() {
        TestObserverEx<Timed<Long>> observer = new TestObserverEx<>();
        /*
        Timestamp:它将一个发射T类型数据的Observable转换为一个发射类型为Timestamped的数据
        的Observable，每一项都包含数据的原始发射时间
         */
        Observable.interval(100, TimeUnit.MILLISECONDS)
                .take(3)
                .timestamp()
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void timeInterval() {
        TestObserverEx<Timed<Long>> observer = new TestObserverEx<>();
        // timeInterval:一个发射数据的Observable转换为发射那些数据发射时间间隔的Observable
        Observable.interval(100, TimeUnit.MILLISECONDS)
                .take(3)
                //         把发送的数据 转化为  相邻发送数据的时间间隔实体
                .timeInterval()
        //                .timeInterval(Schedulers.newThread())
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void timeout_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        // 变体:过了一个指定的时长仍没有发射数据(不是仅仅考虑第一个)，它会发一个错误
        Observable.interval(100, TimeUnit.MILLISECONDS)
                //        过了一个指定的时长仍没有发射数据(不是仅仅考虑第一个)，它会发一个错误
                .timeout(50, TimeUnit.MILLISECONDS)
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void timeout_002() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        Observable<Long> other;
        // 变体 备用Observable:过了一个指定的时长仍没有发射数据(不是仅仅考虑第一个)，它会发一个错误
        Observable.<Long>empty()
                // 过了一个指定的时长仍没有发射数据(不是仅仅考虑第一个)，他会用备用Observable 发送数据，本身的会发送一个compelte
                .timeout(50, TimeUnit.MILLISECONDS, other = Observable.just(2L, 3L, 4L))
                .subscribe(observer);
        observer.awaitTerminalEvent();

        if (null != other) {
            other.subscribe(Utils::log);
        }
    }

}
