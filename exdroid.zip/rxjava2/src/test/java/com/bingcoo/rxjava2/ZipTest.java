package com.bingcoo.rxjava2;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


public class ZipTest {
    /*
    zip 专用于合并事件，该合并不是连接（连接操作符后面会说），而是两两配对，也就意味着，最终配对出的
     Observable 发射事件数目只和少的那个相同。
    zip 组合事件的过程就是分别从发射器 A 和发射器 B 各取出一个事件来组合，并且一个事件只能被使用一次，
    组合的顺序是严格按照事件发送的顺序来进行的。
     */

    @Test
    public void zip_001() {
        List<String> stringList = Arrays.asList("a", "b", "d");
        Observable.just(1, 2, 3, 4, 5)
                .zipWith(stringList, (Integer value, String str) -> value + str)
                .subscribe(new Observer<String>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(String s) {
                        Utils.log("onNext s=" + s);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Utils.log("onError");
                    }

                    @Override
                    public void onComplete() {
                        Utils.log("onComplete");
                    }
                });
    }


}
