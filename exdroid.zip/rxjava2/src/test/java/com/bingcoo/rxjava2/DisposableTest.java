package com.bingcoo.rxjava2;

import org.junit.Test;

import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableObserver;

/**
 * Created by admin on 2017/12/18.
 */

/*
    Disposable, 这个单词的字面意思是一次性用品,用完即可丢弃的。
    在RxJava中,用它来切断Observer(观察者)与Observable(被观察者)之间的连接，
    当调用它的dispose()方法时, 它就会将Observer(观察者)与Observable(被观察者)之间的连接切断,
    从而导致Observer(观察者)收不到事件, 而被观察者的事件却仍在继续执行。
 */
public class DisposableTest {
    @Test
    public void test_001() {
        Disposable d = sampleObservable()
                //.subscribeOn(Schedulers.io())
                .subscribeWith(new DisposableObserver<String>() {

                    @Override
                    public void onNext(String s) {
                        Utils.log("onNext s=" + s);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Utils.log(e);
                    }

                    @Override
                    public void onComplete() {
                        Utils.log("onComplete");
                    }
                });

        CompositeDisposable disposables = new CompositeDisposable();
        disposables.add(d);
        disposables.clear(); // 将所有的 observer 取消订阅

        Utils.sleep(3000, TimeUnit.MILLISECONDS);
    }

    static Observable<String> sampleObservable() {
        return Observable.defer(new Callable<ObservableSource<? extends String>>() {
            @Override
            public ObservableSource<? extends String> call() throws Exception {
                // Do some long running operation
                //SystemClock.sleep(2000);
                //Utils.sleep(2000, TimeUnit.MILLISECONDS);
                return Observable.just("one", "two", "three", "four", "five");
            }
        });
    }

}
