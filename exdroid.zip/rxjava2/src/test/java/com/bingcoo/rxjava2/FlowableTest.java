package com.bingcoo.rxjava2;

import org.junit.Test;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import java.util.concurrent.TimeUnit;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subscribers.TestSubscriber;

/**
 * Created by admin on 2017/12/18.
 */

/*
    什么情况下才会产生Backpressure问题？
    1.如果生产者和消费者在一个线程的情况下，无论生产者的生产速度有多快，每生产一个事件都会通知消费者，
    等待消费者消费完毕，再生产下一个事件。所以在这种情况下，根本不存在Backpressure问题。即同步情况下，
    Backpressure问题不存在。
    2.如果生产者和消费者不在同一线程的情况下，如果生产者的速度大于消费者的速度，就会产生Backpressure问题。
    即异步情况下，Backpressure问题才会存在。
 */
public class FlowableTest {

    /*
    数据流发射，处理，响应可能在各自的线程中独立进行，上游在发射数据的时候，不知道下游是否处理完，
    也不会等下游处理完之后再发射。这样，如果上游发射的很快而下游处理的很慢，会怎样呢？
    将会产生很多下游没来得及处理的数据，这些数据既不会丢失，也不会被垃圾回收机制回收，而是存放在一个
    异步缓存池中，如果缓存池中的数据一直得不到处理，越积越多，最后就会造成内存溢出，这便是Rxjava中的背压问题。

    在Flowable的基础创建方法create中多了一个BackpressureStrategy类型的参数，BackpressureStrategy是个枚举，
    源码如下：
    public enum BackpressureStrategy {
       ERROR,BUFFER,DROP,LATEST,MISSING
    }
    其作用是什么呢？
    Flowable的异步缓存池不同于Observable，Observable的异步缓存池没有大小限制，可以无限制向里添加数据，直至OOM,
    而Flowable的异步缓存池有个固定容量，其大小为128。
    BackpressureStrategy的作用便是用来设置Flowable通过异步缓存池存储数据的策略。
    在异步调用时，RxJava中有个缓存池，用来缓存消费者处理不了暂时缓存下来的数据，缓存池的默认大小为128，
    即只能缓存128个事件。无论request()中传入的数字比128大或小，缓存池中在刚开始都会存入128个事件。
    当然如果本身并没有这么多事件需要发送，则不会存128个事件。
     */
    @Test
    public void error_001() {
        Flowable<Integer> flowable = Flowable.create(new FlowableOnSubscribe<Integer>() {
            @Override
            public void subscribe(FlowableEmitter<Integer> emitter) throws Exception {
                Utils.log("emit 1");
                emitter.onNext(1);
                Utils.log("emit 2");
                emitter.onNext(2);
                Utils.log("emit 3");
                emitter.onNext(3);
                Utils.log("emit complete");
                emitter.onComplete();
            }
        }, BackpressureStrategy.ERROR); //增加了一个参数.在ERROR策略下，如果缓存池溢出，就会立刻抛出MissingBackpressureException异常。

        TestSubscriber<Integer> subscriber = new TestSubscriber<Integer>() {
            @Override
            public void onSubscribe(Subscription s) {
                super.onSubscribe(s);
                Utils.log("onSubscribe");
                /*
                Flowable在设计的时候采用了一种新的思路也就是响应式拉取的方式,你要求多少，我便传给你多少.
                Subscription也可以用于切断观察者与被观察者之间的联系，调用Subscription.cancel()方法便可。
                 */
                s.request(Long.MAX_VALUE);
            }
            @Override
            public void onNext(Integer integer) {
                super.onNext(integer);
                Utils.log("onNext: " + integer);

            }
            @Override
            public void onError(Throwable t) {
                super.onError(t);
                Utils.log("onError: t=" + t);
            }
            @Override
            public void onComplete() {
                super.onComplete();
                Utils.log("onComplete");
            }
        };

        flowable.observeOn(Schedulers.computation()).subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertComplete();
    }

    @Test
    public void error_002() {
        Subscriber<Integer> testSubscriber = new Subscriber<Integer>() {
            @Override
            public void onSubscribe(Subscription s) {

            }

            @Override
            public void onNext(Integer integer) {
                Utils.log("onNext: " + integer);
            }
            @Override
            public void onError(Throwable t) {
                Utils.log("onError: t" + t);
            }

            @Override
            public void onComplete() {
                Utils.log("onComplete");
            }
        };

        Flowable.create(new FlowableOnSubscribe<Integer>() {
            @Override
            public void subscribe(FlowableEmitter<Integer> emitter) throws Exception {
                for (int i = 0; i < 129; i++) {
                    Utils.log("emit " + i);
                    emitter.onNext(i);
                }
                emitter.onComplete();
            }
        }, BackpressureStrategy.ERROR)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.computation())
                .subscribe(testSubscriber);

        //testSubscriber.awaitTerminalEvent();
        //testSubscriber.assertError(MissingBackpressureException.class);
        Utils.sleep(1, TimeUnit.SECONDS);
    }

    /*
    BUFFER
    所谓BUFFER就是把RxJava中默认的只能存128个事件的缓存池换成一个大的缓存池，支持存很多很多的数据。
这样，消费者通过request()即使传入一个很大的数字，生产者也会生产事件，并将处理不了的事件缓存。
但是这种方式任然比较消耗内存，除非是我们比较了解消费者的消费能力，能够把握具体情况，不会产生OOM。
总之BUFFER要慎用。
     */

    /*
    DROP
看名字就可以了解其作用：当消费者处理不了事件，就丢弃。
消费者通过request()传入其需求n，然后生产者把n个事件传递给消费者供其消费。其他消费不掉的事件就丢掉。
注意：并不是Subscriber接收一条，便清理一条，而是每累积到一定程度（95条）清理一次。
     */
    @Test
    public void drop_001() {
        Flowable<Integer> flowable = Flowable.create(new FlowableOnSubscribe<Integer>() {
            @Override
            public void subscribe(FlowableEmitter<Integer> emitter) throws Exception {
                for (int i = 0; i<500; i++) {
                    try {
                        Thread.sleep(100);
                    } catch (Exception e) {

                    }
                    Utils.log("发送 i=" + i);
                    emitter.onNext(i);
                }
                emitter.onComplete();
            }
        }, BackpressureStrategy.DROP);

        class TestSubscriber implements Subscriber<Integer> {
            Subscription mSubscription;

            public Subscription getSubscription() {
                return mSubscription;
            }

            @Override
            public void onSubscribe(Subscription s) {
                mSubscription = s;
                s.request(50);
                Utils.log("onSubscribe");
            }

            @Override
            public void onNext(Integer integer) {
                try {
                    Thread.sleep(300);
                } catch (Exception e) {

                }
                Utils.log("接受 onNext: " + integer);
            }

            @Override
            public void onError(Throwable t) {
                Utils.log("onError: t=" + t);
            }

            @Override
            public void onComplete() {
                Utils.log("onComplete");
            }
        }

        TestSubscriber subscriber = new TestSubscriber();
        flowable.subscribeOn(Schedulers.io()).observeOn(Schedulers.newThread()).subscribe(subscriber);

        subscriber.getSubscription().request(50);
        subscriber.getSubscription().request(50);

        Utils.sleep(1, TimeUnit.MINUTES);
    }

    @Test
    public void drop_002() {
        Flowable<Integer> flowable = Flowable.create(new FlowableOnSubscribe<Integer>() {
            @Override
            public void subscribe(FlowableEmitter<Integer> emitter) throws Exception {
                for (int i = 0; i<500; i++) {
                    try {
                        Thread.sleep(100);
                    } catch (Exception e) {

                    }
                    Utils.log("发送 i=" + i);
                    emitter.onNext(i);
                }
                emitter.onComplete();
                Utils.log("发送完成");
            }
        }, BackpressureStrategy.DROP);

        TestSubscriber<Integer> subscriber = new TestSubscriber<Integer>(0) {
            private Integer mCnt = 0;

            @Override
            public void onSubscribe(Subscription s) {
                super.onSubscribe(s);
                Utils.log("onSubscribe");
                /*
                Flowable在设计的时候采用了一种新的思路也就是响应式拉取的方式,你要求多少，我便传给你多少.
                Subscription也可以用于切断观察者与被观察者之间的联系，调用Subscription.cancel()方法便可。
                 */
                s.request(10);
            }

            @Override
            public void onNext(Integer integer) {
                super.onNext(integer);
                try {
                    Thread.sleep(300);
                } catch (Exception e) {

                }
                mCnt++;
                Utils.log("onNext: " + integer + ", cnt=" + mCnt);
            }

            @Override
            public void onError(Throwable t) {
                super.onError(t);
                Utils.log("onError: t=" + t);
            }

            @Override
            public void onComplete() {
                super.onComplete();
                Utils.log("onComplete");
            }
        };

        flowable.subscribeOn(Schedulers.io()).observeOn(Schedulers.newThread()).subscribe(subscriber);

        try {
            Thread.sleep(129*100);
        } catch (Exception e) {

        }
        subscriber.request(50);

        try {
            subscriber.await(1, TimeUnit.MINUTES);
        } catch (Exception e) {

        }
        subscriber.assertSubscribed();
        subscriber.assertNotComplete();
        subscriber.assertTimeout();
    }

    @Test
    public void drop_003() {
        Flowable<Integer> flowable = Flowable.create(new FlowableOnSubscribe<Integer>() {
            @Override
            public void subscribe(FlowableEmitter<Integer> emitter) throws Exception {
                int i = 0;
                do {
                    /*
                    通过requested()获取到的值，并不是下游真正的数据请求数量，而是异步缓存池中可放入数据的数量。
                     */
                    if (0 == emitter.requested()) {
                        Utils.log("0 = emitter.requested() !! ");
                        try {
                            Thread.sleep(129*100);
                        } catch (Exception e) {

                        }
                        continue;
                    }

                    Utils.log("发送 i=" + i);
                    emitter.onNext(i);
                    i++;
                } while (i<500);

                emitter.onComplete();
                Utils.log("发送完成");
            }
        }, BackpressureStrategy.DROP);

        TestSubscriber<Integer> subscriber = new TestSubscriber<Integer>(0) {
            private Integer mCnt = 0;

            @Override
            public void onSubscribe(Subscription s) {
                super.onSubscribe(s);
                Utils.log("onSubscribe");
                /*
                Flowable在设计的时候采用了一种新的思路也就是响应式拉取的方式,你要求多少，我便传给你多少.
                Subscription也可以用于切断观察者与被观察者之间的联系，调用Subscription.cancel()方法便可。
                 */
                s.request(10);
            }

            @Override
            public void onNext(Integer integer) {
                super.onNext(integer);
                try {
                    Thread.sleep(300);
                } catch (Exception e) {

                }
                mCnt++;
                Utils.log("onNext: " + integer + ", cnt=" + mCnt);
            }

            @Override
            public void onError(Throwable t) {
                super.onError(t);
                Utils.log("onError: t=" + t);
            }

            @Override
            public void onComplete() {
                super.onComplete();
                Utils.log("onComplete");
            }
        };

        flowable.subscribeOn(Schedulers.io()).observeOn(Schedulers.newThread()).subscribe(subscriber);

        for (int i=0; i<3; i++ ) {
            try {
                Thread.sleep(129 * 100);
            } catch (Exception e) {

            }
            subscriber.request(50);
            Utils.log("after wait, request another 50 !!");
        }
        subscriber.request(Long.MAX_VALUE);

        subscriber.awaitTerminalEvent();
        subscriber.assertComplete();
    }

    /*
    LATEST
LATEST与DROP功能基本一致。
消费者通过request()传入其需求n，然后生产者把n个事件传递给消费者供其消费。其他消费不掉的事件就丢掉。
唯一的区别就是LATEST总能使消费者能够接收到生产者产生的最后一个事件。
还是以上述例子展示，唯一的区别就是Flowable不再无限发事件，只发送1000000个。
     */

    /*
    MISSING
    此策略表示，通过Create方法创建的Flowable没有指定背压策略，不会对通过OnNext发射的数据做缓存或丢弃处理，
    需要下游通过背压操作符（onBackpressureBuffer()/onBackpressureDrop()/onBackpressureLatest()）指定背压策略。

    onBackpressureXXX背压操作符
    Flowable除了通过create创建的时候指定背压策略，也可以在通过其它创建操作符just，fromArray等创建后通过背压操作符指定背压策略。
    onBackpressureBuffer()对应BackpressureStrategy.BUFFER
    onBackpressureDrop()对应BackpressureStrategy.DROP
    onBackpressureLatest()对应BackpressureStrategy.LATEST


    如果Flowable对象不是自己创建的，可以采用onBackpressureBuffer()、onBackpressureDrop()、onBackpressureLatest()的方式指定。
     */
    @Test
    public void onBackpressureBuffer() {
        Flowable.just(1).onBackpressureBuffer()
                .observeOn(Schedulers.newThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new Consumer<Integer>() {
                    @Override
                    public void accept(Integer integer) throws Exception {
                        Utils.log("accept integer=" + integer);
                    }
                });

        Utils.sleep(1, TimeUnit.SECONDS);
    }

    /*
    Scheduler种类

    Schedulers.io( )：
    用于IO密集型的操作，例如读写SD卡文件，查询数据库，访问网络等，具有线程缓存机制，在此调度器接收到任务后，先检查线程缓存池中，是否有空闲的线程，如果有，则复用，如果没有则创建新的线程，并加入到线程池中，如果每次都没有空闲线程使用，可以无上限的创建新线程。

    Schedulers.newThread( )：
    在每执行一个任务时创建一个新的线程，不具有线程缓存机制，因为创建一个新的线程比复用一个线程更耗时耗力，虽然使用Schedulers.io( )的地方，都可以使用Schedulers.newThread( )，但是，Schedulers.newThread( )的效率没有Schedulers.io( )高。

    Schedulers.computation()：
    用于CPU 密集型计算任务，即不会被 I/O 等操作限制性能的耗时操作，例如xml,json文件的解析，Bitmap图片的压缩取样等，具有固定的线程池，大小为CPU的核数。不可以用于I/O操作，因为I/O操作的等待时间会浪费CPU。

    Schedulers.trampoline()：
    在当前线程立即执行任务，如果当前线程有任务在执行，则会将其暂停，等插入进来的任务执行完之后，再将未完成的任务接着执行。

    Schedulers.single()：
    拥有一个线程单例，所有的任务都在这一个线程中执行，当此线程中有任务执行时，其他任务将会按照先进先出的顺序依次执行。

    Scheduler.from(@NonNull Executor executor)：
    指定一个线程调度器，由此调度器来控制任务的执行策略。

    AndroidSchedulers.mainThread()：
    在Android UI线程中执行任务，为Android开发定制。

--------------------------------------
    Flowable是为了解决背压（backpressure）问题，而在Observable的基础上优化后的产物，与Observable不是同一组
    观察者模式下的成员，Flowable是Publisher与Subscriber这一组观察者模式中Publisher的典型实现，Observable是
    ObservableSource/Observer这一组观察者模式中ObservableSource的典型实现；
    所以在使用Flowable的时候，可观察对象不再是Observable,而是Flowable;观察者不再是Observer，而是Subscriber。
    Flowable与Subscriber之间依然通过subscribe()进行关联。
    有些朋友可能会想，既然Flowable是在Observable的基础上优化后的产物，Observable能解决的问题Flowable都能进行
    解决，何不抛弃Observable而只用Flowable呢。其实，这是万万不可的，他们各有自己的优势和不足。
    由于基于Flowable发射的数据流，以及对数据加工处理的各操作符都添加了背压支持，附加了额外的逻辑，其运行效率要
    比Observable低得多。
    因为只有上下游运行在各自的线程中，且上游发射数据速度大于下游接收处理数据的速度时，才会产生背压问题。
    所以，如果能够确定上下游在同一个线程中工作，或者上下游工作在不同的线程中，而下游处理数据的速度高于上游发射
    数据的速度，则不会产生背压问题，就没有必要使用Flowable，以免影响性能。

作者：冯丰枫
链接：https://www.jianshu.com/p/12638513424f
     */



}
