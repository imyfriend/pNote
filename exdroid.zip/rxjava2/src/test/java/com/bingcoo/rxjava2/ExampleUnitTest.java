package com.bingcoo.rxjava2;

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.UnicastSubject;

import static org.junit.Assert.assertEquals;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }

    @Test
    public void test_001() {
        Observable<String> observable = Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(ObservableEmitter<String> e) throws Exception {
                try {
                    if (!e.isDisposed()) {
                        e.onNext("begin");
                        e.onComplete();
                    }
                } catch (Exception ep) {
                    if (!e.isDisposed()) {
                        e.onError(ep);
                    }
                }
            }
        });

        Observer<String> observer = new Observer<String>() {

            @Override
            public void onSubscribe(Disposable d) {
                System.out.println("onSubscribe");
            }

            @Override
            public void onNext(String s) {
                System.out.println("onNext 我接收到数据了");
            }

            @Override
            public void onError(Throwable e) {
                System.out.println("onError");
            }

            @Override
            public void onComplete() {
                System.out.println("onComplete");
            }
        };

        observable.subscribe(observer);
    }

    @Test
    public void consumer_001() {
        Observable.just("hello").subscribe(new Consumer<String>() {
            @Override
            public void accept(String s) throws Exception {
                System.out.println(s);
            }
        });

    }

    @Test
    public void toFuture_001() {
        try {
            Observable.just(1, 2, 3)
                    .observeOn(Schedulers.computation())
                    .toList()//转换成Single<List<T>> 这样就变成一个数据了
                    .toFuture()
                    .get()
                    .forEach(integer -> System.out.println(integer));
        } catch (Exception e) {
            Utils.log("toFuture e=" + e);
        }
    }

    @Test
    public void toFuture_002() {
        try {
            Integer v = Observable.just(1).delay(100, TimeUnit.MICROSECONDS).toFuture().get();
            Utils.log("v=" + v);
        } catch (Exception e) {

        }
    }

    @Test
    public void unicastSubject_001() {
        UnicastSubject<Integer> subject = UnicastSubject.create();

        Observable.just(1).subscribe(subject);
        try {
            Integer v = subject.toFuture().get();
            Utils.log("v=" + v);
        } catch (Exception e) {

        }
    }


}