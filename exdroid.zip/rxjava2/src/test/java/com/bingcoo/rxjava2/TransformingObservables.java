package com.bingcoo.rxjava2;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Emitter;
import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by admin on 2017/12/18.
 */

public class TransformingObservables {

    @Test
    public void map() {
        Observable<Integer> observable = Observable.just("hello").map(new Function<String, Integer>() {
            @Override
            public Integer apply(String s) throws Exception {
                return s.length();
            }
        });
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        observable.subscribe(observer);
        observer.assertComplete();
    }

    @Test
    public void flatMap_001() {
        List<String> list = new ArrayList<>();
        for(int i=0; i<10; i++){
            list.add("Hello"+i);
        }
        Observable<Object> observable = Observable.just(list).flatMap(new Function<List<String>, ObservableSource<?>>() {
            @Override
            public ObservableSource<?> apply(List<String> strings) throws Exception {
                return Observable.fromIterable(strings);
            }
        });

        TestObserverEx<Object> observer = new TestObserverEx<>();
        observable.subscribe(observer);
        observer.assertComplete();
    }

    @Test
    public void flatMap_002() {
        TestObserverEx<Object> observer = new TestObserverEx<>();

        // flatMap()则是在onNext()被调用后执行，onNext()的每一次调用都会触发flatMap()，也就是说，flatMap()转换的是每一个事件
        Observable.create(source -> source.onComplete()).flatMap(new Function<Object, ObservableSource<?>>() {
            @Override
            public ObservableSource<?> apply(Object o) throws Exception {
                Utils.log("flatMap apply");
                return Observable.just(o);
            }
        })
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void compose() {
        TestObserverEx<Object> observer = new TestObserverEx<>();

        // compose()是唯一一个能够从数据流中得到原始Observable<T>的操作符,转换的是整个数据流
        Observable.create(Emitter::onComplete)
                .compose(upstream -> {
                    Utils.log("compose");
                    return upstream.subscribeOn(Schedulers.io());
                })
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }


}
