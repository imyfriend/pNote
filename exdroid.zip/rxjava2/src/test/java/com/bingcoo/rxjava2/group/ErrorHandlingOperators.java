package com.bingcoo.rxjava2.group;

/*
    参考：Rxjava2总结 -- https://luhaoaimama1.github.io/2017/07/31/rxjava/
 */

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.functions.Function;

import com.bingcoo.rxjava2.TestObserverEx;
import com.bingcoo.rxjava2.Utils;

public class ErrorHandlingOperators {
    @Test
    public void onErrorReturnItem_001() {
        /*
        onErrorReturn:让Observable遇到错误时发射一个特殊的项并且正常终止
         */
        Observable.error(new Throwable("我擦 空啊"))
                .onErrorReturnItem("hei")
                .subscribe(o -> System.out.println("===>" + o + "\t")
                        , throwable -> System.out.println("===>throwable")
                        , () -> System.out.println("===>complete"));
    }

    @Test
    public void onErrorReturn_001() {
        Observable.error(new Throwable("我擦 空啊"))
                .onErrorReturn(throwable -> {
                    System.out.println("错误信息：" + throwable.getMessage());
                    return throwable;
                })
                .subscribe(o -> System.out.println("===>" + o + "\t")
                        , throwable -> System.out.println("===>throwable")
                        , () -> System.out.println("===>complete"));
    }

    @Test
    public void onErrorReturn_002() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        Observable.<Integer>create(e -> {
            e.onNext(1);
            e.onNext(2);
            e.onError(new Throwable("Error!!"));
            e.onNext(3);
            e.onComplete();
        }).onErrorReturn(throwable -> {
            Utils.log(throwable);
            return 22;
        }).subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void onErrorResumeNext_001() {
        /*
        onErrorResumeNext:让Observable在遇到错误时开始发射第二个Observable的数据序列
         */
        Observable.error(new Throwable("我擦 空啊"))
                .onErrorResumeNext(throwable -> {
                    System.out.println("错误信息：" + throwable.getMessage());
                    return Observable.range(0, 3);
                })
                .subscribe(o -> System.out.print("===>" + o + "\t")
                        , throwable -> System.out.print("===>throwable"+ "\t")
                        , () -> System.out.print("===>complete"+ "\t"));
    }

    @Test
    public void onExceptionResumeNext_001() {
        /*
        onExceptionResumeNext:只能处理异常。
        Throwable 不是一个Exception ,它会将错误传递给观察者的onError方法，不会使用备用的Observable。
         */
        Observable.error(new Throwable("我擦 空啊"))
                .onExceptionResumeNext(observer -> Observable.range(0, 3))
                .subscribe(o -> System.out.println("===>" + o + "\t")
                        , throwable -> System.out.println("===>throwable")
                        , () -> System.out.println("===>complete"));
    }

    @Test
    public void retry_001() {
        /*
        retry:如果原始Observable遇到错误，重新订阅它期望它能正常终止
        变体count 重复次数
         */
        Observable.create(e -> {
            e.onNext(1);
            e.onNext(2);
            e.onError(new Throwable("hehe"));
        })
                .retry(2)
                .subscribe(o -> System.out.print("===>" + o + "\t")
                        , throwable -> System.out.print("===>throwable\t")
                        , () -> System.out.print("===>complete\t"));
    }

    @Test
    public void retry_002() {
        /*
        变体Predicate 条件判定 如果返回 true retry,false 放弃 retry
         */
        Observable.create(e -> {
            e.onNext(1);
            e.onNext(2);
            e.onError(new Throwable("hehe"));
        })
                .retry(throwable -> throwable.getMessage().equals("hehe1"))
                .subscribe(o -> System.out.print("===>" + o + "\t")
                        , throwable -> System.out.print("===>throwable\t")
                        , () -> System.out.print("===>complete\t"));
    }

    @Test
    public void retryWhen_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        /*
        retryWhen: 需要一个Observable 通过判断 throwableObservable,Observable发射一个数据 就重新订阅，
        发射的是 onError 通知，它就将这个通知传递给观察者然后终止。
         */
        Observable.just(1, "2", 3)
                .cast(Integer.class)
                // 结果：1,1,complete 原因这个Observable发了一次数据
                //.retryWhen(throwableObservable -> Observable.timer(1, TimeUnit.SECONDS))
                // 结果：1,1,1,1,complete 原因这个Observable发了三次数据
                .retryWhen(throwableObservable ->
                                   Observable.interval(1, TimeUnit.SECONDS).take(3))
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void retryWhen_002() {
        /*
        利用RxJava来实现出现错误后重试若干次，并且可以设定重试的时间间隔。
        https://blog.csdn.net/jdsjlzx/article/details/51722365
        https://www.jianshu.com/p/d42793eba591
         */
        class RetryWithDelay implements Function<Observable<? extends Throwable>, Observable<?>> {

            private final int maxRetries;
            private final int retryDelayMillis;
            private int retryCount;

            public RetryWithDelay(int maxRetries, int retryDelayMillis) {
                this.maxRetries = maxRetries;
                this.retryDelayMillis = retryDelayMillis;
            }

            @Override
            public Observable<?> apply(Observable<? extends Throwable> attempts) {
                return attempts
                        .flatMap(new Function<Throwable, Observable<?>>() {
                            @Override
                            public Observable<?> apply(Throwable throwable) {
                                if (++retryCount <= maxRetries) {
                                    // When this Observable calls onNext, the original Observable will be retried (i.e. re-subscribed).
                                    Utils.log("get error, it will try after " + retryDelayMillis
                                            + " millisecond, retry count " + retryCount);
                                    return Observable.timer(retryDelayMillis,
                                                            TimeUnit.MILLISECONDS);
                                }
                                // Max retries hit. Just pass the error along.
                                return Observable.error(throwable);
                            }
                        });
            }
        }

        TestObserverEx<Integer> observer = new TestObserverEx<>();
        Observable.<Integer>create(e -> {
            e.onNext(1);
            e.onError(new Throwable("hehe"));
        })
                .retryWhen(new RetryWithDelay(3, 3000))
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }


}
