package com.bingcoo.rxjava2;

import org.junit.Test;

import io.reactivex.Completable;
import io.reactivex.CompletableEmitter;
import io.reactivex.CompletableObserver;
import io.reactivex.CompletableOnSubscribe;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import io.reactivex.MaybeEmitter;
import io.reactivex.MaybeObserver;
import io.reactivex.MaybeOnSubscribe;
import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.BiFunction;

public class SingleTest {
    /*
作者：冯丰枫
链接：https://www.jianshu.com/p/66a55abbadef
     */

    /*
    Single
    只发射一条单一的数据，或者一条异常通知，不能发射完成通知，其中数据与通知只能发射一个。

    可观察对象Single的发射器接口SingleEmitter中，
    1、方法void onSuccess(T t)用来发射一条单一的数据，且一次订阅只能调用一次，不同于Observale的发射器
        ObservableEmitter中的void onNext(@NonNull T value)方法，在一次订阅中，可以多次调用多次发射。
    2、方法void onError(Throwable t)等同于ObservableEmitter中的void onError(@NonNull Throwable error)
        用来发射一条错误通知
    3、SingleEmitter中没有用来发射完成通知的void onComplete()方法。
    方法onSuccess与onError只可调用一个，若先调用onError则会导致onSuccess无效，若先调用onSuccess,则会抛
    出io.reactivex.exceptions.UndeliverableException异常。

    可观察对象Single对应的观察者为SingleObserver
    1、方法void onSubscribe(Disposable d)等同于Observer中的void onSubscribe(Disposable d)。
    2、方法void onSuccess(T t)类似于Observer中的onNext(T t)用来接收Single发的数据。
    3、方法void onError(Throwable e)等同于Observer中的void onError(Throwable e)用来处理异常通知。
    没有用来处理完成通知的方法void onComplete()
     */
    @Test
    public void single_data() {
        /*
        Single.create(new SingleOnSubscribe<String>() {
            @Override
            public void subscribe(SingleEmitter<String> e) throws Exception {

            }
        });
        */

        Single.<String>create(e -> e.onSuccess("data"))
                .subscribe(new SingleObserver<String>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        Utils.log("onSubscribe");
                    }

                    @Override
                    public void onSuccess(String s) {
                        Utils.log("onSuccess s=" + s);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Utils.log("onError e=" + e);
                    }
                });
    }

    @Test
    public void single_error() {
        Single.<String>create(e -> e.onError(new Exception("test Exception")))
                .subscribe(new SingleObserver<String>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        Utils.log("onSubscribe");
                    }

                    @Override
                    public void onSuccess(String s) {
                        Utils.log("onSuccess s=" + s);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Utils.log("onError e=" + e);
                    }
                });
    }

    @Test
    public void single_reduce() {
        SingleObserver<Integer> singleObserver = new SingleObserver<Integer>() {

            @Override
            public void onSubscribe(Disposable d) {
                Utils.log("onSubscribe d.isDisposed=" + d.isDisposed());
            }

            @Override
            public void onSuccess(Integer integer) {
                Utils.log("onSuccess integer=" + integer);
            }

            @Override
            public void onError(Throwable e) {
                Utils.log(e);
            }
        };

        Flowable.just(1, 2, 3, 4).reduce(50, new BiFunction<Integer, Integer, Integer>() {
            @Override
            public Integer apply(Integer t1, Integer t2) {
                return t1 + t2;
            }
        }).subscribe(singleObserver);
    }

    /*
     Completable
    只发射一条完成通知，或者一条异常通知，不能发射数据，其中完成通知与异常通知只能发射一个

    可观察对象Completable的发射器接口CompletableEmitter中
    1、方法onComplete()等同于Observable的发射器ObservableEmitter中的onComplete()，用来发射完成通知。
    2、方法onError(Throwable e)等同于ObservableEmitter中的onError(Throwable e)，用来发射异常通知。
    方法onComplete与onError只可调用一个，若先调用onError则会导致onComplete无效，若先调用onComplete,则会抛出
    io.reactivex.exceptions.UndeliverableException异常。

    可观察对象Completable对应的观察者为CompletableObserver
    其中的三个方法均等同于Observer中的对应的方法，CompletableObserver中没有用来发射数据的方法。
     */
    @Test
    public void completable_success() {
        Completable.create(new CompletableOnSubscribe() {
            @Override
            public void subscribe(CompletableEmitter e) throws Exception {
                e.onComplete();
            }
        }).subscribe(new CompletableObserver() {
            @Override
            public void onSubscribe(Disposable d) {
                Utils.log("onSubscribe");
            }

            @Override
            public void onComplete() {
                Utils.log("onComplete");
            }

            @Override
            public void onError(Throwable e) {
                Utils.log("onError e=" + e);
            }
        });
    }

    @Test
    public void completable_error() {
        Completable.create(new CompletableOnSubscribe() {
            @Override
            public void subscribe(CompletableEmitter e) throws Exception {
                e.onError(new Exception("Test Error"));
            }
        }).subscribe(new CompletableObserver() {
            @Override
            public void onSubscribe(Disposable d) {
                Utils.log("onSubscribe");
            }

            @Override
            public void onComplete() {
                Utils.log("onComplete");
            }

            @Override
            public void onError(Throwable e) {
                Utils.log("onError e=" + e);
            }
        });
    }

    /*
     Maybe
    可发射一条单一的数据，或者发射一条完成通知，或者一条异常通知。

    可观察对象Maybe的发射器接口MaybeEmitter中
    1、方法void onSuccess(T t)用来发射一条单一的数据，且一次订阅只能调用一次，不同于Observable的发射器
        ObservableEmitter中的void onNext(@NonNull T value)方法，在一次订阅中，可以多次调用多次发射。
    2、方法void onError(Throwable t)等同于ObservableEmitter中的void onError(@NonNull Throwable error);用
        来发射一条错误通知
    3、方法onComplete()等同于Observable的发射器ObservableEmitter中的onComplete()，用来发射完成通知。
    方法onComplete与onError只可调用一个，若先调用onError则会导致onComplete无效，若先调用onComplete,则会抛出
    io.reactivex.exceptions.UndeliverableException异常。

    可观察对象Maybe对应的观察者为MaybeObserver
    1、方法void onSubscribe(Disposable d)等同于Observer中的void onSubscribe(Disposable d)。
    2、方法void onSuccess(T t)类似于Observer中的onNext(T t)用来接收Single发的数据。
    3、方法void onError(Throwable e)等同于Observer中的void onError(Throwable e)用来处理异常通知。
    4、方法void onComplete()等同于Observer中的void onComplete()用来接收完成通知。
     */
    @Test
    public void maybe_data() {
        Maybe.create(new MaybeOnSubscribe<String>() {
            @Override
            public void subscribe(MaybeEmitter<String> e) throws Exception {
                e.onSuccess("data");
            }
        }).subscribe(new MaybeObserver<String>() {
            @Override
            public void onSubscribe(Disposable d) {
                Utils.log("onSubscribe");
            }

            @Override
            public void onSuccess(String s) {
                Utils.log("onSuccess s=" + s);
            }

            @Override
            public void onError(Throwable e) {
                Utils.log("onError");
            }

            @Override
            public void onComplete() {
                Utils.log("onComplete");
            }
        });
    }

    @Test
    public void maybe_success() {
        Maybe.create(new MaybeOnSubscribe<String>() {
            @Override
            public void subscribe(MaybeEmitter<String> e) throws Exception {
                e.onComplete();
            }
        }).subscribe(new MaybeObserver<String>() {
            @Override
            public void onSubscribe(Disposable d) {
                Utils.log("onSubscribe");
            }

            @Override
            public void onSuccess(String s) {
                Utils.log("onSuccess s=" + s);
            }

            @Override
            public void onError(Throwable e) {
                Utils.log("onError");
            }

            @Override
            public void onComplete() {
                Utils.log("onComplete");
            }
        });
    }

    @Test
    public void maybe_error() {
        Maybe.create(new MaybeOnSubscribe<String>() {
            @Override
            public void subscribe(MaybeEmitter<String> e) throws Exception {
                e.onError(new Exception("Test Error"));
            }
        }).subscribe(new MaybeObserver<String>() {
            @Override
            public void onSubscribe(Disposable d) {
                Utils.log("onSubscribe");
            }

            @Override
            public void onSuccess(String s) {
                Utils.log("onSuccess s=" + s);
            }

            @Override
            public void onError(Throwable e) {
                Utils.log("onError e=" + e);
            }

            @Override
            public void onComplete() {
                Utils.log("onComplete");
            }
        });
    }

}
