package com.bingcoo.rxjava2;

import org.junit.Test;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.schedulers.Schedulers;

public class SchedulersTest {

    /*
    subscribeOn通过接收一个Scheduler参数，来指定对数据的处理运行在特定的线程调度器Scheduler上。
若多次设定，则只有一次起作用。

    observeOn同样接收一个Scheduler参数，来指定下游操作运行在特定的线程调度器Scheduler上。
若多次设定，每次均起作用。

----
Scheduler种类
    Schedulers.io( )：
用于IO密集型的操作，例如读写SD卡文件，查询数据库，访问网络等，具有线程缓存机制，在此调度器接收到任务后，先检查线程缓存池中，
是否有空闲的线程，如果有，则复用，如果没有则创建新的线程，并加入到线程池中，如果每次都没有空闲线程使用，可以无上限的创建新线程。

    Schedulers.newThread( )：
在每执行一个任务时创建一个新的线程，不具有线程缓存机制，因为创建一个新的线程比复用一个线程更耗时耗力，虽然使用Schedulers.io( )
的地方，都可以使用Schedulers.newThread( )，但是，Schedulers.newThread( )的效率没有Schedulers.io( )高。

    Schedulers.computation()：
用于CPU 密集型计算任务，即不会被 I/O 等操作限制性能的耗时操作，例如xml,json文件的解析，Bitmap图片的压缩取样等，具有固定的线程池，
大小为CPU的核数。不可以用于I/O操作，因为I/O操作的等待时间会浪费CPU。

    Schedulers.trampoline()：
在当前线程立即执行任务，如果当前线程有任务在执行，则会将其暂停，等插入进来的任务执行完之后，再将未完成的任务接着执行。

    Schedulers.single()：
拥有一个线程单例，所有的任务都在这一个线程中执行，当此线程中有任务执行时，其他任务将会按照先进先出的顺序依次执行。

    Scheduler.from(@NonNull Executor executor)：
指定一个线程调度器，由此调度器来控制任务的执行策略。

    AndroidSchedulers.mainThread()：
在Android UI线程中执行任务，为Android开发定制。

注：
在RxJava2中，废弃了RxJava1中的Schedulers.immediate( )
在RxJava1中，Schedulers.immediate( )的作用为在当前线程立即执行任务，功能等同于RxJava2中的Schedulers.trampoline( )。
而Schedulers.trampoline( )在RxJava1中的作用是当其它排队的任务完成后，在当前线程排队开始执行接到的任务，有点像RxJava2中的Schedulers.single()，但也不完全相同，因为Schedulers.single()不是在当前线程而是在一个线程单例中排队执行任务。

作者：冯丰枫
链接：https://www.jianshu.com/p/12638513424f
     */

    @Test
    public void subscribe_observe() {
        TestObserverEx<String> observer = new TestObserverEx<>();

        Observable.fromIterable(Arrays.asList("hello", "gaga", "12 String"))
                  .doOnNext(s -> Utils.log("subscribeOn Schedulers.single() 1: " + s))
                  .subscribeOn(Schedulers.single())
                  .doOnNext(s -> {
                      Utils.log("subscribeOn Schedulers.io() 2: " + s); // 无效，和上面的subscribeOn指定的线程一样
                      Utils.sleep(10, TimeUnit.MILLISECONDS);
                  })
                  .subscribeOn(Schedulers.io())
                  .observeOn(Schedulers.computation())
                  .doOnNext(s -> Utils.log("observeOn Schedulers.computation() 3: " + s))
                  .observeOn(Schedulers.single())
                  .doOnNext(s -> Utils.log("observeOn Schedulers.single() 4: " + s))
                  .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void trampoline_001() {
        /*
        Schedulers.trampoline()的作用在当前线程立即执行任务，如果当前线程有任务在执行，则会将其暂停，
        等插入进来的任务执行完之后，再将未完成的任务接着执行。
         */
        TestObserverEx<String> observer = new TestObserverEx<>();

        Observable.fromIterable(Arrays.asList("hello", "gaga", "12 String"))
                  .doOnNext(s -> Utils.log("1 : " + s))
                  .subscribeOn(Schedulers.io())
                  .doOnNext(s -> Utils.log("2 : " + s))
                  .observeOn(Schedulers.trampoline())
                  .doOnNext(s -> Utils.log("3 : " + s))
                  .subscribe(observer);

        observer.awaitTerminalEvent();

        /*
        main: onSubscribe s=io.reactivex.internal.operators.observable.ObservableDoOnEach$DoOnEachObserver@2038ae61
        RxCachedThreadScheduler-1: 1 : hello
        RxCachedThreadScheduler-1: 2 : hello
        RxCachedThreadScheduler-1: 3 : hello
        RxCachedThreadScheduler-1: onNext t=hello
        RxCachedThreadScheduler-1: 1 : gaga
        RxCachedThreadScheduler-1: 2 : gaga
        RxCachedThreadScheduler-1: 3 : gaga
        RxCachedThreadScheduler-1: onNext t=gaga
        RxCachedThreadScheduler-1: 1 : 12 String
        RxCachedThreadScheduler-1: 2 : 12 String
        RxCachedThreadScheduler-1: 3 : 12 String
        RxCachedThreadScheduler-1: onNext t=12 String
        RxCachedThreadScheduler-1: onComplete
         */
    }

    @Test
    public void computation_001() {
        TestObserverEx<String> observer = new TestObserverEx<>();

        Observable.fromIterable(Arrays.asList("hello", "gaga", "12 String"))
                  .doOnNext(s -> Utils.log("1 : " + s))
                  .subscribeOn(Schedulers.io())
                  .doOnNext(s -> Utils.log("2 : " + s))
                  .observeOn(Schedulers.computation())
                  .doOnNext(s -> Utils.log("3 : " + s))
                  .subscribe(observer);

        observer.awaitTerminalEvent();

        /*
main: onSubscribe s=io.reactivex.internal.operators.observable.ObservableDoOnEach$DoOnEachObserver@20398b7c
RxCachedThreadScheduler-1: 1 : hello
RxCachedThreadScheduler-1: 2 : hello
RxCachedThreadScheduler-1: 1 : gaga
RxCachedThreadScheduler-1: 2 : gaga
RxCachedThreadScheduler-1: 1 : 12 String
RxCachedThreadScheduler-1: 2 : 12 String
RxComputationThreadPool-1: 3 : hello
RxComputationThreadPool-1: onNext t=hello
RxComputationThreadPool-1: 3 : gaga
RxComputationThreadPool-1: onNext t=gaga
RxComputationThreadPool-1: 3 : 12 String
RxComputationThreadPool-1: onNext t=12 String
RxComputationThreadPool-1: onComplete
         */
    }

    @Test
    public void single_001() {
        /*
           Schedulers.single()：
拥有一个线程单例，所有的任务都在这一个线程中执行，当此线程中有任务执行时，其他任务将会按照先进先出的顺序依次执行。
         */
        TestObserverEx<String> observer = new TestObserverEx<>();

        Observable.fromIterable(Arrays.asList("hello", "gaga", "12 String"))
                  .doOnNext(s -> Utils.log("发射 : " + s))
                  .subscribeOn(Schedulers.single())
                  .observeOn(Schedulers.single())
                  .doOnNext(s -> Utils.log("处理 : " + s))
                  .observeOn(Schedulers.single())
                  .doOnNext(s -> Utils.log("接收 : " + s))
                  .subscribe(observer);

        observer.awaitTerminalEvent();

        /*
main: onSubscribe s=io.reactivex.internal.operators.observable.ObservableDoOnEach$DoOnEachObserver@2ac273d3
RxSingleScheduler-1: 发射 : hello
RxSingleScheduler-1: 发射 : gaga
RxSingleScheduler-1: 发射 : 12 String
RxSingleScheduler-1: 处理 : hello
RxSingleScheduler-1: 处理 : gaga
RxSingleScheduler-1: 处理 : 12 String
RxSingleScheduler-1: 接收 : hello
RxSingleScheduler-1: onNext t=hello
RxSingleScheduler-1: 接收 : gaga
RxSingleScheduler-1: onNext t=gaga
RxSingleScheduler-1: 接收 : 12 String
RxSingleScheduler-1: onNext t=12 String
RxSingleScheduler-1: onComplete
         */
    }

    @Test
    public void current_001() {
        TestObserverEx<String> observer = new TestObserverEx<>();

        Observable.fromIterable(Arrays.asList("hello", "gaga", "12 String"))
                  .doOnNext(s -> Utils.log("发射 : " + s))
                  .doOnNext(s -> Utils.log("处理 : " + s))
                  .doOnNext(s -> Utils.log("接收 : " + s))
                  .subscribe(observer);

        observer.awaitTerminalEvent();
        /*
main: onSubscribe s=io.reactivex.internal.operators.observable.ObservableDoOnEach$DoOnEachObserver@3b81a1bc
main: 发射 : hello
main: 处理 : hello
main: 接收 : hello
main: onNext t=hello
main: 发射 : gaga
main: 处理 : gaga
main: 接收 : gaga
main: onNext t=gaga
main: 发射 : 12 String
main: 处理 : 12 String
main: 接收 : 12 String
main: onNext t=12 String
main: onComplete
         */
    }


}
