package com.bingcoo.rxjava2.group;

/*
    参考：Rxjava2总结 -- https://luhaoaimama1.github.io/2017/07/31/rxjava/
 */

/*
    This section explains operators with which you conditionally emit or transform Observables,
    or can do boolean evaluations of them.
 */

public class ConditionalBooleanOperators {

}
