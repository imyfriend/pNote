package com.bingcoo.rxjava2.group;

/*
    参考：Rxjava2总结 -- https://luhaoaimama1.github.io/2017/07/31/rxjava/
 */

import org.junit.Test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.internal.functions.Functions;
import io.reactivex.schedulers.Schedulers;

import com.bingcoo.rxjava2.TestObserverEx;
import com.bingcoo.rxjava2.Utils;

public class TransformingObservables {
    @Test
    public void map_001() {
        // map:对Observable发射的每一项数据应用一个函数，执行变换操作
        Observable.just(1, 2)
                .map(integer -> "This is result " + integer)
                .subscribe(Utils::log);
    }

    @Test
    public void flatMap_001() {
        /*
        flatMap: 将一个发射数据的Observable变换为多个Observables，然后将它们发射的数据合并后放进一个单独的Observable
        mapper:根据发射数据映射成Observable
        combiner: 用来合并 的
        注意:FlatMap 对这些Observables发射的数据做的是合并( merge )操作，因此它们可能是交错的。
         */
        Observable.just(1, 2, 3)
                .flatMap(integer -> Observable.range(integer * 10, 2)
                        , (a, b) -> {
                            //a ： 原始数据的 just(1,2,3) 中的值
                            //b ： 代表 flatMap后合并发送的数据的值
                            Utils.log("a:" + a + ", b:" + b);
                            //return flatMap发送的值 ，经过处理后 而发送的值
                            return a + b;
                        })
                .subscribe(Utils::log);
    }

    @Test
    public void flatMapIterable_001() {
        Observable.just(Arrays.asList(2, 4), Arrays.asList("two", "four"))
                  .flatMapIterable(new Function<List<? extends Serializable>, Iterable<?>>() {
                      @Override
                      public Iterable<?> apply(List<? extends Serializable> serializables) throws
                                                                                           Exception {
                          return serializables;
                      }
                  })
                  .subscribe(Utils::log);
    }

    @Test
    public void concatMap_001() {
        // concatMap:类似FlatMap但是保证顺序 因为没有合并操作！
        Observable.just(1, 2, 3)
                .concatMap(integer -> Observable.range(integer * 10, 2))
                .subscribe(Utils::log);
    }

    @Test
    public void cast_001() {
        // cast:在发射之前强制将Observable发射的所有数据转换为指定类型
        Observable.just(1, 2, "string", 3)
                .cast(Integer.class)//订阅之后才能发横强转
                .subscribe(Utils::log, Utils::log);
    }

    @Test
    public void groupBy_001() {
        /*
        groupBy:通过keySelector的apply的值当做key 进行分组,发射GroupedObservable(有getKey()方法)的group
        通过group继续订阅取得其组内的值;
            keySelector:通过这个的返回值 当做key进行分组
            valueSelector:value转换
         */
        Observable.range(0, 10)
                .groupBy(integer -> integer % 2, integer -> "(" + integer + ")")
                .subscribe(group -> {
                    group.subscribe(integer -> System.out.println(
                            "key:" + group.getKey() + "==>value:" + integer));
                });
    }

    @Test
    public void groupBy_002() {
        Observable.range(0, 10)
                .groupBy(integer -> integer % 2, integer -> integer)
                .flatMap(group -> group.toList().toObservable())
                .subscribe(Utils::log);
    }

    @Test
    public void groupBy_003() {
        Observable.range(0, 10)
                .groupBy(integer -> integer % 2, integer -> integer)
                .flatMap(group -> group.toMultimap(v -> group.getKey()).toObservable())
                .subscribe(Utils::log);
    }

    @Test
    public void window_001() {
        TestObserverEx<List<Long>> observer = new TestObserverEx<>();
        // window: 依照此范例 每三秒收集,Observable在此时间内发送的值。组装成Observable发送出去。
        Observable.interval(1, TimeUnit.SECONDS).take(30)
                //返回值  Observable<Observable<T>> 即代表 发送Observable<T>
                .window(3, TimeUnit.SECONDS)
                .flatMap(window -> window.toList().toObservable())
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void scan_001() {
        /*
        scan:连续地对数据序列的每一项应用一个函数，然后连续发射结果
        感觉就是发送一个有 累加(函数) 过程序列
        * initialValue（可选） 其实就是放到 原始数据之前发射。
        * a 原始数据的中的值
        * b 则是最后应用scan函数后发送的值
         */
        Observable.just(1, 4, 2)
                // 7是用来 对于第一次的 a的值
                .scan(7, (a, b) -> {
                    //b 原始数据的 just(1,4,2) 中的值
                    //a 则是最后应用scan 发送的值
                    System.out.format("a:%d * b:%d\n", a, b);
                    return a * b;
                })
                .subscribe(Utils::log);
    }

    @Test
    public void buffer_count_001() {
        /*
        emits buffers every {skip} items, each containing {count} items.
        count:缓存的数量
        skip:每个缓存创建的间隔数量

        注意skip不能小于0
        可以小于count这样就会导致每个发送的list之间的值会有重复
        可以大于count这样就会导致每个发送的list之间的值和原有的值之间会有遗漏
        可以等于count就你懂的了
         */
        Observable.range(1, 10)
                .buffer(2, 1,ArrayList::new)//有默认的装载器
                .subscribe(Utils::log);
        // 解析:每发射1个。创建一个发射物list buffer,每个buffer缓存2个,收集的存入list后发送。
    }

    @Test
    public void buffer_time_001() {
        TestObserverEx<List<Long>> observer = new TestObserverEx<>();
        /*
        starts a new buffer periodically, as determined by the {timeSkip} argument, and on the
        specified {scheduler}. It emits each buffer after a fixed timeSpan, specified by the
        {timeSpan} argument.

        变体 time系列
        timeSpan:缓存的时间
        timeSkip:每个缓存创建的间隔时间
        注意：timeSpan和timeSkip可以重叠
         */
        Observable.interval(600, TimeUnit.MILLISECONDS)
                .take(7)
                .buffer(3, 2, TimeUnit.SECONDS, Schedulers.single(),
                        Functions.createArrayList(16))
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void buffer_open_close_001() {
        TestObserverEx<List<Long>> observer = new TestObserverEx<>();
        /*
        emits buffers that it creates when the specified {openingIndicator} ObservableSource emits an
        item, and closes when the ObservableSource returned from {closingIndicator} emits an item.

        变体 自定义buffer创建和收集时间
        bufferOpenings:每当 bufferOpenings 发射了一个数据时，它就 创建一个新的 List,开始装入之后的发射数据
        closingSelector:每当 closingSelector 发射了一个数据时,就结束装填数据 发射List。
         */
        Consumer<Long> longConsumer  = aLong -> System.out.println("开始创建 bufferSupplier");
        Consumer<Long> longConsumer2 = aLong -> System.out.println("结束收集");
        Observable.interval(500, TimeUnit.MILLISECONDS).take(7)
                //                .doOnNext(aLong -> System.out.println("原始发射物：" + aLong))
                .buffer(Observable.interval(2, TimeUnit.SECONDS)
                                .startWith(-1L)//为了刚开始就发射一次
                                .take(2)//多余的我就不创建了
                                .doOnNext(longConsumer)
                        , aLong -> Observable.timer(3, TimeUnit.SECONDS)
                                .doOnNext(longConsumer2)
                        , ArrayList::new)
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void buffer_boundarySupplier_001() {
        TestObserverEx<List<Long>> observer = new TestObserverEx<>();
        /*
        变体 仅仅bufer创建时间
        boundarySupplier 因为发送一个值代表上个缓存的发送 和这个缓存的创建
         */
        Observable.interval(500, TimeUnit.MILLISECONDS).take(7)
                .buffer(() -> Observable.timer(2, TimeUnit.SECONDS)
                                .doOnNext(aLong -> System.out.println("开始创建 bufferSupplier"))
                        , ArrayList::new)
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

}
