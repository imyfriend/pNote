package com.bingcoo.rxjava2;

/*
部分内容来自：冯丰枫 Rxjava2入门教程 - https://www.jianshu.com/nb/14108894
 */


import org.junit.Test;

import io.reactivex.Observable;

public class MapTest {
    @Test
    public void map_001() {
        /*
        map:对Observable发射的每一项数据应用一个函数，执行变换操作map操作符，
        需要接收一个函数接口Function<T,R>的实例化对象，实现接口内R apply(T t)的方法，
        在此方法中可以对接收到的数据t进行变换后返回。
         */
        TestObserverEx<String> observer = new TestObserverEx<>();
        Observable.range(0, 5)
                .map(value -> value + "^2=" + value*value)
                .subscribe(observer);
        observer.assertComplete();
    }

    @Test
    public void flatMap_001() {
        /*
        flatMap:将一个发射数据的Observable变换为多个Observable，然后将多个Observable发射的
        数据合并到一个Observable中进行发射
         */
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        Observable.just(new Integer[]{1, 2, 3}, new Integer[]{4, 5, 5}, new Integer[]{9, 21})
                .flatMap(Observable::fromArray)
                .subscribe(observer);
        observer.assertComplete();
    }


}
