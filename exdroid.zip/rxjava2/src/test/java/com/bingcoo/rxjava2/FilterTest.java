package com.bingcoo.rxjava2;

import org.junit.Test;

import io.reactivex.Observable;

/*
部分内容来自：冯丰枫 Rxjava2入门教程 - https://www.jianshu.com/nb/14108894
 */

public class FilterTest {
    @Test
    public void filter_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        Observable.range(1, 5)
                .filter(value -> value<3)
                .subscribe(observer);
        observer.assertComplete();
    }

    @Test
    public void distinct_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        Observable.fromArray(1, 1, 2, 3, 4, 2, 4)
                .distinct()
                .subscribe(observer);
        observer.assertComplete();
    }
}
