package com.bingcoo.rxjava2.group;

/*
参考：Rxjava2总结 -- https://luhaoaimama1.github.io/2017/07/31/rxjava/
 */

import org.junit.Test;

import java.util.Collections;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.schedulers.Schedulers;

import com.bingcoo.rxjava2.TestObserverEx;
import com.bingcoo.rxjava2.Utils;

public class CombiningObservables {
    @Test
    public void zip_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        /*
        zip(静态方法):只有当原始的Observable中的每一个都发射了 一条数据时 zip 才发射数据。接受一到九个参数
         */
        Observable<Long> observable1 = Observable.interval(100, TimeUnit.MILLISECONDS)
                .take(3)
                .subscribeOn(Schedulers.newThread());
        Observable<Long> observable2 = Observable.interval(200, TimeUnit.MILLISECONDS)
                .take(4)
                .subscribeOn(Schedulers.newThread());
        Observable.zip(observable1, observable2, (aLong, aLong2) -> {
            System.out.print("aLong:" + aLong + "\t aLong2:" + aLong2+"\t");
            return aLong + aLong2;
        }).subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void zipWith_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        /*
        zipWith:zip的非静态写法,总是接受两个参数，第一个参数是一个Observable或者一个Iterable。
         */
        Observable.just(1, 2, 3)
                .zipWith(Observable.just(10, 20, 30), (aLong, aLong2) -> {
                    System.out.print("aLong:" + aLong + "\t aLong2:" + aLong2+"\t");
                    return aLong + aLong2;
                })
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void merge_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        /*
        merge(静态方法):根据时间线 合并多个observer
         */
        Observable<Long> ob1 = Observable.interval(100, TimeUnit.MILLISECONDS)
                .take(3)
                .map(aLong -> aLong * 100)
                .subscribeOn(Schedulers.newThread());

        Observable<Long> ob2 = Observable.interval(50, TimeUnit.MILLISECONDS)
                .take(4)
                .map(aLong -> aLong * 50 + 5)
                .subscribeOn(Schedulers.newThread());

        Observable.merge(ob1, ob2)
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void mergeWith_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        /*
        mergeWith:merge非静态写法
         */
        Observable<Long> ob1 = Observable.interval(100, TimeUnit.MILLISECONDS)
                .take(3)
                .map(aLong -> aLong * 100)
                .subscribeOn(Schedulers.newThread());

        Observable<Long> ob2 = Observable.interval(50, TimeUnit.MILLISECONDS)
                .take(4)
                .map(aLong -> aLong * 50 + 5)
                .subscribeOn(Schedulers.newThread());

        ob1.mergeWith(ob2).subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void combineLatest_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        /*
        combineLatest(静态方法):使用一个函数结合它们最近发射的数据，然后发射这个函数的返回值,它接受二到九个
        Observable作为参数 或者单 个Observables列表作为参数
         */
        Observable<Long> observable1 = Observable.interval(100, TimeUnit.MILLISECONDS)
                .take(4)
                .subscribeOn(Schedulers.newThread());
        Observable<Long> observable2 = Observable.interval(200, TimeUnit.MILLISECONDS)
                .take(5)
                .subscribeOn(Schedulers.newThread());
        Observable.combineLatest(observable1, observable2, (aLong, aLong2) -> {
            System.out.print("aLong:" + aLong + "\t aLong2:" + aLong2+"\t");
            return aLong + aLong2;
        }).subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void withLatestFrom_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        /*
        withLatestFrom:类似zip ,但是只在observable2发射了一条数据时才发射数据,而不是两个都发
         */
        Observable<Long> observable2 = Observable.interval(150, TimeUnit.MILLISECONDS)
                .take(4)
                .subscribeOn(Schedulers.newThread());
        Observable<Long> observable1 = Observable.interval(100, TimeUnit.MILLISECONDS)
                .take(3)
                .subscribeOn(Schedulers.newThread());

                // 明明原始take是3为啥不是三条log呢 因为原始的发送0的时候 ，Observable2还没发送过数据
        observable1.withLatestFrom(observable2, (aLong, aLong2) -> {
                    System.out.print("aLong:" + aLong + "\t aLong2:" + aLong2 + "\t");
                    return aLong + aLong2;
                })
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void switchMap_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        /*
        switchMap:和flatMap类似,不同的是当原始Observable发射一个新的数据（Observable）时，它将取消订阅前一个Observable
         */
        Observable.interval(500, TimeUnit.MILLISECONDS)
                .take(3)
                .doOnNext(Utils::log)
                .switchMap(aLong -> Observable.intervalRange(aLong * 10, 3,
                                                             0, 300, TimeUnit.MILLISECONDS)
                        .subscribeOn(Schedulers.newThread()))
                .subscribe(observer);
        observer.awaitTerminalEvent();

        /*
        解析：因为发送2的时候 intervalRange发送第三条数据的时候已经是600ms既 500ms的时候原始数据发送了。
        导致取消订阅前一个Observable,所以 2 ,12没有发送 但是最后的22发送了 因为原始数据没有新发送的了
         */
    }

    @Test
    public void startWith_001() {
        /*
        startWith:是concat()的对应部分,在Observable开始发射他们的数据之前,startWith()通过传递一个参数来先发射一个数据序列
         */
        Observable.just("old").startWith("Start") // 简化版本 T item
                .startWith("Start2")
                .startWith(Observable.just("Other Observable")) // observer版本
                .startWith(Collections.singletonList("from Iterable")) // Iterable版本
                .startWithArray("from Array", "from Array2") // T...版本
                .subscribe(Utils::log);
    }

    @Test
    public void join_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        /*
        join:任何时候，只要在另一个Observable发射的数据定义的时间窗口内，这个Observable发射了一条数据，
        就结合两个Observable发射的数据
         */
        Observable.intervalRange(10, 4, 0, 300, TimeUnit.MILLISECONDS)
                .join(Observable.interval(100, TimeUnit.MILLISECONDS)
                              .take(7)
                        , aLong -> {
                            System.out.println("开始收集："+aLong);
                            return Observable.just(aLong);
                        }
                        , aLong -> Observable.timer(200, TimeUnit.MILLISECONDS)
                        , (aLong, aLong2) -> {
                            System.out.print("aLong:" + aLong + "\t aLong2:" + aLong2 + "\t");
                            return aLong + aLong2;
                        }
                     )
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }



}
