package com.bingcoo.rxjava2;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.ObservableSource;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.BiFunction;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.internal.disposables.DisposableHelper;
import io.reactivex.internal.util.BlockingHelper;
import io.reactivex.plugins.RxJavaPlugins;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by admin on 2017/12/18.
 * 部分内容来自：冯丰枫 Rxjava2入门教程 - https://www.jianshu.com/nb/14108894
 * 部分内容来自：这可能是最好的RxJava 2.x 入门教程（二） - https://www.jianshu.com/p/b39afa92807e
 */

public class CreatingObservables {
    /*
    被观察者 Observable 称为发射器（上游事件），观察者 Observer 称为接收器（下游事件）
     */

    @Test
    public void create_001() {
        /*
        ObservableEmitter<T> 继承自接口Emitter<T>，查看源码接口Emitter的具体代码如下：

        public interface Emitter<T> {
                //用来发送数据，可多次调用，每调用一次发送一条数据
                void onNext(@NonNull T value);
                //用来发送异常通知，只发送一次，若多次调用只发送第一条
                void onError(@NonNull Throwable error);
                //用来发送完成通知，只发送一次，若多次调用只发送第一条
                void onComplete();
        }
        onNext：用来发送数据，可多次调用，每调用一次发送一条数据
        onError：用来发送异常通知，只发送一次，若多次调用只发送第一条
        onComplete：用来发送完成通知，只发送一次，若多次调用只发送第一条

         */
        Observable<String> observable = Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(ObservableEmitter<String> e) throws Exception {
                Utils.log("e=" + e.getClass());
                e.onNext("begin"); // onNext()内部进行了isDisposed()的判断
                e.onComplete(); // onComplete()内部进行了isDisposed()的判断
            }
        });

        Observer<String> observer = new Observer<String>() {

            /*
            onSubscribe表示在订阅时，当观察者Observer订阅可观察对象Observable，建立订阅关系后，
            会触发这个方法，并且会生成一个Disposable对象，其实无论观察者Observer以何种方式订阅
            可观察对象Observable，都会生成一个Disposable，不管有没有onSubscribe(Disposable d)方法。

            查看Disposable接口的源码，如下：
            public interface Disposable {
                    void dispose();
                    boolean isDisposed();
            }
            Disposable是观察者Observer与可观察对象Observable建立订阅关系后生成的用来取消订阅关系
            和判断订阅关系是否存在的一个接口。
            只有当观察者Observer与可观察对象Observable之间存在订阅关系时，Observer才能接收Observable
            发送的数据或信息。如果Observer在接收Observable的信息的过程中，取消了订阅关系，则Observer
            只能接收订阅关系取消之前Observable发送的数据，对于订阅关系取消之后Observable发送的数据，
            Observer将不会再接收。
             */
            @Override
            public void onSubscribe(Disposable d) {
                System.out.println("onSubscribe d=" + d); // 这里输出d=null，只是因为d的toString方法返回null，d不为null
                //Utils.findCaller();
            }

            @Override
            public void onNext(String s) {
                System.out.println("onNext 我接收到数据了 s=" + s);
            }

            @Override
            public void onError(Throwable e) {
                System.out.println("onError e=" + e);
            }

            @Override
            public void onComplete() {
                System.out.println("onComplete");
            }
        };

        observable.subscribe(observer);
    }

    @Test
    public void create_002() {
        Observable<String> observable = Observable.create(e -> {
            e.onNext("1");

            /*
            1.x 是允许我们在发射事件的时候传入 null 值的，但现在我们的 2.x 不支持了,此时抛出NullPointerException
             */
            e.onNext(null);
        });

        TestObserverEx<String> observerEx = new TestObserverEx<>();

        observable.subscribe(observerEx);
    }

    @Test
    public void just_001() {
        TestObserverEx<String> observer = new TestObserverEx<>();
        Observable<String> observable = Observable.just("Hello", "world");
        observable.subscribe(observer);

        observer.assertComplete();
    }

    @Test
    public void just_002() {
        Observable.just("hello, world!")
                .subscribe(new Consumer<String>() {
                    @Override
                    public void accept(String s) throws Exception {
                        Utils.log("accept s=" + s);
                    }
                });
    }

    @Test
    public void range_dispose() {
        /*
        注意：取消订阅关系后，onError/onComplete也不会被调用了
         */
        Observable.range(1, 9)
                .subscribe(new Observer<Integer>() {
                    Disposable mDisposable;

                    @Override
                    public void onSubscribe(Disposable d) {
                        mDisposable = d;
                    }

                    @Override
                    public void onNext(Integer integer) {
                        Utils.log("onNext integer=" + integer);
                        if (5 < integer) {
                            mDisposable.dispose();
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Utils.log("onError e=" + e);
                    }

                    @Override
                    public void onComplete() {
                        Utils.log("onComplete");
                    }
                });
    }

    @Test
    public void fromIterable_001() {
        TestObserverEx<String> observer = new TestObserverEx<>();

        List<String> list = new ArrayList<>();
        for(int i=0; i<10; i++){
            list.add("Hello"+i);
        }
        Observable<String> observable = Observable.fromIterable(list);
        observable.subscribe(observer);

        observer.assertComplete();
    }

    @Test
    public void fromArray_001() {
        Integer[] array = new Integer[]{0, 1, 2, 3};

        TestObserverEx<Integer> observer = new TestObserverEx<>();
        Observable.fromArray(array).subscribe(observer);
        observer.assertComplete();
    }

    @Test
    public void defer_001() {
        TestObserverEx<String> observer = new TestObserverEx<>();
        /*
        当观察者订阅时，才创建Observable，并且针对每个观察者创建都是一个新的Observable。
        以何种方式创建这个Observable对象，当满足回调条件后，就会进行相应的回调。
         */
        Observable<String> observable = Observable.defer(new Callable<ObservableSource<? extends String>>() {

            @Override
            public ObservableSource<? extends String> call() throws Exception {
                return Observable.just("Hello,world!!");
            }
        });

        observable.subscribe(observer);

        observer.assertComplete();
    }

    @Test
    public void interval_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        /*
        创建一个按固定时间间隔发射整数序列的Observable，可用作定时器。
         */
        Observable<Long> observable = Observable.interval(2, TimeUnit.SECONDS).take(10);
        observable.subscribe(observer);

        observer.awaitTerminalEvent();
        observer.assertComplete();
    }

    @Test
    public void range_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        /*
        创建一个发射特定整数序列的Observable，第一个参数为起始值，第二个为发送的个数，
        如果为0则不发送，负数则抛异常。
         */
        Observable<Integer> observable = Observable.range(2, 5);
        observable.subscribe(observer);

        //observer.awaitTerminalEvent();
        observer.assertComplete();
    }

    @Test
    public void timer_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        /*
        在一个给定的延迟后发射0L
         */
        Observable<Long> observable = Observable.timer(2, TimeUnit.SECONDS);
        observable.subscribe(observer);

        observer.awaitTerminalEvent();
        observer.assertComplete();
    }

    @Test
    public void repeat_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        /*
        创建一个Observable，该Observable的事件可以重复调用
         */
        Observable<Integer> observable = Observable.just(123).repeat().take(3);
        observable.subscribe(observer);

        observer.assertComplete();
    }

    @Test
    public void buffer_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();

        Observable.just(1, 2, 3, 4, 5)
                .buffer(3, 2)
                .subscribe(new Consumer<List<Integer>>() {
                    @Override
                    public void accept(List<Integer> integers) throws Exception {
                        Utils.log("accept integers=" + integers);
                    }
                });
    }

    @Test
    public void buffer_002() {
        Observable.range(0, 100)
                .buffer(3, 20)
                .subscribe(new Consumer<List<Integer>>() {
                    @Override
                    public void accept(List<Integer> integers) throws Exception {
                        Utils.log("accept integers=" + integers);
                    }
                });
    }

    @Test
    public void buffer_003() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();

        Observable.just(1, 2, 3, 4, 5)
                .buffer(3)
                .subscribe(new Consumer<List<Integer>>() {
                    @Override
                    public void accept(List<Integer> integers) throws Exception {
                        Utils.log("accept integers=" + integers);
                    }
                });
    }

    @Test
    public void window_001() {
        TestObserverEx<Observable<Integer>> observer = new TestObserverEx<Observable<Integer>>() {

            @Override
            public void onNext(Observable<Integer> integerObservable) {
                integerObservable.map(String::valueOf).reduce((String v1, String v2) -> v1 + ", " + v2)
                        .subscribe(Utils::log);
            }
        };

        Observable.range(0, 50)
                .window(4)
                .subscribe(observer);
    }

    @Test
    public void group_001() {
        TestObserverEx<String> observer = new TestObserverEx<>();
        Observable.range(0, 100)
                .groupBy(value -> value%2)
                .doOnNext(groupedObservable -> Utils.log(groupedObservable.getKey() + ", "))
                .flatMap(source -> source.map(String::valueOf)
                        .reduce((String v1, String v2) -> v1+","+v2).toObservable())
                .subscribe(observer);
    }

    @Test
    public void merge_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();

        Observable.merge(Observable.just(1L, 2L, 3L),
                         Observable.rangeLong(6, 4).subscribeOn(Schedulers.computation()),
                         Observable.intervalRange(10, 5, 50, 100, TimeUnit.MILLISECONDS),
                         Observable.intervalRange(20, 5, 0, 100, TimeUnit.MILLISECONDS))
                //.observeOn(Schedulers.single())
                .doOnComplete(() -> Utils.log("doOnComplete"))
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void combineLatest_001() {
        TestObserverEx<String> observer = new TestObserverEx<>();
        /*
        combineLatest操作符把两个Observable产生的结果进行合并，合并的结果组成一个新的Observable。
        这两个Observable中任意一个Observable产生的结果，都和另一个Observable最后产生的结果，按照
        一定的规则进行合并。
         */
        Observable.combineLatest(
                Observable.intervalRange(10, 5, 50, 100, TimeUnit.MILLISECONDS),
                Observable.intervalRange(20, 5, 0, 100, TimeUnit.MILLISECONDS),
                (Long v1, Long v2) -> v1 + " + " + v2 + " = " + (v1+v2)
                                 )
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void scan_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        Observable.range(0, 10)
                .scan((Integer v1, Integer v2) -> {
                    Utils.log("v1=" + v1 + ", v2=" + v2);
                    return v1 + v2;
                })
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void amb_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();

        Observable.intervalRange(10, 5, 50, 100, TimeUnit.MILLISECONDS)
                .ambWith(Observable.timer(101, TimeUnit.MILLISECONDS))
                .subscribe(observer);

        observer.awaitTerminalEvent();

        Utils.log("-------");

        observer = new TestObserverEx<>();
        Observable.intervalRange(10, 5, 50, 100, TimeUnit.MILLISECONDS)
                .ambWith(Observable.timer(10, TimeUnit.MILLISECONDS))
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void takeUntil_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();

        Observable.intervalRange(1, 15, 50, 100, TimeUnit.MILLISECONDS)
                .doOnNext(Utils::log)
                .takeUntil(Observable.timer(360, TimeUnit.MILLISECONDS))
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void takeUntil_002() {
        TestObserverEx<Object> observer = new TestObserverEx<>();

        // 在Observable.timer发出数据前，empty已经发出OnComplete事件
        Observable.empty()
                .takeUntil(Observable.timer(1, TimeUnit.MINUTES))
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void all_001() {
        TestObserverEx<Boolean> observer = new TestObserverEx<>();

        Observable.just(1, 2, 3, 4, 5)
                .all(value -> 0<value)
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void join_001() {
        /*
        无论何时，如果一个Observable发射了一个数据项，只要在另一个Observable发射的数据项定义的时间窗口内，
        就将两个Observable发射的数据合并发射
         */
        TestObserverEx<Integer> observer = new TestObserverEx<>();

        Observable.range(1, 5)
                .join(Observable.just(10,11,12).delay(600, TimeUnit.MILLISECONDS),
                      value -> {
                            Utils.log("leftEnd value=" + value);
                            return Observable.just(0)
                                    .delay(500, TimeUnit.MILLISECONDS);},
                      value -> {
                            Utils.log("rightEnd value=" + value);
                            return Observable.just(1).delay(1000, TimeUnit.MILLISECONDS);},
                      (Integer v1, Integer v2) -> {
                            Utils.log("v1=" + v1 + ", v2=" + v2);
                            return v1 + v2;
                        })
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void join_002() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        //产生0,5,10,15,20数列
        Observable<Long> observable1 = Observable.interval(0, 1000, TimeUnit.MILLISECONDS)
                .map(new Function<Long, Long>() {
                    @Override
                    public Long apply(Long aLong) {
                        return aLong * 5;
                    }
                }).take(5);

        //产生0,10,20,30,40数列
        Observable<Long> observable2 = Observable.interval(500, 1000, TimeUnit.MILLISECONDS)
                .map(new Function<Long, Long>() {
                    @Override
                    public Long apply(Long aLong) {
                        return aLong * 10;
                    }
                }).take(5);

        observable1.join(observable2, new Function<Long, Observable<Long>>() {
            @Override
            public Observable<Long> apply(Long aLong) {
                //使Observable延迟600毫秒执行
                return Observable.just(aLong).delay(600, TimeUnit.MILLISECONDS);
            }
        }, new Function<Long, Observable<Long>>() {
            @Override
            public Observable<Long> apply(Long aLong) {
                //使Observable延迟600毫秒执行
                return Observable.just(aLong).delay(600, TimeUnit.MILLISECONDS);
            }
        }, new BiFunction<Long, Long, Long>() {
            @Override
            public Long apply(Long aLong, Long aLong2) {
                Utils.log("aLong=" + aLong + ", aLong2=" + aLong2);
                return aLong + aLong2;
            }
        }).subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void groupJoin_001() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        //产生0,5,10,15,20数列
        Observable<Long> observable1 = Observable.interval(0, 1000, TimeUnit.MILLISECONDS)
                .map(new Function<Long, Long>() {
                    @Override
                    public Long apply(Long aLong) {
                        return aLong * 5;
                    }
                }).take(5);

        //产生0,10,20,30,40数列
        Observable<Long> observable2 = Observable.interval(500, 1000, TimeUnit.MILLISECONDS)
                .map(new Function<Long, Long>() {
                    @Override
                    public Long apply(Long aLong) {
                        return aLong * 10;
                    }
                }).take(5);

        observable1.groupJoin(observable2,
                              new Function<Long, Observable<Long>>() {
                                  @Override
                                  public Observable<Long> apply(Long aLong) {
                                      //使Observable延迟600毫秒执行
                                      return Observable.just(aLong).delay(600, TimeUnit.MILLISECONDS);
                                  }
                              },
                              new Function<Long, Observable<Long>>() {
                                    @Override
                                    public Observable<Long> apply(Long aLong) {
                                        //使Observable延迟600毫秒执行
                                        return Observable.just(aLong).delay(600, TimeUnit.MILLISECONDS);
                                    }
                                },
                              new BiFunction<Long, Observable<Long>, Observable<Long>>() {
                                  @Override
                                  public Observable<Long> apply(Long aLong, Observable<Long> aLong2) {
                                      Utils.log("aLong=" + aLong + ", aLong2=" + aLong2);
                                      return aLong2.map(v -> v + aLong);
                                  }
                              })
                .flatMap(longObservable -> longObservable)
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void groupJoin_002() {
        TestObserverEx<Long> observer = new TestObserverEx<>();
        //产生0,5,10,15,20数列
        Observable<Long> observable1 = Observable.interval(0, 1000, TimeUnit.MILLISECONDS)
                .map(new Function<Long, Long>() {
                    @Override
                    public Long apply(Long aLong) {
                        return aLong * 5;
                    }
                }).take(5);

        //产生0,10,20,30,40数列
        Observable<Long> observable2 = Observable.interval(500, 1000, TimeUnit.MILLISECONDS)
                .map(new Function<Long, Long>() {
                    @Override
                    public Long apply(Long aLong) {
                        return aLong * 10;
                    }
                }).take(5);

        observable1.groupJoin(observable2,
                              new Function<Long, Observable<Long>>() {
                                  @Override
                                  public Observable<Long> apply(Long aLong) {
                                      //使Observable延迟600毫秒执行
                                      return Observable.just(aLong).delay(600, TimeUnit.MILLISECONDS);
                                  }
                              },
                              new Function<Long, Observable<Long>>() {
                                  @Override
                                  public Observable<Long> apply(Long aLong) {
                                      //使Observable延迟600毫秒执行
                                      return Observable.just(aLong).delay(600, TimeUnit.MILLISECONDS);
                                  }
                              },
                              new BiFunction<Long, Observable<Long>, Long>() {
                                  @Override
                                  public Long apply(Long aLong, Observable<Long> aLong2) {
                                      Utils.log("aLong=" + aLong + ", aLong2=" + aLong2);
                                      Long value = 0L;
                                      try {
                                          // 这个时候toFuture无效，是因为aLong2的onNext还没有被调用
                                          Future<Long> longFuture = aLong2.subscribeWith(new FutureObserverTest<>());
                                          value = longFuture.get();
                                      } catch (Exception e) {
                                          Utils.log("apply e=" + e);
                                      }
                                      return aLong + value;
                                  }
                              })
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    public final class FutureObserverTest<T> extends CountDownLatch
            implements Observer<T>, Future<T>, Disposable {

        T value;
        Throwable error;

        final AtomicReference<Disposable> s;

        public FutureObserverTest() {
            super(1);
            this.s = new AtomicReference<Disposable>();
            Utils.log("FutureObserverTest");
        }

        @Override
        public boolean cancel(boolean mayInterruptIfRunning) {
            for (;;) {
                Disposable a = s.get();
                if (a == this || a == DisposableHelper.DISPOSED) {
                    return false;
                }

                if (s.compareAndSet(a, DisposableHelper.DISPOSED)) {
                    if (a != null) {
                        a.dispose();
                    }
                    countDown();
                    return true;
                }
            }
        }

        @Override
        public boolean isCancelled() {
            return DisposableHelper.isDisposed(s.get());
        }

        @Override
        public boolean isDone() {
            return getCount() == 0;
        }

        @Override
        public T get() throws InterruptedException, ExecutionException {
            if (getCount() != 0) {
                BlockingHelper.verifyNonBlocking();
                await();
            }

            if (isCancelled()) {
                throw new CancellationException();
            }
            Throwable ex = error;
            if (ex != null) {
                throw new ExecutionException(ex);
            }
            return value;
        }

        @Override
        public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
            if (getCount() != 0) {
                BlockingHelper.verifyNonBlocking();
                if (!await(timeout, unit)) {
                    throw new TimeoutException();
                }
            }

            if (isCancelled()) {
                throw new CancellationException();
            }

            Throwable ex = error;
            if (ex != null) {
                throw new ExecutionException(ex);
            }
            return value;
        }

        @Override
        public void onSubscribe(Disposable s) {
            DisposableHelper.setOnce(this.s, s);
            Utils.log("onSubscribe");
        }

        @Override
        public void onNext(T t) {
            Utils.log("onNext t=" + t);
            if (value != null) {
                s.get().dispose();
                onError(new IndexOutOfBoundsException("More than one element received"));
                return;
            }
            value = t;
        }

        @Override
        public void onError(Throwable t) {
            Utils.log("onError t=" + t);
            if (error == null) {
                error = t;

                for (;;) {
                    Disposable a = s.get();
                    if (a == this || a == DisposableHelper.DISPOSED) {
                        RxJavaPlugins.onError(t);
                        return;
                    }
                    if (s.compareAndSet(a, this)) {
                        countDown();
                        return;
                    }
                }
            } else {
                RxJavaPlugins.onError(t);
            }
        }

        @Override
        public void onComplete() {
            Utils.log("onComplete");
            if (value == null) {
                onError(new NoSuchElementException("The source is empty"));
                return;
            }
            for (;;) {
                Disposable a = s.get();
                if (a == this || a == DisposableHelper.DISPOSED) {
                    return;
                }
                if (s.compareAndSet(a, this)) {
                    countDown();
                    return;
                }
            }
        }

        @Override
        public void dispose() {
            // ignoring as `this` means a finished Disposable only
        }

        @Override
        public boolean isDisposed() {
            return isDone();
        }
    }

}
