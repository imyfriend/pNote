package com.bingcoo.rxjava2.group;

/*
参考：Rxjava2总结 -- https://luhaoaimama1.github.io/2017/07/31/rxjava/
 */

/*
This class shows operators you can use to filter and select items emitted by Observables.
 */

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.schedulers.Schedulers;

import com.bingcoo.rxjava2.TestObserverEx;
import com.bingcoo.rxjava2.Utils;

public class FilteringObservables {
    @Test
    public void elementAt_001() {
        // elementAt:只发射第N项数据
        Observable.just(1, 2)
                .elementAt(0)
                .subscribe(Utils::log);
    }

    @Test
    public void elementAt_002() {
        Observable.range(0, 10)
                /*
                如果索引值大于数据项数，它会发射一个默认值(通过额外的参数指定)，而不是抛出异常。
                */
                .elementAt(100, -100)
                .subscribe(Utils::log);

        TestObserverEx<Integer> observer = new TestObserverEx<>();
        Observable.range(0, 10)
                /*
                如果你传递一个负数索引值，它仍然会抛出一个IndexOutOfBoundsException异常。
                 */
                .elementAt(-1)
                .subscribe(observer);

    }

    @Test
    public void ignoreElements_001() {
        // ignoreElements:如果你不关心一个Observable发射的数据，但是希望在它完成时或遇到错误终止时收到通知
        Observable.range(0, 10)
                .ignoreElements()
                .subscribe(() -> Utils.log("onComplete"), Utils::log);
    }

    @Test
    public void take_count_001() {
        // 变体 count系列:只发射前面的N项数据
        Observable.range(0,10)
                .take(3)
                .subscribe(Utils::log);
    }

    @Test
    public void take_time_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        // 变体 time系列: 发射Observable开始的那段时间发射的数据
        Observable.range(0,10)
                .take(100, TimeUnit.MILLISECONDS)
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void takeLast_count_001() {
        // 变体 count系列:只发射后面的N项数据
        Observable.range(0,10)
                .takeLast(3)
                .subscribe(Utils::log);
    }

    @Test
    public void takeLast_time_001() {
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        // 变体 time系列: 发射在原始Observable的生命周期内最后一段时间内发射的数据
        Observable.range(0,1000)
                .takeLast(100, TimeUnit.MILLISECONDS)
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void takeUntil_001() {
        // takeUntil:发送complete的结束条件 当然发送结束之前也会包括这个值
        Observable.just(2,3,4,5)
                // 发送complete的结束条件 当然发送结束之前也会包括这个值
                .takeUntil(integer ->  integer>3)
                .subscribe(Utils::log);
    }

    @Test
    public void takeWhile_001() {
        // takeWhile:当不满足这个条件会发送结束 不会包括这个值
        Observable.just(2,3,4,5)
                //当不满足这个条件会发送结束 不会包括这个值
                .takeWhile(integer ->integer<4 )
                .subscribe(Utils::log);
    }

    @Test
    public void skip_count_001() {
        // 变体 count系列:丢弃Observable发射的前N项数据
        Observable.range(1,5)
                .skip(3)
                .subscribe(Utils::log);
    }

    @Test
    public void skip_time_001() {
        // 变体 time系列:丢弃原始Observable开始的那段时间发射的数据
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        Observable.range(0,100000)
                .skip(5, TimeUnit.MILLISECONDS)
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void skipLast_count_001() {
        // 变体 count系列:丢弃Observable发射的后N项数据
        Observable.range(1,5)
                .skipLast(3)
                .subscribe(Utils::log);
    }

    @Test
    public void skipLast_time_001() {
        // 变体 time系列:丢弃原始Observable结束前的那段时间发射的数据
        TestObserverEx<Integer> observer = new TestObserverEx<>();
        Observable.range(0,100000)
                .skipLast(5, TimeUnit.MILLISECONDS)
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void distinct_001() {
        // 无参版本 就是内部实现了的keySelector通过生成的key就是value本身
        Observable.just(1, 2, 1, 2, 3)
                .distinct()
                .subscribe(Utils::log);
    }

    @Test
    public void distinct_002() {
        // keySelector:这个函数根据原始Observable发射的数据项产生一个 Key，然后，比较这些Key而不是
        // 数据本身，来判定两个数据是否是不同的
        Observable.just(1, 2, 1, 2, 3)
                //这个函数根据原始Observable发射的数据项产生一个 Key，
                // 然后，比较这些Key而不是数据本身，来判定两个数据是否是不同的
                .distinct(integer -> integer % 2 == 0)
                .subscribe(Utils::log);
    }

    @Test
    public void distinctUntilChanged_001() {
        // distinctUntilChanged(相邻去重):它只判定一个数据和它的直接前驱是否是不同的。
        Observable.just(1, 2, 1, 2, 3, 3)
                .distinctUntilChanged()
                .subscribe(Utils::log);
    }

    @Test
    public void distinctUntilChanged_002() {
        // distinctUntilChanged(相邻去重):它只判定一个数据和它的直接前驱是否是不同的。
        Observable.just(1, 2, 1, 2, 3, 3)
                //这个函数根据原始Observable发射的数据项产生一个 Key，
                // 然后，比较这些Key而不是数据本身，来判定两个数据是否是不同的
                .distinctUntilChanged(integer -> integer % 2 == 0)
                .subscribe(Utils::log);
    }

    @Test
    public void throttleWithTimeout() {
        TestObserverEx<String> observer = new TestObserverEx<>();
        /*
        操作符会过滤掉发射速率过快的数据项
        throttleWithTimeout/debounce： 含义相同
        如果发送数据后 指定时间段内没有新数据的话 。则发送这条
        如果有新数据 则以这个新数据作为将要发送的数据项，并且重置这个时间段，重新计时。
         */
        Observable.<String>create(e -> {
            e.onNext("onNext 0");
            Thread.sleep(100);
            e.onNext("onNext 1");
            Thread.sleep(230);
            e.onNext("onNext 2");
            Thread.sleep(300);
            e.onNext("onNext 3");
            Thread.sleep(400);
            e.onNext("onNext 4");
            Thread.sleep(500);
            e.onNext("onNext 5");
            e.onNext("onNext 6");
            e.onComplete();
        })
                .debounce(330, TimeUnit.MILLISECONDS)
                //                .throttleWithTimeout(330, TimeUnit.MILLISECONDS)
                .subscribeOn(Schedulers.newThread())
                .observeOn(Schedulers.newThread())
                .subscribe(observer);

        observer.awaitTerminalEvent();
    }

    @Test
    public void filter_001() {
        // filter:只发射通过了谓词测试的数据项
        Observable.range(1, 10)
                .filter(v -> v%2==0)
                .subscribe(Utils::log);
    }

    @Test
    public void ofType_001() {
        // ofType 是 filter 操作符的一个特殊形式。它过滤一个Observable只返回指定类型的数据
        Observable.just(0, "what?", 1, "String", 3)
                .ofType(String.class)
                .subscribe(Utils::log);
    }

    @Test
    public void first_001() {
        // first:只发射第一项数据 感觉和take(1) elementAt(0)差不多
        Observable.range(0, 10)
                //如果元数据没有发送  则有发送默认值
                .first(-1)
                .subscribe(Utils::log);
    }

    @Test
    public void last_001() {
        // last:只发射最后一项数据 感觉和takeLast(1)差不多
        Observable.range(0, 10)
                //如果元数据没有发送  则有发送默认值
                .last(-1)
                .subscribe(Utils::log);
    }

    @Test
    public void sample_001() {
        TestObserverEx<String> observer = new TestObserverEx<>();
        // sample/throttleLast: 周期采样后 发送最后的数据
        Observable.<String>create(e -> {
            e.onNext("onNext 0");
            Thread.sleep(100);
            e.onNext("onNext 1");
            Thread.sleep(50);
            e.onNext("onNext 2");
            Thread.sleep(70);
            e.onNext("onNext 3");
            Thread.sleep(200);
            e.onNext("onNext 4");
            e.onNext("onNext 5");
            e.onComplete();
        })
                .subscribeOn(Schedulers.newThread())
                .observeOn(Schedulers.newThread())
                .sample(200, TimeUnit.MILLISECONDS,Schedulers.newThread())
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

    @Test
    public void throttleFirst_001() {
        TestObserverEx<String> observer = new TestObserverEx<>();
        // 周期采样 的第一条数据 发送
        Observable.<String>create(e -> {
            e.onNext("onNext 0");
            Thread.sleep(100);
            e.onNext("onNext 1");
            Thread.sleep(50);
            e.onNext("onNext 2");
            Thread.sleep(70);
            e.onNext("onNext 3");
            Thread.sleep(200);
            e.onNext("onNext 4");
            e.onNext("onNext 5");
            e.onComplete();
        })
                .subscribeOn(Schedulers.newThread())
                .observeOn(Schedulers.newThread())
                .throttleFirst(200, TimeUnit.MILLISECONDS,Schedulers.newThread())
                .subscribe(observer);
        observer.awaitTerminalEvent();
    }

}
