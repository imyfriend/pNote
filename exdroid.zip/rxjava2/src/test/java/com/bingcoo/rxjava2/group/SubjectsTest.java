package com.bingcoo.rxjava2.group;

/*
    参考：Rxjava2总结 -- https://luhaoaimama1.github.io/2017/07/31/rxjava/
 */

import org.junit.Test;

import io.reactivex.subjects.AsyncSubject;
import io.reactivex.subjects.BehaviorSubject;
import io.reactivex.subjects.PublishSubject;
import io.reactivex.subjects.ReplaySubject;

public class SubjectsTest {
    /*
    Subject可以看成是一个桥梁或者代理，在某些ReactiveX实现中(如RxJava)，它同时充当 了Observer和Observable的角色。
    因为它是一个Observer，它可以订阅一个或多个 Observable;又因为它是一个Observable，它可以转发它收到(Observe)的数据，
    也可以发射新的数据。
    对我来说为什么用subjects呢？所有Subject都可以直接发射,不需要 发射器的引用 和 Observable.create()不同
     */

    @Test
    public void asyncSubject_001() {
        /*
        AsyncSubject:简单的说使用AsyncSubject无论输入多少参数，永远只输出最后一个参数。
        但是如果因为发生了错误而终止，AsyncSubject将不会发射任何数据，只是简单的向前传递这个错误通知。
         */
        AsyncSubject<Integer> source = AsyncSubject.create();
        source.subscribe(o -> System.out.println("1:"+o));
        source.onNext(1);
        source.onNext(2);
        source.onNext(3);

        source.subscribe(o -> System.out.println("2:"+o));
        source.onNext(4);
        source.onComplete();
    }

    @Test
    public void behaviorSubject_001() {
        /*
        BehaviorSubject:会发送离订阅最近的上一个值，没有上一个值的时候会发送默认值。
        如果原始的Observable因为发生了一个错误而终止，BehaviorSubject将不会发射任何 数据，只是简单的向前传递这个错误通知。
         */
        BehaviorSubject<Integer> source = BehaviorSubject.create();
        //默认值版本
        //        BehaviorSubject<Integer> source = BehaviorSubject.createDefault(-1);
        source.subscribe(o -> System.out.println("1:"+o));
        source.onNext(1);
        source.onNext(2);
        source.onNext(3);

        source.subscribe(o -> System.out.println("2:"+o));
        source.onNext(4);
        source.onComplete();
    }

    @Test
    public void publishSubject_001() {
        /*
        publishSubject(subject里最常用的):可以说是最正常的Subject，从那里订阅就从那里开始发送数据。
        如果原始的Observable因为发生了一个错误而终止，PublishSubject将不会发射任何数据，只 是简单的向前传递这个错误通知。
         */
        PublishSubject bs = PublishSubject.create();
        bs.subscribe(o -> System.out.println("1:"+o));
        bs.onNext(1);
        bs.onNext(2);
        bs.subscribe(o -> System.out.println("2:"+o));
        bs.onNext(3);
        bs.onComplete();
        bs.subscribe(o -> System.out.println("3:"+o));
    }

    @Test
    public void replaySubject_001() {
        /*
        replaySubject: 无论何时订阅，都会将所有历史订阅内容全部发出。
         */
        ReplaySubject bs = ReplaySubject.create();
        bs.subscribe(o -> System.out.println("1:"+o));
        // 无论何时订阅都会收到1，2，3
        bs.onNext(1);
        bs.onNext(2);
        bs.onNext(3);
        bs.onComplete();
        bs.subscribe(o -> System.out.println("2:"+o));
    }

}
