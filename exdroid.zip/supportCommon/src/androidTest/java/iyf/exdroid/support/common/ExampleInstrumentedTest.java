package iyf.exdroid.support.common;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;

import org.junit.Test;
import org.junit.runner.RunWith;

import iyf.exdroid.support.common.utils.BitmapUtils;
import iyf.exdroid.support.common.utils.HanziToPinyin;

import static org.junit.Assert.*;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    @Test
    public void useAppContext() throws Exception {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();

        assertEquals("iyf.exdroid.support.common.test", appContext.getPackageName());
        BitmapUtils.getDateNumberBitmap(appContext.getAssets(), "123");
    }

    @Test
    public void HanziToPinyin_test() throws Exception {
        Log.d("Hanzi", "防止: " + HanziToPinyin.getInstance().get("防止").get(0).mTarget + HanziToPinyin.getInstance().get("防止").get(1).mTarget);
        assertEquals("FANGZHI", HanziToPinyin.getInstance().get("防止").get(0).mTarget + HanziToPinyin.getInstance().get("防止").get(1).mTarget);
    }
}
