package iyf.exdroid.support.common.utils;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore.Images;
import android.provider.MediaStore.Images.ImageColumns;
import android.text.TextUtils;
import android.text.format.Formatter;
import android.util.Log;
import android.webkit.MimeTypeMap;

@SuppressWarnings({"WeakerAccess", "unused"})
public final class FileUtils {
	private static final String TAG = "FileUtils";

	/**
	 * The number of bytes in a kilobyte.
	 */
	@SuppressWarnings("WeakerAccess")
    public static final int ONE_KB = 1024;

	private static final int COPY_BUFFER_SIZE = 16 * ONE_KB;

	/**
	 * The number of bytes in a megabyte.
	 */
	public static final long ONE_MB = ONE_KB * ONE_KB;

	// --------------------------------------------------------------------------
	// Constructor
	// --------------------------------------------------------------------------

	private FileUtils() {
		// do nothing
	}

	// --------------------------------------------------------------------------
	// public static method
	// --------------------------------------------------------------------------

	/*
	 * copy function -- begin
	 */
	// assetFilePath: 1.mp4 or fonts/zidi.ttf
	public static void copyAssets(Context context, String assetFilePath,
			String destDirPath) throws IOException {
		AssetManager assetManager = context.getAssets();
		InputStream in = null;
		OutputStream out = null;
		try {
			in = assetManager.open(assetFilePath);
			File outFile = new File(destDirPath,
					getFileNameFromUrl(assetFilePath));
			out = new FileOutputStream(outFile);
			copy(in, out);
			out.flush();
		} catch (IOException e) {
			Log.e(TAG, "Failed to copy asset file: " + assetFilePath, e);
			throw e;
		} finally {
			closeQuietly(in);
            closeQuietly(out);
		}
	}

	public static void copy(InputStream from, OutputStream to)
			throws IOException {
		byte[] buffer = new byte[COPY_BUFFER_SIZE];
		int read;
		try {
			while ((read = from.read(buffer)) != -1) {
				if (read > 0) {
					to.write(buffer, 0, read);
				}
			}
		} catch (IOException e) {
			Log.w(TAG, "FileUtils.copy()", e);
			throw e;
		} finally {
			closeQuietly(from);
			closeQuietly(to);
		}
	}

	public static void copy(File from, File to) throws
            IOException {
		copy(new FileInputStream(from), new FileOutputStream(to));
	}

	public static void copy(Uri from, Uri to) throws
            IOException {
		copy(uriToFile(from), uriToFile(to));
	}

	public static void copy(File from, Uri to) throws
            IOException {
		copy(from, uriToFile(to));
	}

	public static void copy(Uri from, File to) throws
            IOException {
		copy(uriToFile(from), to);
	}

	/**
	 * <p>
	 * 将一个目录下的文件全部拷贝到另一个目录里面，并且保留文件日期。
	 * </p>
	 * <p>
	 * 如果目标目录不存在，则被创建。 如果目标目录已经存在，则将会合并两个文件夹的内容，若有冲突则替换掉目标目录中的文件。
	 * </p>
	 *
	 * @param srcDir
	 *            源目录，不能为null且必须存在。
	 * @param destDir
	 *            目标目录，不能为null。
	 * @throws NullPointerException
	 *             如果源目录或目标目录为null。
	 * @throws IOException
	 *             如果源目录或目标目录无效。
	 * @throws IOException
	 *             如果拷贝中出现IO错误。
	 */
	public static void copyDirectoryToDirectory(File srcDir, File destDir)
			throws IOException {
		if (srcDir == null) {
			throw new NullPointerException("Source must not be null");
		}
		if (srcDir.exists() && !srcDir.isDirectory()) {
			throw new IllegalArgumentException("Source '" + destDir
					+ "' is not a directory");
		}
		if (destDir == null) {
			throw new NullPointerException("Destination must not be null");
		}
		if (destDir.exists() && !destDir.isDirectory()) {
			throw new IllegalArgumentException("Destination '" + destDir
					+ "' is not a directory");
		}
		copyDirectory(srcDir, new File(destDir, srcDir.getName()), true);
	}

	/**
	 * <p>
	 * 将目录及其以下子目录拷贝到一个新的位置，并且保留文件日期。
	 * <p>
	 * 如果目标目录不存在，则被创建。 如果目标目录已经存在，则将会合并两个文件夹的内容，若有冲突则替换掉目标目录中的文件。
	 * <p>
	 *
	 * @param srcDir
	 *            一个存在的源目录，不能为null。
	 * @param destDir
	 *            新的目录，不能为null。
	 *
	 * @throws NullPointerException
	 *             如果源目录或目标目录为null。
	 * @throws IOException
	 *             如果源目录或目标目录无效。
	 * @throws IOException
	 *             如果拷贝中出现IO错误。
	 */
	public static void copyDirectory(File srcDir, File destDir)
			throws IOException {
		copyDirectory(srcDir, destDir, true);
	}

	/**
	 * 拷贝目录到一个新的位置。
	 * <p>
	 * 该方法将拷贝指定的源目录的所有内容到一个新的目录中。
	 * </p>
	 * <p>
	 * 如果目标目录不存在，则被创建。 如果目标目录已经存在，则将会合并两个文件夹的内容，若有冲突则替换掉目标目录中的文件。
	 * </p>
	 *
	 * @param srcDir
	 *            一个存在的源目录，不能为null。
	 * @param destDir
	 *            新的目录，不能为null。
	 *
	 * @throws NullPointerException
	 *             如果源目录或目标目录为null。
	 * @throws IOException
	 *             如果源目录或目标目录无效。
	 * @throws IOException
	 *             如果拷贝中出现IO错误。
	 */
	public static void copyDirectory(File srcDir, File destDir,
                                     @SuppressWarnings("SameParameterValue") boolean preserveFileDate) throws IOException {
		if (srcDir == null) {
			throw new NullPointerException("Source must not be null");
		}
		if (srcDir.exists() && !srcDir.isDirectory()) {
			throw new IllegalArgumentException("Source '" + destDir
					+ "' is not a directory");
		}
		if (destDir == null) {
			throw new NullPointerException("Destination must not be null");
		}
		if (destDir.exists() && !destDir.isDirectory()) {
			throw new IllegalArgumentException("Destination '" + destDir
					+ "' is not a directory");
		}
		if (srcDir.getCanonicalPath().equals(destDir.getCanonicalPath())) {
			throw new IOException("Source '" + srcDir + "' and destination '"
					+ destDir + "' are the same");
		}

		// 为满足当目标目录在源目录里面的情况。
		List<String> exclusionList = null;
		if (destDir.getCanonicalPath().startsWith(srcDir.getCanonicalPath())) {
			File[] srcFiles = srcDir.listFiles();
			if (srcFiles != null && srcFiles.length > 0) {
				exclusionList = new ArrayList<>(srcFiles.length);
				for (File srcFile : srcFiles) {
					File copiedFile = new File(destDir, srcFile.getName());
					exclusionList.add(copiedFile.getCanonicalPath());
				}
			}
		}

		doCopyDirectory(srcDir, destDir, preserveFileDate, exclusionList);
	}

	/**
	 * Internal copy directory method.
	 *
	 * @param srcDir
	 *            the validated source directory, must not be <code>null</code>
	 * @param destDir
	 *            the validated destination directory, must not be
	 *            <code>null</code>
	 * @param filter
	 *            the filter to apply, null means copy all directories and files
	 * @param preserveFileDate
	 *            whether to preserve the file date
	 * @param exclusionList
	 *            List of files and directories to exclude from the copy, may be
	 *            null
	 * @throws IOException
	 *             if an error occurs
	 * @since Commons IO 1.1
	 */
	@SuppressWarnings("JavadocReference")
    private static void doCopyDirectory(File srcDir, File destDir,
                                        boolean preserveFileDate, List<String> exclusionList)
			throws IOException {
		// recurse
		File[] srcFiles = srcDir.listFiles();
		if (srcFiles == null) { // null if abstract pathname does not denote a
								// directory, or if an I/O error occurs
			throw new IOException("Failed to list contents of " + srcDir);
		}
		if (destDir.exists()) {
			if (!destDir.isDirectory()) {
				throw new IOException("Destination '" + destDir
						+ "' exists but is not a directory");
			}
		} else {
			if (!destDir.mkdirs() && !destDir.isDirectory()) {
				throw new IOException("Destination '" + destDir
						+ "' directory cannot be created");
			}
		}
		if (!destDir.canWrite()) {
			throw new IOException("Destination '" + destDir
					+ "' cannot be written to");
		}
		for (File srcFile : srcFiles) {
			File dstFile = new File(destDir, srcFile.getName());
			if (exclusionList == null
					|| !exclusionList.contains(srcFile.getCanonicalPath())) {
				if (srcFile.isDirectory()) {
					doCopyDirectory(srcFile, dstFile, preserveFileDate,
							exclusionList);
				} else {
					doCopyFile(srcFile, dstFile, preserveFileDate);
				}
			}
		}

		// Do this last, as the above has probably affected directory metadata
		if (preserveFileDate) {
            //noinspection ResultOfMethodCallIgnored
            destDir.setLastModified(srcDir.lastModified());
		}
	}

	/**
	 * Internal copy file method.
	 *
	 * @param srcFile
	 *            the validated source file, must not be <code>null</code>
	 * @param destFile
	 *            the validated destination file, must not be <code>null</code>
	 * @param preserveFileDate
	 *            whether to preserve the file date
	 * @throws IOException
	 *             if an error occurs
	 */
	private static void doCopyFile(File srcFile, File destFile,
			boolean preserveFileDate) throws IOException {
		if (destFile.exists() && destFile.isDirectory()) {
			throw new IOException("Destination '" + destFile
					+ "' exists but is a directory");
		}

		FileInputStream fis = null;
		FileOutputStream fos = null;
		FileChannel input = null;
		FileChannel output = null;
		try {
			fis = new FileInputStream(srcFile);
			fos = new FileOutputStream(destFile);
			input = fis.getChannel();
			output = fos.getChannel();
			long size = input.size();
			long pos = 0;
			long count;
			while (pos < size) {
				count = (size - pos) > COPY_BUFFER_SIZE ? COPY_BUFFER_SIZE
						: (size - pos);
				pos += output.transferFrom(input, pos, count);
			}
		} finally {
			closeQuietly(output);
			closeQuietly(fos);
			closeQuietly(input);
			closeQuietly(fis);
		}

		if (srcFile.length() != destFile.length()) {
			throw new IOException("Failed to copy full contents from '"
					+ srcFile + "' to '" + destFile + "'");
		}
		if (preserveFileDate) {
            //noinspection ResultOfMethodCallIgnored
            destFile.setLastModified(srcFile.lastModified());
		}
	}

	/*
	 * copy function -- end
	 */

	public static File uriToFile(Uri uri) {
		if (ContentResolver.SCHEME_CONTENT.equals(uri.getScheme())) {
			final ContentResolver contentResolver = ApplicationKeeper
					.getApplication().getContentResolver();
			final String[] projection = new String[] { Images.Media.DATA };
			String path = null;
			Cursor cursor = null;
            //noinspection TryFinallyCanBeTryWithResources
            try {
				cursor = contentResolver.query(uri, projection, null, null,
						null);
				if (cursor != null && cursor.moveToNext()) {
					path = cursor.getString(0);
				}
			} finally {
                assert cursor != null;
                cursor.close();
			}
			if (path == null) {
				throw new IllegalArgumentException("not found data.uri=" + uri);
			} else {
				return new File(path);
			}
		} else {
			return new File(uri.getPath());
		}
	}

	/*
	 * delete function -- begin
	 */
	public static boolean deleteFile(final File file) {
        return !(file != null && file.exists()) || file.delete();
    }

	public static void deleteOnRecursive(final File root) {
		if (root == null || !root.exists()) {
			return;
		}
		if (root.isFile()) {
			if (root.exists() && !root.delete()) {
				root.deleteOnExit();
			}
		} else {
			final File[] list = root.listFiles();
			if (list != null) {
                for (File aList : list) {
                    deleteOnRecursive(aList);
                }
			}
			if (root.exists() && !root.delete()) {
				root.deleteOnExit();
			}
		}
	}

	public static void deleteDirectory(final File root,
			final File[] exceptedFolders, final boolean deleteRootDir) {
		if (root == null || !root.exists()) {
			return;
		}
		if (root.isFile()) {
			if (root.exists() && !root.delete()) {
				root.deleteOnExit();
			}
		} else {
			if (exceptedFolders != null) {
				for (File exceptedFolder : exceptedFolders) {
					if (root.equals(exceptedFolder)) {
						return;
					}
				}
			}
			final File[] list = root.listFiles();
			if (list != null) {
                for (File aList : list) {
                    deleteDirectory(aList, exceptedFolders, true);
                }
			}
			if (deleteRootDir) {
				if (root.exists() && !root.delete()) {
					root.deleteOnExit();
				}
			}
		}

    }

	public static void deleteDirectory(final File root,
			final boolean deleteRootDir) {
		deleteDirectory(root, null, deleteRootDir);
	}

	/*
	 * delete function -- end
	 */

	// Android/data/packageName
	public static String getExternalFilesDirName(Context context) {
        return "Android" + File.separatorChar + "data" +
                File.separatorChar + context.getPackageName();
	}

	public static File getBaseDirectory()
			throws NotAvailableExternalStorageException {
		return getBaseDirectory(ApplicationKeeper.getApplication());
	}

	// sdcard/Android/data/packageName
	public static File getBaseDirectory(final Context context)
			throws NotAvailableExternalStorageException {
		final String packageName = context.getPackageName();
		final File targetDir = new File(
				Environment.getExternalStorageDirectory(),
				FileUtils.getExternalFilesDirName(context));
		if (!targetDir.exists()) {
			final File androidDir = new File(
					Environment.getExternalStorageDirectory(), "Android");
			mkdirToExternalStorage(androidDir, false);

			final File dataDir = new File(androidDir, "data");
			mkdirToExternalStorage(dataDir, false);

			final File packageDir = new File(dataDir, packageName);
			mkdirToExternalStorage(packageDir, false);

			final File nomediaFile = new File(packageDir, ".nomedia");
			try {
                //noinspection ResultOfMethodCallIgnored
                nomediaFile.createNewFile();
			} catch (IOException e) {
				// do nothing.
			}

			return packageDir;
		} else {
			return targetDir;
		}
	}

	public static void mkdirToExternalStorage(final File directory,
                                              @SuppressWarnings("SameParameterValue") final boolean force) throws NotAvailableExternalStorageException {

		if (!directory.exists() && !directory.mkdir()) {
			throw new NotAvailableExternalStorageException("failed mkdir.(path = " +
                    directory.getAbsolutePath() + ")");
		} else if (!directory.isDirectory()) {
			if (force) {
				if (!directory.delete() && !directory.mkdir()) {
					throw new NotAvailableExternalStorageException(
                            "failed mkdir. exists file.(path = " +
                                    directory.getAbsolutePath() +
                                    ")");
				}
			} else {
				throw new NotAvailableExternalStorageException(
                        "failed mkdir. exists file.(path = " +
                                directory.getAbsolutePath() +
                                ")");
			}
		}
	}

	public static String getFileExtensionFromUrl(String url) {
		if (!TextUtils.isEmpty(url)) {
			int fragment = url.lastIndexOf('#');
			if (fragment > 0) {
				url = url.substring(0, fragment);
			}

			int query = url.lastIndexOf('?');
			if (query > 0) {
				url = url.substring(0, query);
			}

			int filenamePos = url.lastIndexOf(File.separator);
			String filename = (0 <= filenamePos) ? url
					.substring(filenamePos + 1) : url;

			if (!TextUtils.isEmpty(filename)) {
				int dotPos = filename.lastIndexOf('.');
				if (0 <= dotPos) {
					return filename.substring(dotPos + 1);
				}
			}
		}

		return "";
	}

	public static String getFileNameFromUrl(String url) {
		if (!TextUtils.isEmpty(url)) {
			int fragment = url.lastIndexOf('#');
			if (fragment > 0) {
				url = url.substring(0, fragment);
			}

			int query = url.lastIndexOf('?');
			if (query > 0) {
				url = url.substring(0, query);
			}

			int filenamePos = url.lastIndexOf(File.separator);
            return (0 <= filenamePos) ? url
                    .substring(filenamePos + 1) : url;
		}

		return "";
	}

	public static List<File> getSortedFileList(final File rootDir,
			final boolean ignoreHiddenFile) {
		final List<File> list = getFileList(rootDir, ignoreHiddenFile);
		Collections.sort(list, new Comparator<File>() {
			@Override
			public int compare(File lhs, File rhs) {
				return lhs.getAbsolutePath().compareTo(rhs.getAbsolutePath());
			}
		});
		return list;
	}

	public static List<File> getFileList(final File rootDir,
			final boolean ignoreHiddenFile) {
		final List<File> list = new ArrayList<>();
		final File[] files = rootDir.listFiles();
		for (File file : files) {
			if (file.isHidden() && ignoreHiddenFile) {
                //noinspection UnnecessaryContinue
                continue;
			} else if (file.isDirectory()) {
				list.addAll(getFileList(file, ignoreHiddenFile));
			} else if (file.isFile()) {
				list.add(file);
			}
		}
		return list;
	}

	public static long getUncompressedSize(final File file)
			throws IOException {
		long totalSize = 0;
		final ZipFile zipFile = new ZipFile(file);
		final Enumeration<? extends ZipEntry> entries = zipFile.entries();
		while (entries.hasMoreElements()) {
			ZipEntry entry = entries.nextElement();
			totalSize += entry.getSize();
		}

		return totalSize;
	}

	/**
	 * Unconditionally close a <code>Closeable</code>.
	 * <p>
	 * Equivalent to {@link Closeable#close()}, except any exceptions will be
	 * ignored. This is typically used in finally blocks.
	 * <p>
	 * Example code:
	 *
	 * <pre>
	 * Closeable closeable = null;
	 * try {
	 * 	closeable = new FileReader(&quot;foo.txt&quot;);
	 * 	// process closeable
	 * 	closeable.close();
	 * } catch (Exception e) {
	 * 	// error handling
	 * } finally {
	 * 	IOUtils.closeQuietly(closeable);
	 * }
	 * </pre>
	 *
	 * @param closeable
	 *            the object to close, may be null or already closed
	 * @since Commons IO 2.0
	 */
	public static void closeQuietly(Closeable closeable) {
		if (closeable != null) {
			try {
				closeable.close();
			} catch (IOException ioe) {
				// ignore
			}
		}
	}

    public static class ExternalStorageException extends Exception {
        private static final long serialVersionUID = -1698082590955363600L;

        public ExternalStorageException() {
            super();
        }

        public ExternalStorageException(String detailMessage, Throwable throwable) {
            super(detailMessage, throwable);
        }

        public ExternalStorageException(String detailMessage) {
            super(detailMessage);
        }

        public ExternalStorageException(Throwable throwable) {
            super(throwable);
        }
    }

    public static class NotAvailableExternalStorageException extends ExternalStorageException {
        private static final long serialVersionUID = -1698082590955363600L;

        public NotAvailableExternalStorageException() {
            super();
        }

        public NotAvailableExternalStorageException(String detailMessage, Throwable throwable) {
            super(detailMessage, throwable);
        }

        public NotAvailableExternalStorageException(String detailMessage) {
            super(detailMessage);
        }

        public NotAvailableExternalStorageException(Throwable throwable) {
            super(throwable);
        }
    }


	public static String getMimeType(String filename) {
		if (TextUtils.isEmpty(filename)) {
			return null;
		}
		int lastDotIndex = filename.lastIndexOf('.');
		String mimeType =
				MimeTypeMap.getSingleton()
						.getMimeTypeFromExtension(
								filename.substring(lastDotIndex + 1).toLowerCase());
		LogUtils.d(TAG, "getFileMimeType: mimeType = " + mimeType);
		return mimeType;
	}

	/**
	 * This method gets extension of certain file.
	 *
	 * @param fileName name of a file
	 * @return Extension of the file's name
	 */
	public static String getExtension(String fileName) {
		if (fileName == null) {
			return null;
		}
		String extension = null;
		final int lastDot = fileName.lastIndexOf('.');
		if ((lastDot >= 0)) {
			extension = fileName.substring(lastDot + 1).toLowerCase();
		}
		return extension;
	}

	/**
	 * This method gets name of certain file from its path.
	 *
	 * @param absolutePath the file's absolute path
	 * @return name of the file
	 */
	public static String getName(String absolutePath) {
		int sepIndex = absolutePath.lastIndexOf(File.separator);
		if (sepIndex >= 0) {
			return absolutePath.substring(sepIndex + 1);
		}
		return absolutePath;

	}

	/**
	 * This method gets path to directory of certain file(or folder).
	 *
	 * @param filePath path to certain file
	 * @return path to directory of the file
	 */
	public static String getPath(String filePath) {
		int sepIndex = filePath.lastIndexOf(File.separator);
		if (sepIndex >= 0) {
			return filePath.substring(0, sepIndex);
		}
		return "";
	}

    /**
     * This method gets size to directory of certain file(or folder).
     */
    public static String getSize(Context context, File file) {
        return Formatter.formatFileSize(context, file.length());
    }

	/**
	 * This method generates a new suffix if a name conflict occurs, ex: paste a file named
	 * "stars.txt", the target file name would be "stars(1).txt"
	 *
	 * @param file the conflict file
	 * @return a new name for the conflict file
	 */

	public static File generateNextNewName(File file) {
		String parentDir = file.getParent();
		String fileName = file.getName();
		String ext = "";
		int newNumber = 0;
		if (file.isFile()) {
			int extIndex = fileName.lastIndexOf(".");
			if (extIndex != -1) {
				ext = fileName.substring(extIndex);
				fileName = fileName.substring(0, extIndex);
			}
		}

		if (fileName.endsWith(")")) {
			int leftBracketIndex = fileName.lastIndexOf("(");
			if (leftBracketIndex != -1) {
				String numeric = fileName.substring(leftBracketIndex + 1, fileName.length() - 1);
				if (numeric.matches("[0-9]+")) {
					LogUtils.v(TAG, "Conflict folder name already contains (): " + fileName
							+ "thread id: " + Thread.currentThread().getId());
					try {
						newNumber = Integer.parseInt(numeric);
						newNumber++;
						fileName = fileName.substring(0, leftBracketIndex);
					} catch (NumberFormatException e) {
						LogUtils.e(TAG, "Fn-findSuffixNumber(): " + e.toString());
					}
				}
			}
		}
		StringBuilder sb = new StringBuilder();
		sb.append(fileName).append("(").append(newNumber).append(")").append(ext);
		if (FileUtils.checkFileName(sb.toString()) < 0) {
			return null;
		}
		return new File(parentDir, sb.toString());
	}

	/**
	 * This method check the file name is valid.
	 */
	public static final int ERROR_CODE_NAME_VALID = 100;
	public static final int ERROR_CODE_NAME_EMPTY = -1;
	public static final int ERROR_CODE_NAME_TOO_LONG = -2;
	/** File name's max length */
	public static final int FILENAME_MAX_LENGTH = 255;

	public static int checkFileName(String fileName) {
		if (TextUtils.isEmpty(fileName) || fileName.trim().length() == 0) {
			return ERROR_CODE_NAME_EMPTY;
		} else {
			try {
				int length = fileName.getBytes("UTF-8").length;
				// int length = fileName.length();
				LogUtils.d(TAG, "checkFileName: " + fileName + ",lenth= " + length);
				if (length > FILENAME_MAX_LENGTH) {
					LogUtils.d(TAG, "checkFileName,fileName is too long,len=" + length);
					return ERROR_CODE_NAME_TOO_LONG;
				} else {
					return ERROR_CODE_NAME_VALID;
				}
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
				return ERROR_CODE_NAME_EMPTY;
			}
		}
	}

	/**
	 * 根据文件路径获取文件
	 *
	 * @param filePath 文件路径
	 * @return 文件
	 */
	public static File getFileByPath(String filePath) {
		return TextUtils.isEmpty(filePath) ? null : new File(filePath);
	}

	/**
	 * 判断目录是否存在，不存在则判断是否创建成功
	 *
	 * @param file 文件
	 * @return {@code true}: 存在或创建成功<br>{@code false}: 不存在或创建失败
	 */
	public static boolean createOrExistsDir(File file) {
		// 如果存在，是目录则返回true，是文件则返回false，不存在则返回是否创建成功
		return file != null && (file.exists() ? file.isDirectory() : file.mkdirs());
	}



	/**
	 * 判断文件是否存在，不存在则判断是否创建成功
	 *
	 * @param filePath 文件路径
	 * @return {@code true}: 存在或创建成功<br>{@code false}: 不存在或创建失败
	 */
	public static boolean createOrExistsFile(String filePath) {
		return createOrExistsFile(getFileByPath(filePath));
	}

	/**
	 * 判断文件是否存在，不存在则判断是否创建成功
	 *
	 * @param file 文件
	 * @return {@code true}: 存在或创建成功<br>{@code false}: 不存在或创建失败
	 */
	public static boolean createOrExistsFile(File file) {
		if (file == null) return false;
		// 如果存在，是文件则返回true，是目录则返回false
		if (file.exists()) return file.isFile();
		if (!createOrExistsDir(file.getParentFile())) return false;
		try {
			return file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	public static String getRealFilePath( final Context context, final Uri uri) {
		if ( null == uri ) return null;
		final String scheme = uri.getScheme();
		String data = null;
		if ( scheme == null )
			data = uri.getPath();
		else if ( ContentResolver.SCHEME_FILE.equals(scheme) ) {
			data = uri.getPath();
		} else if ( ContentResolver.SCHEME_CONTENT.equals( scheme ) ) {
			Cursor cursor = context.getContentResolver().query(uri, new String[] { ImageColumns.DATA }, null, null, null);
			if ( null != cursor ) {
				if ( cursor.moveToFirst() ) {
					int index = cursor.getColumnIndex(ImageColumns.DATA);
					if ( index > -1 ) {
						data = cursor.getString( index );
					}
				}
				cursor.close();
			}
		}
		return data;
	}

}
