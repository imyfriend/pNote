package iyf.exdroid.support.common.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Outline;
import android.graphics.Paint;
import android.os.Build;
import android.support.annotation.LayoutRes;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.TextView;


@SuppressWarnings("unused")
public final class ViewUtils {
    private static final String TAG = "ViewUtils";

    private ViewUtils() {
    }

    /**
     * Returns a boolean indicating whether or not the view's layout direction is RTL
     *
     * @param view - A valid view
     * @return True if the view's layout direction is RTL
     */
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @SuppressWarnings("unused")
    public static boolean isLayoutRtl(View view) {
        return view.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
    }

    @SuppressWarnings("unused")
    @RequiresApi(api =Build.VERSION_CODES.JELLY_BEAN)
    public static void resizeText(TextView textView, int originalTextSize, int minTextSize) {
        final Paint paint = textView.getPaint();
        final int width = textView.getWidth();
        if (width == 0) return;
        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, originalTextSize);
        float ratio = width / paint.measureText(textView.getText().toString());
        if (ratio <= 1.0f) {
            textView.setTextSize(TypedValue.COMPLEX_UNIT_PX,
                    Math.max(minTextSize, originalTextSize * ratio));
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public static void adjustText(TextView textView) {
        if (null != textView) {
            Paint.FontMetrics fm = textView.getPaint().getFontMetrics();
            float topDiff = Math.abs(fm.ascent - fm.top);
            float bottomDiff = Math.abs(fm.descent - fm.bottom);
            float leading = fm.leading;

            float lineSpacingExtra = textView.getLineSpacingExtra();
            float lineSpacingMultiplier = textView.getLineSpacingMultiplier();

            Log.d(TAG, "adjustText: fm.ascent=" + fm.ascent + ", fm.top=" + fm.top
                    + ", fm.descent=" + fm.descent + ", fm.bottom=" + fm.bottom + ", fm.leading=" + fm.leading
                    + ", topDiff=" + topDiff + ", bottomDiff=" + bottomDiff
                    + ", lineSpacingExtra=" + lineSpacingExtra + ", lineSpacingMultiplier=" + lineSpacingMultiplier);
            float lineSpacing = lineSpacingExtra*lineSpacingMultiplier;
            if (leading <= lineSpacing) {
                lineSpacing -= leading;
                textView.setLineSpacing(lineSpacing, 1);
            }

            int topPadding = textView.getPaddingTop();
            if (topDiff <= topPadding) {
               topPadding -= topDiff;
                topDiff = 0;
            } else {
                topPadding = 0;
                topDiff -= topPadding;
            }

            int bottomPadding = textView.getPaddingBottom();
            if (bottomDiff <= bottomPadding) {
                bottomPadding -= bottomDiff;
                bottomDiff = 0;
            } else {
                bottomPadding = 0;
                bottomDiff -= bottomPadding;
            }
            textView.setPadding(textView.getPaddingLeft(), topPadding,
                    textView.getPaddingRight(), bottomPadding);

            ViewGroup.LayoutParams lp = textView.getLayoutParams();
            if (lp instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams)lp;
                Log.d(TAG, "mlp.topMargin=" + mlp.topMargin + ", mlp.bottomMargin=" + mlp.bottomMargin);
                if (topDiff <= mlp.topMargin) {
                    mlp.topMargin -= topDiff;
                }
                if (bottomDiff <= mlp.bottomMargin) {
                    mlp.bottomMargin -= bottomDiff;
                }
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public static void adjustText(TextView textView, ViewGroup.MarginLayoutParams marginLayoutParams) {
        if (null != textView) {
            Paint.FontMetrics fm = textView.getPaint().getFontMetrics();
            float topDiff = Math.abs(fm.ascent - fm.top);
            float bottomDiff = Math.abs(fm.descent - fm.bottom);
            float leading = fm.leading;

            float lineSpacingExtra = textView.getLineSpacingExtra();
            float lineSpacingMultiplier = textView.getLineSpacingMultiplier();

            Log.d(TAG, "adjustText: fm.ascent=" + fm.ascent + ", fm.top=" + fm.top
                    + ", fm.descent=" + fm.descent + ", fm.bottom=" + fm.bottom + ", fm.leading=" + fm.leading
                    + ", topDiff=" + topDiff + ", bottomDiff=" + bottomDiff
                    + ", lineSpacingExtra=" + lineSpacingExtra + ", lineSpacingMultiplier=" + lineSpacingMultiplier);
            float lineSpacing = lineSpacingExtra*lineSpacingMultiplier;
            if (leading <= lineSpacing) {
                lineSpacing -= leading;
                textView.setLineSpacing(lineSpacing, 1);
            }

            int topPadding = textView.getPaddingTop();
            int bottomPadding = textView.getPaddingBottom();
            Log.d(TAG, "topPadding=" + topPadding + ", bottomPadding=" + bottomPadding);

            if (topDiff <= topPadding) {
                topPadding -= topDiff;
                topDiff = 0;
            } else {
                topPadding = 0;
                topDiff -= topPadding;
            }

            if (bottomDiff <= bottomPadding) {
                bottomPadding -= bottomDiff;
                bottomDiff = 0;
            } else {
                bottomPadding = 0;
                bottomDiff -= bottomPadding;
            }

            textView.setPadding(textView.getPaddingLeft(), topPadding,
                    textView.getPaddingRight(), bottomPadding);

            if (null != marginLayoutParams) {
                Log.d(TAG, "marginLayoutParams.topMargin=" + marginLayoutParams.topMargin
                        + ", marginLayoutParams.bottomMargin=" + marginLayoutParams.bottomMargin);
                if (topDiff <= marginLayoutParams.topMargin) {
                    marginLayoutParams.topMargin -= topDiff;
                }
                if (bottomDiff <= marginLayoutParams.bottomMargin) {
                    marginLayoutParams.bottomMargin -= bottomDiff;
                }
            }
        }
    }

    /**
     * ***********************************************************
     * findViewById的一种更优雅的写法
     * 原理:泛型的类型推断
     * ***********************************************************
     */
    public static <T extends View> T findViewById(Activity activity, int viewId) {
        //noinspection unchecked
        return (T) activity.findViewById(viewId);
    }

    public static <T extends View> T findViewById(View view, int viewId) {
        //noinspection unchecked
        return (T) view.findViewById(viewId);
    }

    public static <T extends View> T findViewById(Dialog dialog, int viewId) {
        //noinspection unchecked
        return (T) dialog.findViewById(viewId);
    }

    /** Runs a piece of code after the next layout run */
    public static void doAfterLayout(final View view, final Runnable runnable) {
        final ViewTreeObserver.OnGlobalLayoutListener listener = new ViewTreeObserver.OnGlobalLayoutListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onGlobalLayout() {
                // Layout pass done, unregister for further events
                view.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                runnable.run();
            }
        };
        view.getViewTreeObserver().addOnGlobalLayoutListener(listener);
    }

    /** Runs a piece of code just before the next draw, after layout and measurement */
    public static void doOnPreDraw(final View view, final boolean drawNextFrame,
                                   final Runnable runnable) {
        final ViewTreeObserver.OnPreDrawListener listener = new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                view.getViewTreeObserver().removeOnPreDrawListener(this);
                runnable.run();
                return drawNextFrame;
            }
        };
        view.getViewTreeObserver().addOnPreDrawListener(listener);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private static final ViewOutlineProvider OVAL_OUTLINE_PROVIDER = new ViewOutlineProvider() {
        @Override
        public void getOutline(View view, Outline outline) {
            outline.setOval(0, 0, view.getWidth(), view.getHeight());
        }
    };

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private static final ViewOutlineProvider RECT_OUTLINE_PROVIDER = new ViewOutlineProvider() {
        @Override
        public void getOutline(View view, Outline outline) {
            outline.setRect(0, 0, view.getWidth(), view.getHeight());
        }
    };

    /**
     * Adds a rectangular outline to a view. This can be useful when you want to add a shadow
     * to a transparent view. See b/16856049.
     * @param view view that the outline is added to
     * @param res The resources file.
     */
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static void addRectangularOutlineProvider(View view, Resources res) {
        view.setOutlineProvider(RECT_OUTLINE_PROVIDER);
    }

    /**
     * Configures the floating action button, clipping it to a circle and setting its translation z.
     * @param view The float action button's view.
     * @param translationZ translationZ.
     */
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static void setupFloatingActionButton(View view, float translationZ) {
        view.setOutlineProvider(OVAL_OUTLINE_PROVIDER);
        view.setTranslationZ(translationZ);
    }

    /**
     * 执行测量，执行完成之后只需调用View的getMeasuredXXX()方法即可获取测量结果
     */
    public static final View measure(View view) {
        ViewGroup.LayoutParams p = view.getLayoutParams();
        if (p == null) {
            p = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        int childWidthSpec = ViewGroup.getChildMeasureSpec(0, 0 + 0, p.width);
        int lpHeight = p.height;
        int childHeightSpec;
        if (lpHeight > 0) {
            childHeightSpec = View.MeasureSpec.makeMeasureSpec(lpHeight,
                    View.MeasureSpec.EXACTLY);
        } else {
            childHeightSpec = View.MeasureSpec.makeMeasureSpec(0,
                    View.MeasureSpec.UNSPECIFIED);
        }
        view.measure(childWidthSpec, childHeightSpec);
        return view;
    }

    public static View inflateLayout(View view, @LayoutRes int resId) {
        return LayoutInflater.from(view.getContext()).inflate(resId, view instanceof ViewGroup ? (ViewGroup) view : new FrameLayout(view.getContext()), false);
    }

    public static View inflateLayout(Activity activity, @LayoutRes int resId) {
        return LayoutInflater.from(activity).inflate(resId, (ViewGroup) activity.getWindow().getDecorView(), false);
    }

    public static View inflateLayout(Window window, @LayoutRes int resId) {
        return LayoutInflater.from(window.getContext()).inflate(resId, (ViewGroup) window.getDecorView(), false);
    }

    public static View inflateLayout(Dialog dialog, @LayoutRes int resId) {
        return inflateLayout(dialog.getWindow(), resId);
    }

    public static View inflateLayout(Context context, @LayoutRes int resId) {
        return LayoutInflater.from(context).inflate(resId, new FrameLayout(context), false);
    }

    public static View attachLayout(ViewGroup viewGroup, @LayoutRes int resId) {
        return LayoutInflater.from(viewGroup.getContext()).inflate(resId, viewGroup, true);
    }

}
