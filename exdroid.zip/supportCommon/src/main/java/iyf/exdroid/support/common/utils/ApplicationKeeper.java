package iyf.exdroid.support.common.utils;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

@SuppressWarnings({"WeakerAccess", "unused"})
public class ApplicationKeeper {
	@SuppressLint("StaticFieldLeak")
	private static Application app = null;
	private static HomeKeyEventBroadCastReceiver homeKeyReceiver;
	private static PowerKeyEventBroadCastReceiver powerKeyReceiver;

	public static synchronized void attach(Application application) {
		app = application;
		
		if (app != null) {
			homeKeyReceiver = new HomeKeyEventBroadCastReceiver();
			app.registerReceiver(homeKeyReceiver, new IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS));
			
			powerKeyReceiver = new PowerKeyEventBroadCastReceiver();
			IntentFilter filter = new IntentFilter();
			filter.addAction(Intent.ACTION_SCREEN_OFF);
			filter.addAction(Intent.ACTION_SCREEN_ON);
			app.registerReceiver(powerKeyReceiver, filter);
		}
	}

	public static synchronized void detach() {
		if (app != null) {
			try {
				if (homeKeyReceiver != null) {
					app.unregisterReceiver(homeKeyReceiver);
				}
				if (powerKeyReceiver != null) {
					app.unregisterReceiver(powerKeyReceiver);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		app = null;
	}

	public static synchronized Application getApplication() {
		if (app != null) {
			return app;
		} else {
			throw new RuntimeException("Application is not loaded");
		}
	}
	
	public static synchronized void setOnHomeKeyEventListener(OnHomeKeyEventListener listener) {
		if (homeKeyReceiver != null) {
			homeKeyReceiver.setOnHomeKeyEventListener(listener);
		}
	}
	
	public static synchronized void setOnPowerKeyEventListener(OnPowerKeyEventListener listener) {
		if (powerKeyReceiver != null) {
			powerKeyReceiver.setOnPowerKeyEventListener(listener);
		}
	}
	
	public interface OnHomeKeyEventListener {
		void onHomeKey();
		void onLongHomeKey();
	}

	private static class HomeKeyEventBroadCastReceiver extends BroadcastReceiver {  
		  
	    static final String SYSTEM_REASON = "reason";  
	    static final String SYSTEM_HOME_KEY = "homekey"; // home key  
	    static final String SYSTEM_RECENT_APPS = "recentapps"; // long home key  
	    
	    private OnHomeKeyEventListener listener;
	      
	    @Override  
	    public void onReceive(Context context, Intent intent) {  
	        String action = intent.getAction();  
	        if (action.equals(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)) {  
	            String reason = intent.getStringExtra(SYSTEM_REASON);  
	            if (reason != null) {  
	                if (reason.equals(SYSTEM_HOME_KEY)) {  
	                	if (listener != null) {
	                		listener.onHomeKey();
	                	}
	                } else if (reason.equals(SYSTEM_RECENT_APPS)) {
	                	if (listener != null) {
	                		listener.onLongHomeKey();
	                	}
	                }
	            }  
	        }  
	    }  
	    
	    public void setOnHomeKeyEventListener(OnHomeKeyEventListener listener) {
	    	this.listener = listener;
	    }
	}  
	
	public interface OnPowerKeyEventListener {
		void onScreenOff();
		void onScreenOn();
	}
	
	private static class PowerKeyEventBroadCastReceiver extends BroadcastReceiver {

		private OnPowerKeyEventListener listener;
		
		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			if (Intent.ACTION_SCREEN_OFF.equals(action)) {
				if (listener != null) {
					listener.onScreenOff();
				}
			} else if (Intent.ACTION_SCREEN_ON.equals(action)) {
				if (listener != null) {
					listener.onScreenOn();
				}
			}
			
		}  
		
		public void setOnPowerKeyEventListener(OnPowerKeyEventListener listener) {
			this.listener = listener;
		}
		
	}
}
