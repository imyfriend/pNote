package iyf.exdroid.support.common.utils;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.support.v4.content.LocalBroadcastManager;

/**
 * 类名称：PermissionUtils
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/4/20
 * 修改者， 修改日期， 修改内容
 */
public class PermissionUtils {
    /*
     * manifest中Normal Protection权限的判断。只要在Manifest指定了这些权限，就会被授予，并且不能撤销。
     * 正常权限具有如下的几个特点：
        1. 对用户隐私没有较大影响或者不会打来安全问题。
        2. 安装后就赋予这些权限，不需要显示提醒用户，用户也不能取消这些权限。

        正常权限列表：
        ACCESS_LOCATION_EXTRA_COMMANDS
        ACCESS_NETWORK_STATE
        ACCESS_NOTIFICATION_POLICY
        ACCESS_WIFI_STATE
        BLUETOOTH
        BLUETOOTH_ADMIN
        BROADCAST_STICKY
        CHANGE_NETWORK_STATE
        CHANGE_WIFI_MULTICAST_STATE
        CHANGE_WIFI_STATE
        DISABLE_KEYGUARD
        EXPAND_STATUS_BAR
        GET_PACKAGE_SIZE
        INTERNET
        KILL_BACKGROUND_PROCESSES
        MODIFY_AUDIO_SETTINGS
        NFC
        READ_SYNC_SETTINGS
        READ_SYNC_STATS
        RECEIVE_BOOT_COMPLETED
        REORDER_TASKS
        REQUEST_INSTALL_PACKAGES
        SET_TIME_ZONE
        SET_WALLPAPER
        SET_WALLPAPER_HINTS
        TRANSMIT_IR
        USE_FINGERPRINT
        VIBRATE
        WAKE_LOCK
        WRITE_SYNC_SETTINGS
        SET_ALARM
        INSTALL_SHORTCUT
        UNINSTALL_SHORTCUT
     */
    public static boolean hasPermission(Context context, String permission) {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
        } else {
            return context.checkPermission(permission, Process.myPid(), Process.myUid()) == PackageManager.PERMISSION_GRANTED;
        }
    }

    /*
      特殊权限，顾名思义，就是一些特别敏感的权限，在Android系统中，主要由两个
      1、SYSTEM_ALERT_WINDOW，设置悬浮窗，进行一些黑科技
      2、WRITE_SETTINGS 修改系统设置
      关于上面两个特殊权限的授权，做法是启动授权界面来完成。
      注意：上述仍需在manifest中声明
     */

    /*
     * <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
     * 备注：即使获得OVERLAY_PERMISSION权限，使用hasPermission检查SYSTEM_ALERT_WINDOW也是false
     */
    public static final int REQUEST_CODE_OVERLAY_PERMISSION = 0x0A00;
    public static boolean hasOverlayPermission(Context context) {
        boolean hasPermission = false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(context)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                           Uri.parse("package:" + context.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (context instanceof Activity) {
                    ((Activity)context).startActivityForResult(intent, REQUEST_CODE_OVERLAY_PERMISSION);
                } else {
                    context.startActivity(intent);
                }
            } else {
                hasPermission = true;
            }
        }
        return hasPermission;
    }

    /*
     *  <uses-permission android:name="android.permission.WRITE_SETTINGS"/>
     */
    public static final int REQUEST_CODE_WRITE_SETTINGS = 0x0B00;
    public static boolean hasWriteSettingsPermission(Context context) {
        boolean hasPermission = false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.System.canWrite(context)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                                           Uri.parse("package:" + context.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (context instanceof Activity) {
                    ((Activity)context).startActivityForResult(intent, REQUEST_CODE_WRITE_SETTINGS);
                } else {
                    context.startActivity(intent);
                }
            } else {
                hasPermission = true;
            }
        }
        return hasPermission;
    }

    /*
    危险权限实际上才是运行时权限主要处理的对象，这些权限可能引起隐私问题或者影响其他程序运行。
    Android中的危险权限可以归为以下几个分组：
    CALENDAR                        READ_CALENDAR
                                                WRITE_CALENDAR
    -------------------------------------------------------
    CAMERA                            CAMERA
    -------------------------------------------------------
    CONTACTS                        READ_CONTACTS
                                                WRITE_CONTACTS
    -------------------------------------------------------
    LOCATION                         ACCESS_FINE_LOCATION
                                                ACCESS_COARSE_LOCATION
    -------------------------------------------------------
    MICROPHONE                  RECORD_AUDIO
    -------------------------------------------------------
    PHONE                               READ_PHONE_STATE
                                                CALL_PHONE
                                                READ_CALL_LOG
                                                WRITE_CALL_LOG
                                                ADD_VOICEMAIL
                                                USE_SIP
                                                PROCESS_OUTGOING_CALLS
    -------------------------------------------------------
    SENSORS                            BODY_SENSORS
    -------------------------------------------------------
    SMS                                    SEND_SMS
                                                RECEIVE_SMS
                                                READ_SMS
                                                RECEIVE_WAP_PUSH
                                                RECEIVE_MMS
    -------------------------------------------------------
    STORAGE                           READ_EXTERNAL_STORAGE
                                                WRITE_EXTERNAL_STORAGE
    -------------------------------------------------------
     */
    /**
     * Rudimentary methods wrapping the use of a LocalBroadcastManager to simplify the process
     * of notifying other classes when a particular fragment is notified that a permission is
     * granted.
     *
     * To be notified when a permission has been granted, create a new broadcast receiver
     * and register it using {@link #registerPermissionReceiver(Context, BroadcastReceiver, String)}
     *
     * E.g.
     *
     * final BroadcastReceiver receiver = new BroadcastReceiver() {
     *     @Override
     *     public void onReceive(Context context, Intent intent) {
     *         refreshContactsView();
     *     }
     * }
     *
     * PermissionsUtil.registerPermissionReceiver(getActivity(), receiver, READ_CONTACTS);
     *
     * If you register to listen for multiple permissions, you can identify which permission was
     * granted by inspecting {@link Intent#getAction()}.
     *
     * In the fragment that requests for the permission, be sure to call
     * {@link #notifyPermissionGranted(Context, String)} when the permission is granted so that
     * any interested listeners are notified of the change.
     */
    public static void registerPermissionReceiver(Context context, BroadcastReceiver receiver,
                                                  String permission) {
        final IntentFilter filter = new IntentFilter(permission);
        LocalBroadcastManager.getInstance(context).registerReceiver(receiver, filter);
    }

    public static void unregisterPermissionReceiver(Context context, BroadcastReceiver receiver) {
        LocalBroadcastManager.getInstance(context).unregisterReceiver(receiver);
    }

    public static void notifyPermissionGranted(Context context, String permission) {
        final Intent intent = new Intent(permission);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }


}
