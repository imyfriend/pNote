package iyf.exdroid.support.common.utils;

import android.content.Context;
import android.os.PowerManager;

/**
 * 类名称：WakeLockUtils
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/23
 * 修改者， 修改日期， 修改内容
 */
public class WakeLockUtils {
    /**
     * The Wake lock.
     */
    private static PowerManager.WakeLock wakeLock;

    private WakeLockUtils() {
        throw new UnsupportedOperationException(
                "Should not create instance of Util class. Please use as static..");
    }

    /**
     * Hold wake lock.
     *
     * @param context
     *     the context
     */
    public static void holdWakeLock(Context context) {
        PowerManager powerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyWakeLock");
        wakeLock.acquire();
    }

    /**
     * Release wake lock.
     */
    public static void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
    }
}
