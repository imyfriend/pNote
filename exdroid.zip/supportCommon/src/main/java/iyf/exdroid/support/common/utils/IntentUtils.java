package iyf.exdroid.support.common.utils;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.provider.Contacts;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.telecom.PhoneAccount;
import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.telecom.VideoProfile;
import android.text.TextUtils;
import android.util.Log;

import java.io.File;
import java.util.List;

import static iyf.exdroid.support.common.utils.CallUtils.DIAL_NUMBER_INTENT_IMS;
import static iyf.exdroid.support.common.utils.CallUtils.DIAL_NUMBER_INTENT_IP;
import static iyf.exdroid.support.common.utils.CallUtils.DIAL_NUMBER_INTENT_VIDEO;
import static iyf.exdroid.support.common.utils.CallUtils.EXTRA_CALL_ORIGIN;
import static iyf.exdroid.support.common.utils.CallUtils.EXTRA_IS_IMS_CALL;
import static iyf.exdroid.support.common.utils.CallUtils.EXTRA_IS_IP_DIAL;
import static iyf.exdroid.support.common.utils.CallUtils.EXTRA_IS_VIDEO_CALL;

/**
 * 类名称：IntentUtils
 * 作者：David
 * 内容摘要：Utilities for creation of intents in Dialer, such as {@link Intent#ACTION_CALL}.
 * 创建日期：2016/12/21
 * 修改者， 修改日期， 修改内容
 */
public class IntentUtils {
    public static final String CALL_ACTION = Intent.ACTION_CALL;

    private static final String SMS_URI_PREFIX = "sms:";
    private static final int NO_PHONE_TYPE = -1;

    /**
     *  common function
     */
    public static boolean hasIntentHandler(Context context, Intent intent) {
        final List<ResolveInfo> resolveInfo = context.getPackageManager()
                .queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        return resolveInfo != null && resolveInfo.size() > 0;
    }

    /**
     * Returns a copy of {@param intent} with a class name set, if a class inside this app
     * has a corresponding intent filter.
     */
    private static Intent getIntentInAppIfExists(Context context, Intent intent) {
        try {
            final Intent intentCopy = new Intent(intent);
            // Force this intentCopy to open inside the current app.
            intentCopy.setPackage(context.getPackageName());
            final List<ResolveInfo> list = context.getPackageManager().queryIntentActivities(
                    intentCopy, PackageManager.MATCH_DEFAULT_ONLY);
            if (list != null && list.size() != 0) {
                // Now that we know the intentCopy will work inside the current app, we
                // can return this intent non-null.
                if (list.get(0).activityInfo != null
                        && !TextUtils.isEmpty(list.get(0).activityInfo.name)) {
                    // Now that we know the class name, we may as well attach it to intentCopy
                    // to prevent the package manager from needing to find it again inside
                    // startActivity(). This is only needed for efficiency.
                    intentCopy.setClassName(context.getPackageName(),
                            list.get(0).activityInfo.name);
                }
                return intentCopy;
            }
            return null;
        } catch (Exception e) {
            // Don't let the package manager crash our app. If the package manager can't resolve the
            // intent here, then we can still call startActivity without calling setClass() first.
            return null;
        }
    }

    public static boolean shareText(final Context context,
                                    final String text,
                                    final String pickerTitle)
    {
        final Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        if (!TextUtils.isEmpty(text))
            sharingIntent.putExtra(Intent.EXTRA_TEXT, text);
        sharingIntent.setType("text/plain");
        return startIntent(context, sharingIntent, pickerTitle);
    }

    public static boolean shareImage(final Context context,
                                     final File imageFile) {
        return shareImage(context, imageFile, null, null);
    }

    public static boolean shareImage(final Context context,
                                     final File imageFile,
                                     final String shareMessage,
                                     final String pickerTitle) {
        final Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("image/*");
        sharingIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(imageFile));
        if (!TextUtils.isEmpty(shareMessage))
            sharingIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
        return startIntent(context, sharingIntent, pickerTitle);
    }

    public static boolean shareAudio(final Context context,
                                     final File messageFileMp3)
    {
        return shareAudio(context, messageFileMp3, null, null);
    }

    public static boolean shareAudio(final Context context,
                                     final File messageFileMp3,
                                     final String shareMessage,
                                     final String pickerTitle)
    {
        final Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(messageFileMp3));
        if (!TextUtils.isEmpty(shareMessage))
            sharingIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
        sharingIntent.setType("audio/*");
        return startIntent(context, sharingIntent, pickerTitle);
    }

    private static boolean startIntent(final Context context, final Intent sharingIntent, final String pickerTitle) {
        boolean isSharingIntentStarted = true;
        try {
            if (TextUtils.isEmpty(pickerTitle))
                context.startActivity(Intent.createChooser(sharingIntent, "Share using"));
            else
                context.startActivity(Intent.createChooser(sharingIntent, pickerTitle));
        } catch (ActivityNotFoundException e) {
//                Toast.makeText(context, noAssociatedAppErrorMessage, Toast.LENGTH_LONG).show();
            isSharingIntentStarted = false;
        } catch (SecurityException e) {
//                Toast.makeText(context, securityExceptionMessage, Toast.LENGTH_LONG).show();
            isSharingIntentStarted = false;
        }
        return isSharingIntentStarted;
    }

    /**
     *   Call Intent
     */
    public static class Call {
        /**
         * Return an Intent for making a phone call. Scheme (e.g. tel, sip) will be determined
         * automatically.
         */
        public static Intent getCallIntent(String number) {
            return getCallIntent(number, null, null);
        }

        /**
         * Return an Intent for making a phone call. A given Uri will be used as is (without any
         * sanity check).
         */
        public static Intent getCallIntent(Uri uri) {
            return getCallIntent(uri, null, null);
        }

        /**
         * A variant of {@link #getCallIntent(String)} but also accept a call origin.
         * For more information about call origin, see comments in Phone package (PhoneApp).
         */
        public static Intent getCallIntent(String number, String callOrigin) {
            return getCallIntent(CallUtils.getCallUri(number), callOrigin, null);
        }

        /**
         * A variant of {@link #getCallIntent(String)} but also include {@code Account}.
         */
        public static Intent getCallIntent(String number, PhoneAccountHandle accountHandle) {
            return getCallIntent(number, null, accountHandle);
        }

        /**
         * A variant of {@link #getCallIntent(Uri)} but also include {@code Account}.
         */
        public static Intent getCallIntent(Uri uri, PhoneAccountHandle accountHandle) {
            return getCallIntent(uri, null, accountHandle);
        }

        /**
         * A variant of {@link #getCallIntent(String, String)} but also include {@code Account}.
         */
        public static Intent getCallIntent(
                String number, String callOrigin, PhoneAccountHandle accountHandle) {
            return getCallIntent(CallUtils.getCallUri(number), callOrigin, accountHandle);
        }

        /**
         * A variant of {@link #getCallIntent(Uri)} but also accept a call
         * origin and {@code Account}.
         * For more information about call origin, see comments in Phone package (PhoneApp).
         */
        public static Intent getCallIntent(
                Uri uri, String callOrigin, PhoneAccountHandle accountHandle) {
            return getCallIntent(uri, callOrigin, accountHandle,
                    VideoProfile.STATE_AUDIO_ONLY);
        }

        /**
         * A variant of {@link #getCallIntent(String, String)} for starting a video call.
         */
        public static Intent getVideoCallIntent(String number, String callOrigin) {
            return getCallIntent(CallUtils.getCallUri(number), callOrigin, null,
                    VideoProfile.STATE_BIDIRECTIONAL);
        }

        /**
         * A variant of {@link #getCallIntent(String, String, PhoneAccountHandle)} for
         * starting a video call.
         */
        public static Intent getVideoCallIntent(
                String number, String callOrigin, PhoneAccountHandle accountHandle) {
            return getCallIntent(CallUtils.getCallUri(number), callOrigin, accountHandle,
                    VideoProfile.STATE_BIDIRECTIONAL);
        }

        /**
         * A variant of {@link #getCallIntent(String, String, PhoneAccountHandle)} for
         * starting a video call.
         */
        public static Intent getVideoCallIntent(String number, PhoneAccountHandle accountHandle) {
            return getVideoCallIntent(number, null, accountHandle);
        }

        /**
         * A variant of {@link #getCallIntent(Uri)} for calling Voicemail.
         */
        public static Intent getVoicemailIntent() {
            return getCallIntent(Uri.fromParts(PhoneAccount.SCHEME_VOICEMAIL, "", null));
        }

        /**
         * A variant of {@link #getCallIntent(Uri)} but also accept a call
         * origin and {@code Account} and {@code VideoCallProfile} state.
         * For more information about call origin, see comments in Phone package (PhoneApp).
         */
        public static Intent getCallIntent(
                Uri uri, String callOrigin, PhoneAccountHandle accountHandle, int videoState) {
            final Intent intent = new Intent(CALL_ACTION, uri);
            intent.putExtra(TelecomManager.EXTRA_START_CALL_WITH_VIDEO_STATE, videoState);
            if (callOrigin != null) {
                intent.putExtra(EXTRA_CALL_ORIGIN, callOrigin);
            }
            if (accountHandle != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    intent.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, accountHandle);
                }
            }

            return intent;
        }

        /**
         * M: According the type to get the CallIntent
         *
         * @param uri        the uri
         * @param callOrigin
         * @param type       the call' type
         * @return the CallIntent
         */
        public static Intent getCallIntent(Uri uri, String callOrigin, int type) {
            final Intent intent = getCallIntent(uri, callOrigin, null);
            if ((type & DIAL_NUMBER_INTENT_IP) != 0) {
                intent.putExtra(EXTRA_IS_IP_DIAL, true);
            }

            if ((type & DIAL_NUMBER_INTENT_VIDEO) != 0) {
                intent.putExtra(EXTRA_IS_VIDEO_CALL, true);
            }

            if ((type & DIAL_NUMBER_INTENT_IMS) != 0) {
                intent.putExtra(EXTRA_IS_IMS_CALL, true);
            }

            return intent;
        }

        /**
         * M: Return Uri with an appropriate scheme, accepting both SIP and usual
         * phone call numbers.
         */
        public static Uri getCallUri(String number) {
            return CallUtils.getCallUri(number);
        }
    }

    /**
     *   Sms Intent
     */
    public static class Sms {
        public static Intent getSendSmsIntent(CharSequence phoneNumber) {
            return new Intent(Intent.ACTION_SENDTO, Uri.parse(SMS_URI_PREFIX + phoneNumber));
        }
    }

    /**
     *   Contact Intent
     */
    public static class Contact {
        /**
         * Returns an implicit intent for opening QuickContacts.
         */
        public static Intent composeQuickContactIntent(Uri contactLookupUri,
                                                       int extraMode) {
            final Intent intent = new Intent(ContactsContract.QuickContact.ACTION_QUICK_CONTACT);
            intent.setData(contactLookupUri);
            intent.putExtra(ContactsContract.QuickContact.EXTRA_MODE, extraMode);
            // Make sure not to show QuickContacts on top of another QuickContacts.
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            return intent;
        }

        public static Intent getNewContactIntent() {
            return new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI);
        }

        public static Intent getNewContactIntent(CharSequence phoneNumber) {
            return getNewContactIntent(
                    null /* name */,
                    phoneNumber /* phoneNumber */,
                    NO_PHONE_TYPE);
        }

        public static Intent getNewContactIntent(
                CharSequence name, CharSequence phoneNumber, int phoneNumberType) {
            Intent intent = getNewContactIntent();
            populateContactIntent(intent, name, phoneNumber, phoneNumberType);
            return intent;
        }

        public static Intent getAddToExistingContactIntent() {
            Intent intent = new Intent(Intent.ACTION_INSERT_OR_EDIT);
            intent.setType(ContactsContract.Contacts.CONTENT_ITEM_TYPE);
            return intent;
        }

        public static Intent getAddToExistingContactIntent(CharSequence phoneNumber) {
            return getAddToExistingContactIntent(
                    null /* name */,
                    phoneNumber /* phoneNumber */,
                    NO_PHONE_TYPE);
        }

        public static Intent getAddToExistingContactIntent(
                CharSequence name, CharSequence phoneNumber, int phoneNumberType) {
            Intent intent = getAddToExistingContactIntent();
            populateContactIntent(intent, name, phoneNumber, phoneNumberType);
            return intent;
        }

        private static void populateContactIntent(
                Intent intent, CharSequence name, CharSequence phoneNumber, int phoneNumberType) {
            if (phoneNumber != null) {
                intent.putExtra(ContactsContract.Intents.Insert.PHONE, phoneNumber);
            }
            if (name != null) {
                intent.putExtra(ContactsContract.Intents.Insert.NAME, name);
            }
            if (phoneNumberType != NO_PHONE_TYPE) {
                intent.putExtra(ContactsContract.Intents.Insert.PHONE_TYPE, phoneNumberType);
            }
        }
    }

    /**
     *   PostalAddress Intent
     */
    public static class PostalAddress {
        public static Intent getViewPostalAddressIntent(String postalAddress) {
            return new Intent(Intent.ACTION_VIEW, getPostalAddressUri(postalAddress));
        }

        public static Uri getPostalAddressUri(String postalAddress) {
            return Uri.parse("geo:0,0?q=" + Uri.encode(postalAddress));
        }

        public static Intent getViewPostalAddressDirectionsIntent(String postalAddress) {
            return new Intent(Intent.ACTION_VIEW, getPostalAddressDirectionsUri(postalAddress));
        }

        public static Uri getPostalAddressDirectionsUri(String postalAddress) {
            return Uri.parse("https://maps.google.com/maps?daddr=" + Uri.encode(postalAddress));
        }
    }

    /**
     * Crop Intent
     */
    public static class Crop {
        /**
         *  SetExtra		DataType	Description
         crop				String		Signals the crop feature
         aspectX			int				Aspect Ratio
         aspectY			int				Aspect Ratio
         outputX			int				width of output created from this Intent
         outputY			int				width of output created from this Intent
         scale				boolean		should it scale
         return-data	boolean			Return the bitmap with Action=inline-data by using the data
         data				Parcelable	Bitmap to process, you may provide it a bitmap (not tested)
         circleCrop	String			if this string is not null, it will provide some circular cr
         MediaStore.EXTRA_OUTPUT ("output")	URI		Set this URi to a File:///
         */
        public static Intent getCropImageIntent(Uri uri, String mimeType,
                                                boolean crop, boolean scale, boolean noFaceDectection,
                                                int aspectX, int aspectY, int outputX, int outputY) {
            if (null != uri) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT, uri);
                if (!TextUtils.isEmpty(mimeType)) {
                    intent.setDataAndType(uri, mimeType);
                }
                // 下面这个crop=true是设置在开启的Intent中设置显示的VIEW可裁剪
                intent.putExtra("crop", crop ? "true" : "false");
                intent.putExtra("scale", scale);// 去黑边
                intent.putExtra("scaleUpIfNeeded", scale);// 去黑边
                // aspectX aspectY 是宽高的比例
                intent.putExtra("aspectX", aspectX);//输出是X方向的比例
                intent.putExtra("aspectY", aspectY);
                // outputX outputY 是裁剪图片宽高，切忌不要再改动下列数字，会卡死
                intent.putExtra("outputX", outputX);//输出X方向的像素
                intent.putExtra("outputY", outputY);
                intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
                intent.putExtra("noFaceDetection", noFaceDectection);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, uri); // 剪切后的图片存于uri标识的文件中
                intent.putExtra("return-data", false); //设置为不返回数据
                return intent;
            }
            return null;
        }

    }

    // 打开本应用信息界面，由用户自己手动开启这个权限
    public static void openSettingActivity(final Activity activity, String message) {
        showMessageOKCancel(activity, message, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", activity.getPackageName(), null);
                intent.setData(uri);
                activity.startActivity(intent);
            }
        });
    }

    private static void showMessageOKCancel(final Activity context, String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(context)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();

    }

    /*
     * 快捷启动 Home
     */
    public static void goHome(Context cxt) {
        if (null != cxt) {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addCategory(Intent.CATEGORY_HOME);
            if (IntentUtils.hasIntentHandler(cxt, intent)) {
                cxt.startActivity(intent);
            }
        }
    }

    public static void launchCalendar(Context cxt) {
        if (null != cxt) {
            Intent intent = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (IntentUtils.hasIntentHandler(cxt, intent)) {
                cxt.startActivity(intent);
            }
        }
    }

    public static void launchClock(Context cxt) {
        if (null != cxt) {
            Intent intent = new Intent("com.android.deskclock.action.SHOW_CLOCK");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (IntentUtils.hasIntentHandler(cxt, intent)) {
                cxt.startActivity(intent);
            }
        }
    }

    public static void launchDial(Context cxt) {
        if (null != cxt) {
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + ""));
            //Intent intent = new Intent(Intent.ACTION_CALL_BUTTON);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (IntentUtils.hasIntentHandler(cxt, intent)) {
                cxt.startActivity(intent);
            }
        }
    }

    public static void launchMsg(Context cxt) {
        if (null != cxt) {
            //Intent intent = new Intent();
            //intent.setClassName("com.android.mms","com.android.mms.ui.ConversationList");
            Intent intent = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (IntentUtils.hasIntentHandler(cxt, intent)) {
                cxt.startActivity(intent);
            }
        }
    }

    public static void launchContact(Context cxt) {
        if (null != cxt) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Contacts.People.CONTENT_URI);
            //intent.setClassName("com.android.contacts","com.android.contacts.activities.PeopleActivity");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (IntentUtils.hasIntentHandler(cxt, intent)) {
                cxt.startActivity(intent);
            }
        }
    }

    public static void launchCamera(Context cxt) {
        if (null != cxt) {
            Intent intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (IntentUtils.hasIntentHandler(cxt, intent)) {
                cxt.startActivity(intent);
            }
        }
    }

    // 网络 - 流量使用情况
    public static void launchNet(Context cxt) {
        if (null != cxt) {
            Intent        intent =  new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS);
            ComponentName cName  = new ComponentName("com.android.settings", "com.android.settings.Settings$DataUsageSummaryActivity");
            intent.setComponent(cName);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (IntentUtils.hasIntentHandler(cxt, intent)) {
                cxt.startActivity(intent);
            }
        }
    }

    public static void launchGps(Context cxt) {
        if (null != cxt) {
            Intent intent =  new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (IntentUtils.hasIntentHandler(cxt, intent)) {
                cxt.startActivity(intent);
            }
        }
    }

    public static void launchSettings(Context cxt) {
        if (null != cxt) {
            Intent intent =  new Intent(Settings.ACTION_SETTINGS);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (IntentUtils.hasIntentHandler(cxt, intent)) {
                cxt.startActivity(intent);
            }
        }
    }

}
