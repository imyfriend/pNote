package iyf.exdroid.support.common.utils;

import android.os.Build;
import android.util.Log;

import java.text.MessageFormat;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings("unused")
public final class LogUtils {
    private static final Boolean UI_DEBUG = true;

    private static final char TOP_LEFT_CORNER = '┌';
    private static final char BOTTOM_LEFT_CORNER = '└';
    private static final char MIDDLE_CORNER = '├';
    private static final char HORIZONTAL_LINE = '│';
    private static final String DOUBLE_DIVIDER = "────────────────────────────────────────────────────────";
    private static final String SINGLE_DIVIDER = "┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄";
    private static final String TOP_BORDER = TOP_LEFT_CORNER + DOUBLE_DIVIDER + DOUBLE_DIVIDER;
    private static final String BOTTOM_BORDER = BOTTOM_LEFT_CORNER + DOUBLE_DIVIDER + DOUBLE_DIVIDER;
    private static final String MIDDLE_BORDER = MIDDLE_CORNER + SINGLE_DIVIDER + SINGLE_DIVIDER;

    private static final String TAG = "_TAG";

    private static final String LOG_FORMAT = "├ %s  〖%s.%s (%s:%s) | %s〗";

    private static final Boolean runningInAndroid = true;

    private static final Map<String, Boolean> map = new ConcurrentHashMap<>();

    private static boolean isDebug(String tag) {
        synchronized (UI_DEBUG) {
            boolean debug = true;
            if (UI_DEBUG && runningInAndroid) {
                if (map.containsKey(tag)) {
                    debug = map.get(tag);
                } else {
                    map.put(tag, debug);
                }
            }
            return debug;
        }
    }

    public static void setDebug(String tag, boolean isDebug) {
        synchronized (UI_DEBUG) {
            if (runningInAndroid) {
                if (map.containsKey(tag)) {
                    if (map.get(tag) != isDebug) {
                        map.remove(tag);
                        map.put(tag, isDebug);
                    }
                } else {
                    map.put(tag, isDebug);
                }
            }
        }
    }

    public static void clearCache() {
        synchronized (UI_DEBUG) {
            map.clear();
        }
    }

    private LogUtils() {

    }

    private static String getSimpleClassName(String name) {
        int lastIndex = name.lastIndexOf(".");
        return name.substring(lastIndex + 1);
    }

    private static String getFormatString(String msg, StackTraceElement trace) {
        return String.format(LOG_FORMAT, msg, getSimpleClassName(trace.getClassName()), trace.getMethodName(),
                             trace.getFileName(), trace.getLineNumber(), Thread.currentThread().getName());
    }

    private static String getTag() {
        StackTraceElement[] traces = Thread.currentThread().getStackTrace();
        StackTraceElement trace = traces[4];
        String tag = trace.getFileName() + TAG;
        if (!map.containsKey("tag")) {
            setDebug(tag, true);
        }
        return tag;
    }

    private static String getFileName(String fileName) {

        return fileName;
    }

    public static int v(String msg) {
        StackTraceElement trace = getInvocationSource();
        String tag = trace.getClassName() + TAG;
        if (!map.containsKey("tag")) {
            setDebug(tag, true);
        }
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.v(tag, msg);
        } else {
            System.out.println(tag + ": " + msg);
            return 0;
        }
    }

    public static int v(String tag, String msg) {
        StackTraceElement trace = getInvocationSource();
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.v(tag, msg);
        } else {
            System.out.println(tag + ": " + msg);
            return 0;
        }
    }

    public static int v(String tag, String msg, Throwable tr) {
        StackTraceElement trace = getInvocationSource();
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.v(tag, msg, tr);
        } else {
            System.out.println(tag + ": " + msg);
            tr.printStackTrace();
            return 0;
        }
    }

    public static int d(String msg) {
        StackTraceElement trace = getInvocationSource();
        String tag = trace.getClassName() + TAG;
        if (!map.containsKey("tag")) {
            setDebug(tag, true);
        }
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.d(tag, msg);
        } else {
            System.out.println(tag + ": " + msg);
            return 0;
        }
    }

    public static int d(String tag, String msg) {
        StackTraceElement trace = getInvocationSource();
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.d(tag, msg);
        } else {
            System.out.println(tag + ": " + msg);
            return 0;
        }
    }

    public static int d(String tag, String msg, Throwable tr) {
        StackTraceElement trace = getInvocationSource();
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.d(tag, msg, tr);
        } else {
            System.out.println(tag + ": " + msg);
            tr.printStackTrace();
            return 0;
        }
    }

    public static int i(String msg) {
        StackTraceElement trace = getInvocationSource();
        String tag = trace.getClassName() + TAG;
        if (!map.containsKey("tag")) {
            setDebug(tag, true);
        }
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.i(tag, msg);
        } else {
            System.out.println(tag + ": " + msg);
            return 0;
        }
    }

    public static int i(String tag, String msg) {
        StackTraceElement trace = getInvocationSource();
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.i(tag, msg);
        } else {
            System.out.println(tag + ": " + msg);
            return 0;
        }
    }

    public static int i(String tag, String msg, Throwable tr) {
        StackTraceElement trace = getInvocationSource();
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.i(tag, msg, tr);
        } else {
            System.out.println(tag + ": " + msg);
            tr.printStackTrace();
            return 0;
        }
    }

    public static int w(String msg) {
        StackTraceElement trace = getInvocationSource();
        String tag = trace.getClassName() + TAG;
        if (!map.containsKey("tag")) {
            setDebug(tag, true);
        }
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.w(tag, msg);
        } else {
            System.out.println(tag + ": " + msg);
            return 0;
        }
    }

    public static int w(String tag, String msg) {
        StackTraceElement trace = getInvocationSource();
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.w(tag, msg);
        } else {
            System.out.println(tag + ": " + msg);
            return 0;
        }
    }

    public static int w(String tag, String msg, Throwable tr) {
        StackTraceElement trace = getInvocationSource();
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.w(tag, msg, tr);
        } else {
            System.out.println(tag + ": " + msg);
            tr.printStackTrace();
            return 0;
        }
    }

    public static boolean isLoggable(String tag, int level) {
        return !isDebug(tag) || Log.isLoggable(tag, level);
    }

    public static int e(String msg) {
        StackTraceElement trace = getInvocationSource();
        String tag = trace.getClassName() + TAG;
        if (!map.containsKey("tag")) {
            setDebug(tag, true);
        }
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.e(tag, msg);
        } else {
            System.out.println(tag + ": " + msg);
            return 0;
        }
    }

    public static int e(String tag, String msg) {
        StackTraceElement trace = getInvocationSource();
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.e(tag, msg);
        } else {
            System.out.println(tag + ": " + msg);
            return 0;
        }
    }

    public static int e(String tag, String msg, Throwable tr) {
        StackTraceElement trace = getInvocationSource();
        //msg = String.format(LOG_FORMAT, trace.getFileName(), trace.getLineNumber(), msg);
        msg = getFormatString(msg, trace);
        if (isDebug(tag)) {
            return Log.e(tag, msg, tr);
        } else {
            System.out.println(tag + ": " + msg);
            tr.printStackTrace();
            return 0;
        }
    }

    public static String getStackTraceString(Throwable tr) {
        if (UI_DEBUG) {
            return Log.getStackTraceString(tr);
        } else {
            return null;
        }
    }

    public static int println(int priority, String tag, String msg) {
        if (isDebug(tag)) {
            return Log.println(priority, tag, msg);
        } else {
            System.out.println("priority=" + priority + ", tag=" + tag + ": " + msg);
            return 0;
        }
    }

    private static StackTraceElement getInvocationSource() {
        // #0: dalvik.system.VMStack.getThreadStackTrace(Native Method)
        // #1: java.lang.Thread.getStackTrace()
        // #2: utils.LogUtils.getInvocationSource()
        // #3: utils.LogUtils.i()
        // #4: <Logger invocation>
        StackTraceElement[] trace = Thread.currentThread().getStackTrace();

//		for (StackTraceElement iter : trace) {
//			Log.d("mtest", "class name=" + iter.getClassName() + ", line number" + iter.getLineNumber());
//		}

        return trace[4];
    }

    /*
     Object[] arguments = {
         new Integer(7),
         new Date(System.currentTimeMillis()),
         "a disturbance in the Force"
     };
     String result = MessageFormat.format(
         "At {1,time} on {1,date}, there was {2} on planet {0,number,integer}.",
         arguments);

     output: At 12:30 PM on Jul 3, 2053, there was a disturbance
           in the Force on planet 7.
     */
    public static String getFormattedLog(String logFormat, Object... logArgs) {
        if (null == logArgs) {
            return logFormat;
        }

        String formattedLog;
        try {
            formattedLog = MessageFormat.format(logFormat, logArgs);
        } catch (Exception e) {
            //Log.e(TAG, "Cannot process given log: " + e.getMessage());
            e.printStackTrace();
            formattedLog = "-- NO LOG TO DISPLAY --";
        }

        return formattedLog;
    }

    private static final String DEVICE_PRODUCT_SONYERICSSON_XPERIA_X10_JP = "SO-01B_1233-7397";

    private static boolean isProblematicDevice() {
        return Build.PRODUCT.equals(DEVICE_PRODUCT_SONYERICSSON_XPERIA_X10_JP);
    }
}
