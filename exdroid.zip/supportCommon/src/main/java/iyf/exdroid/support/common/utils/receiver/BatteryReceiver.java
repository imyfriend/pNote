package iyf.exdroid.support.common.utils.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;

/**
 * 类名称：BatteryReceiver
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/23
 * 修改者， 修改日期， 修改内容
 */
public class BatteryReceiver extends BroadcastReceiver  {

    private BatteryChargeListener batteryChargeListener = null;

    @Override
    public void onReceive(Context context, Intent intent) {
        int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, 0);
        if (status == BatteryManager.BATTERY_STATUS_CHARGING) {
            // Is Charging
            batteryChargeListener.isCharging();
        }
        if (status == BatteryManager.BATTERY_STATUS_FULL) {
            // Is Full
            batteryChargeListener.isFull();
        }
        else {
            // Is Discharging
            batteryChargeListener.isDiscahrging();
        }
    }

    public void registerReceiver(Context context, BatteryChargeListener batteryChargeListenerListener) {
        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_BATTERY_CHANGED);
            context.registerReceiver(this, filter);
            this.batteryChargeListener = batteryChargeListenerListener;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void unRegisterReceiver(Context context) {
        try {
            context.unregisterReceiver(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * The interface Battery charge listener.
     */
    public interface BatteryChargeListener {
        /**
         * Is charging.
         */
        void isCharging();

        /**
         * Is full.
         */
        void isFull();

        /**
         * Is discahrging.
         */
        void isDiscahrging();
    }
}
