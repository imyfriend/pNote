package iyf.exdroid.support.common.utils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

@SuppressWarnings({"WeakerAccess", "unused"})
public final class ReflectUtils {
    private final static String TAG = "ReflectionHelper";

    static {
        LogUtils.setDebug(TAG, true);
    }

    // getField只可以获取public方法
    public static Object getField(Object obj, String name)
            throws SecurityException, NoSuchFieldException,
            IllegalArgumentException, IllegalAccessException {
        LogUtils.d(TAG, "in getField(obj:" + obj + ", name:" + name + ")");

        Field f = obj.getClass().getField(name);
        return f.get(obj);
    }

    // getDeclaredField无修饰限制
    public static Object getDeclaredField(Object obj, String name)
            throws SecurityException, NoSuchFieldException,
            IllegalArgumentException, IllegalAccessException {
        LogUtils.d(TAG, "in getDeclaredField(obj:" + obj + ", name:" + name + ")");

        Field f = obj.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(obj);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void setEnumField(Object obj, String value, String name)
            throws SecurityException, NoSuchFieldException,
            IllegalArgumentException, IllegalAccessException {
        LogUtils.d(TAG, "in setEnumField(obj:" + obj + ", value:" + value + ", name:" + name + ")");

        Field f = obj.getClass().getField(name);
        f.set(obj, Enum.valueOf((Class<Enum>) f.getType(), value));
    }

    @SuppressWarnings("WeakerAccess")
    public static Object getEnumField(Object obj, String name)
            throws NoSuchFieldException, SecurityException,
            IllegalArgumentException, IllegalAccessException {
        LogUtils.d(TAG, "in getEnumField(obj:" + obj + ", name:" + name + ")");

        Field f = obj.getClass().getField(name);
        f.setAccessible(true);
        return f.get(obj);
    }

    public static boolean isEnumFieldEqual(Object obj, String value, String name) {
        LogUtils.d(TAG, "in isEnumFieldEqual(obj:" + obj + ", value:" + value + ", name:" + name + ")");

        boolean isEqual = false;
        Object o;
        try {
            o = getEnumField(obj, name);
            Field f = obj.getClass().getField(name);
            @SuppressWarnings({"unchecked", "rawtypes"})
            Object v = Enum.valueOf((Class<Enum>) f.getType(), value);
            LogUtils.d(TAG, "** current enum value: " + o + ", value=" + v);
            isEqual = o.equals(v);
            LogUtils.d(TAG, "** isEqual: " + isEqual);
        } catch (NoSuchFieldException | SecurityException | IllegalAccessException | IllegalArgumentException e) {
            e.printStackTrace();
        }

        return isEqual;
    }

    public static Object invokeMethod(Object obj, String method, Object... args)
            throws NoSuchMethodException,
            IllegalAccessException, InvocationTargetException {
        LogUtils.d(TAG, "in invokeMethod(obj:" + obj + ", method:" + method
                + ", args:" + Arrays.toString(args) + ")");

        Class<?>[] parameterTypes = null;
        if (null != args) {
            parameterTypes = new Class<?>[args.length];
            for (Object o : args) {
                for (int i = 0; i < args.length; i++) {
                    parameterTypes[i] = o.getClass();
                }
            }
        }

        Object returnValue;
        Method func = obj.getClass().getMethod(method, parameterTypes);
        returnValue = func.invoke(obj, args);
        return returnValue;
    }

    // getDeclaredMethod不能取得父类的方法，这里获取方法时考虑父类
    public static Method getDeclaredMethod(Object object, String methodName, Class<?>... parameterTypes) {
        Method method;
        for (Class<?> clazz = object.getClass(); clazz != Object.class; clazz = clazz.getSuperclass()) {
            try {
                method = clazz.getDeclaredMethod(methodName, parameterTypes);
//                if (DEBUG) {
//            		Log.d(TAG, "getDeclaredMethod, method=" + method);
//            	}
                return method;
            } catch (Exception e) {
                //Log.e(TAG, "in getDeclaredMethod()", e);
            }
        }
        return null;
    }


}
