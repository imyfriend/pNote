package iyf.exdroid.support.common.utils;

import java.lang.reflect.Method;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;

/*
 * 使用线程组管理线程数。
 * 实现主要通过反射机制和线程池机制
 * 
 * 备注：
 * 1、args里参数的顺序必须和func里的参数声明顺序一致；
 * 2、args里参数类型必须和func里的参数声明完全一致；
 * 3、因为Java的基本类型的装箱/拆箱、反射特性，对于基本类型（boolean, byte, char, short, int, long, float, double），
 * 	  func里的参数声明不要有的使用基本类型，有的使用其封装类（Boolean, Byte, Character, Short, Integer, Long, Float, Double），要统一。  
 * 
 */

@SuppressWarnings({"WeakerAccess", "unused"})
public class TaskScheduler {
    private static final String TAG = "TaskScheduler";
    private static final boolean DEBUG = true;
    
    private static final Integer TIME_OUT = 60;
    private static final int PROCESSORS = Runtime.getRuntime().availableProcessors();
    
    private static ExecutorService pool = null;
    private static HandlerThread handlerThread = null;
    private static Handler handler = null;
    
    
    public static void start() {
    	synchronized (TIME_OUT) {
    		if (DEBUG) {
				Log.d(TAG, "start() begin. available processors=" + PROCESSORS);
			}
    		
    		if (null == pool) {
    			int corePoolSize = 2 > PROCESSORS ? 2 : PROCESSORS; 
    			int maximumPoolSize = 4 > PROCESSORS ? 4 : PROCESSORS;
    			int queueCapacity = 1;
    			pool = new ThreadPoolExecutor(corePoolSize, maximumPoolSize, 
    					TIME_OUT, TimeUnit.SECONDS,
    		            new ArrayBlockingQueue<Runnable>(queueCapacity, true),
    		            Executors.defaultThreadFactory(),
    		            new ThreadPoolExecutor.CallerRunsPolicy());
    		}
    		
    		if (null == handlerThread) {
    			handlerThread = new HandlerThread("Dispatcher");
    			handlerThread.start();
    		}
    		
    		if (null == handler) {
    			handler = new Handler(handlerThread.getLooper());
    		}
    		
    		if (DEBUG) {
				Log.d(TAG, "start() end.");
			}
		}
    }
    
	public static void shutdown() {
		synchronized (TIME_OUT) {
			if (DEBUG) {
				Log.d(TAG, "shutdown() begin.");
			}
			// wait for all of the executor threads to finish
			if (null != pool && !pool.isShutdown()) {
				pool.shutdown();
				try {
					if (!pool.awaitTermination(TIME_OUT, TimeUnit.SECONDS)) {
						// pool didn't terminate after the first try
						pool.shutdownNow();
					}

					//noinspection StatementWithEmptyBody
					if (!pool.awaitTermination(TIME_OUT, TimeUnit.SECONDS)) {
						// pool didn't terminate after the second try
					}
				} catch (InterruptedException ex) {
					pool.shutdownNow();
					Thread.currentThread().interrupt();
				} finally {
					if (null != handler) {
						handler.removeCallbacksAndMessages(null);
					}
					if (null != handlerThread) {
						handlerThread.quit();
					}
					
					pool = null;
					handlerThread = null;
					handler = null;
				}
			}
			if (DEBUG) {
				Log.d(TAG, "shutdown() end.");
			}
		}
	}
    
	private Object target = null; 		// 目标对象
    private String func = null; 		// 在目标对象上需要执行的函数
    private Object[] args = null; 		// 函数参数，需要和func的参数声明顺序和类型严格一致。
    private Object result = null;		// func执行结果
    private long delayMillis = 0; 		// 延迟时间
    private OnResultListener listener = null; // 函数执行结果监听器，当函数执行结束时，该监听器会被调用。
    private Future<?> future = null;
    
    public void setOnResultListener(OnResultListener listener) {
    	this.listener = listener;
    }
    
    public Object getTarget() {
		return target;
	}

	public void setTarget(Object target) {
		this.target = target;
	}

	public String getFunc() {
		return func;
	}

	public void setFunc(String func) {
		this.func = func;
	}

	public Object[] getArgs() {
		return args;
	}

	public void setArgs(Object[] args) {
		this.args = args;
	}
	
	public Object getResult() {
		return result;
	}

	public long getDelayMillis() {
		return delayMillis;
	}

	public void setDelayMillis(long delayMillis) {
		this.delayMillis = delayMillis;
	}
	
	/*
	 * 取消已提交的任务
	 */
	public boolean cancel() { 
		boolean isCancelled = false;
		if (null != future) {
			isCancelled = future.isCancelled();
			if (!isCancelled) {
				isCancelled = future.cancel(true);
			}
		}
		if (DEBUG) {
			Log.d(TAG, "in cancel(), isCancelled=" + isCancelled);
		}
		return isCancelled;
	}


	private Method invocation;
    
    public void execute() {
        init();
        
        synchronized (TIME_OUT) {
        	if (null != handler) {
    			handler.postDelayed(new Runnable() {

    				@Override
    				public void run() {
    					Runnable r;
    					try {
    						r = getRunnable();
    						future = pool.submit(r);
    					} catch (Exception e) {
    						Log.e(TAG, "in execute, pool.submit() Exception!!! ", e);
    					}
    				}

    			}, delayMillis);
            }
		}
        
    }
    
    private void init() {
        if (null != args) {
            int length = args.length;
	        Class<?>[] argsType = new Class<?>[length];
            if (DEBUG) {
            	Log.i(TAG, "init() length=" + length);
            }
            for (int i = 0; i < length; i++) {
                argsType[i] = args[i].getClass();
                if (DEBUG) {
                	Log.i(TAG, "init() argsType[i]=" + argsType[i]);
                }
            }

            try {
                if (DEBUG) {
                	Log.i(TAG, "init() func=" + func);
                }
              
                invocation = getDeclaredMethod(target, func, argsType);
                if (null == invocation) {
                	for (int i = 0; i < length; i++) {
    					if (Boolean.class == argsType[i]) {
    						argsType[i] = boolean.class;
    						if (DEBUG) {
    							Log.d(TAG, "Boolean -> boolean");
    						}
    					} else if (Byte.class == argsType[i]) {
    						argsType[i] = byte.class;
    						if (DEBUG) {
    							Log.d(TAG, "Byte -> byte");
    						}
    					} else if (Character.class == argsType[i]) {
    						argsType[i] = char.class;
    						if (DEBUG) {
    							Log.d(TAG, "Character -> char");
    						}
    					} else if (Short.class == argsType[i]) {
    						argsType[i] = short.class;
    						if (DEBUG) {
    							Log.d(TAG, "Short -> short");
    						}
    					} else if (Integer.class == argsType[i]) {
    						argsType[i] = int.class;
    						if (DEBUG) {
    							Log.d(TAG, "Integer -> int");
    						}
    					} else if (Long.class == argsType[i]) {
    						argsType[i] = long.class;
    						if (DEBUG) {
    							Log.d(TAG, "Long -> long");
    						}
    					} else if (Float.class == argsType[i]) {
    						argsType[i] = float.class;
    						if (DEBUG) {
    							Log.d(TAG, "Float -> float");
    						}
    					} else if (Double.class == argsType[i]) {
    						argsType[i] = double.class;
    						if (DEBUG) {
    							Log.d(TAG, "Double -> double");
    						}
    					}
    				}
    				
    				invocation = getDeclaredMethod(target, func, argsType);
                }
                
            } catch (Exception e) {
                Log.e(TAG, "in init(), Exception args!=null");   
            }
            
        } else {
			if (DEBUG) {
				Log.i(TAG, "init() func=" + func);
			}
			//Class<?>[] args = null;
			try {
				invocation = getDeclaredMethod(target, func);
			} catch (Exception e) {
				Log.e(TAG, "in init()", e);
			}
        }
        
        if (null != invocation) {
            invocation.setAccessible(true);
        } else {
        	if (DEBUG) {
        		Log.e(TAG, "in init(), invocation == null");
        	}
        }
    }
    
    private Runnable getRunnable() {
        return new Runnable() {

            @Override
            public void run() {
                try {
                	if (DEBUG) {
                		Log.d(TAG, "in getRunnable.Runnable.run(), target=" + target + ", invocation=" + invocation + ", " 
                            + Thread.currentThread().getName());
                	}
                    
                	if (null == invocation) {
                		return;
                	}
                	
                    if (args != null) {
                    	result = invocation.invoke(target, args);
                    } else {
                    	result = invocation.invoke(target);
                    }
                    if (DEBUG) {
                		Log.d(TAG, "in getRunnable.Runnable.run(), result=" + result);
                	}
                    
					if (null != listener) {
						listener.onResultCreated(TaskScheduler.this);
					}
                    
                } catch (Exception e) {
                    Log.e(TAG, "in getRunnable.Runnable.run()", e);
                }                
            }
            
        };
    }
    
    public interface OnResultListener {
    	void onResultCreated(TaskScheduler scheduler);
    }
    
    public static Method getDeclaredMethod(Object object, String methodName, Class<?> ... parameterTypes)  {
        Method method;
        for(Class<?> clazz = object.getClass(); clazz != Object.class; clazz = clazz.getSuperclass()) {
            try {   
                method = clazz.getDeclaredMethod(methodName, parameterTypes);   
                if (DEBUG) {
            		Log.d(TAG, "getDeclaredMethod, method=" + method);
            	}
                return method ;  
            } catch (Exception e) { 
            	//Log.e(TAG, "in getDeclaredMethod()", e);
            }
        }
        return null;
   }
    
}
