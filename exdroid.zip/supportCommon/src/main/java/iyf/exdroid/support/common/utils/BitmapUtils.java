package iyf.exdroid.support.common.utils;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
//import android.graphics.AvoidXfermode;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.EmbossMaskFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.Paint.Align;
import android.graphics.PorterDuff.Mode;
import android.graphics.Shader.TileMode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.MediaMetadataRetriever;
import android.os.Build;
import android.os.Trace;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.Layout.Alignment;
import android.util.Log;
import android.widget.ImageView;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

@SuppressWarnings({"WeakerAccess", "unused"})
public class BitmapUtils {
	private static final String TAG = "BitmapUtils";
	
	static {
		LogUtils.setDebug(TAG, true);
	}

	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap) {
		LogUtils.d(TAG, "getRoundedCornerBitmap(bitmap=" + bitmap + ")");
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
				bitmap.getHeight(), Config.ARGB_8888);
		Canvas canvas = new Canvas(output);

		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = 24;

		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

		paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		canvas.drawBitmap(bitmap, rect, rect, paint);

		return output;
	}
	
	public static Bitmap getNumberBitmap(Bitmap sourceBitmap,
	                                     String inputStr, int cSize,
	                                     int imageWidth, int imageHeight, @SuppressWarnings("SameParameterValue") float hRatio) {
		char[] inputChar = inputStr.toCharArray();
		Bitmap newBitmap = Bitmap.createBitmap(imageWidth * inputChar.length, imageHeight, Config.ARGB_8888);
		Canvas cv = new Canvas(newBitmap);
		//Bitmap sourceBitmap = BitmapFactory.decodeResource(res, resID);
		Bitmap bitmap;
		for (int i = 0; i < inputChar.length; i++) {
			char c = inputChar[i];
			int x = 0;
			switch (c) {				
			case '0':
				x = 0;
				break;
				
			case '1':
				x = 1;
				break;
				
			case '2':
				x = 2;
				break;
				
			case '3':
				x = 3;
				break;
				
			case '4':
				x = 4;
				break;
				
			case '5':
				x = 5;
				break;
				
			case '6':
				x = 6;
				break;
				
			case '7':
				x = 7;
				break;
				
			case '8':
				x = 8;
				break;
				
			case '9':
				x = 9;
				break;
				
			case ':':
				x = 10;
				break;
				
			default:
				LogUtils.d(TAG, "in getNumberBitmap, NO MATCHED char!!! ");
				break;
			}
			
			bitmap = Bitmap.createBitmap(sourceBitmap, x * cSize, 0, imageWidth, imageHeight);
			cv.drawBitmap(bitmap, imageWidth * i, 0, null);
			bitmap.recycle();
		}
		
		cv.save(Canvas.ALL_SAVE_FLAG); // save all clip
		cv.restore(); // store

		Bitmap expandBitmap = Bitmap.createScaledBitmap(newBitmap,
														Math.round(newBitmap.getWidth() * hRatio),
														Math.round(newBitmap.getHeight() * hRatio), 
														true);
		newBitmap.recycle();
		
		return expandBitmap;
	}
	
	public static void recycleBitmap(ImageView iv) {
		if (iv != null && iv.getDrawable() != null) {
			Bitmap bmp = ((BitmapDrawable) iv.getDrawable()).getBitmap();
			if (bmp != null && !bmp.isRecycled()) {
				bmp.recycle();
				LogUtils.d(TAG, "recycleBitmap succeeds!!!");
				return;
			}
		}
		
		LogUtils.d(TAG, "recycleBitmap fails!!!");
	}
	
	public static Bitmap getDateNumberBitmap(AssetManager am, String inputStr) {
		Bitmap sourceBitmap = getBitmapFromAssets(am, "drawable/date_number.png");
		return getNumberBitmap(sourceBitmap, inputStr, 48, 48, 74, 1.0f);
	}
	
	public static Bitmap getTimeNumberBitmap(AssetManager am, String inputStr) {
		Bitmap sourceBitmap = getBitmapFromAssets(am, "drawable/time_number.png");
		return getNumberBitmap(sourceBitmap, inputStr, 34, 34, 58, 1.0f);
	}
	
	public static Bitmap getBitmapFromAssets(AssetManager am, String fileName){
		BufferedInputStream buf = null;
		try{
			buf = new BufferedInputStream(am.open(fileName));
			BitmapFactory.Options option = new BitmapFactory.Options();
			option.inPreferredConfig = Config.ARGB_8888;
			Rect outPadding = new Rect(0, 0, 0, 0);
			return BitmapFactory.decodeStream(buf, outPadding, option);
			
		}catch (Exception e) {
			LogUtils.e(TAG, "fileName=" + fileName, e);
			return null;
			
		}finally{
			try{
				if(buf != null) {
					buf.close();
				}
			}catch (Exception e) {
				LogUtils.e(TAG, "fileName=" + fileName, e);
			}
		}
	}
	
	public static Bitmap createBitmapWithText(CharSequence source,
			Typeface typeface, float fontSize, int fontColor, int width, Alignment align, float spacingmult,
			float spacingadd, boolean includepad) {
    	TextPaint textPaint = new TextPaint();
        textPaint.setTypeface(typeface);
        textPaint.setTextSize(fontSize);
        textPaint.setAntiAlias(true);
        textPaint.setColor(fontColor);
        
		StaticLayout layout = new StaticLayout(source, textPaint, width, align,
				spacingmult, spacingadd, includepad);

		Config config =  Config.ARGB_4444;
		Bitmap bitmap = Bitmap.createBitmap(layout.getWidth(),
											layout.getHeight(), 
											config);
		Canvas canvas = new Canvas(bitmap);
		bitmap.eraseColor(Color.TRANSPARENT);
		layout.draw(canvas);

		return bitmap;
	}
	
//	public static Bitmap createBitmapWithText(CharSequence source,
//			String fontname, float fontSize, int fontColor, int width, Alignment align, float spacingmult,
//			float spacingadd, boolean includepad) {
//		LogUtils.d(TAG, "createBitmapWithText(source=" + source + ", ...)");
//		
//		TextPaint paint = initPaint(fontname, fontSize, fontColor);
//		StaticLayout layout = new StaticLayout(source, paint, width, align,
//				spacingmult, spacingadd, includepad);
//
//		Bitmap.Config config = Bitmap.Config.ARGB_4444; 
//		Bitmap bitmap = Bitmap.createBitmap(layout.getWidth(),
//											layout.getHeight(), 
//											config);
//		Canvas canvas = new Canvas(bitmap);
//		bitmap.eraseColor(Color.TRANSPARENT);
//		layout.draw(canvas);
//
//		return bitmap;
//	}

//    private static HashMap<String, Typeface> typefaces = new HashMap<String, Typeface>();
//    private static TextPaint initPaint(String fontname, float fontSize, int color){
//    	Typeface typeface;
//    	if(!typefaces.containsKey(fontname)) {
//	        try {
//	        	iCare2Application.getInstance().getAssets().open(fontname);
//	        	typeface = Typeface.createFromAsset(iCare2Application.getInstance().getAssets(), fontname);
//	        } catch(IOException e) {
//	        	typeface = Typeface.create(fontname, Typeface.NORMAL);
//	        }
//	        typefaces.put(fontname, typeface);
//    	} else {
//    		typeface = typefaces.get(fontname);
//    	}
//
//    	TextPaint textPaint = new TextPaint();
//        textPaint.setTypeface(typeface);
//        textPaint.setTextSize(fontSize);
//        textPaint.setAntiAlias(true);
//        textPaint.setColor(color);
//    	
//    	return textPaint;
//    }
    
//    public static Bitmap createBitmapWithText(String source, int fontNumberOfRow, int fontColor, int width) {
//    	LogUtils.d(TAG, "createBitmapWithText(fontNumberOfRow=" + fontNumberOfRow + ", fontColor=" + fontColor + ", width=" + width + ", source=" + source);
//    	
//		char[] inputChar = source.toCharArray();
//		int length = inputChar.length;
//		int fontSize = (int)Math.round(((double)width)/fontNumberOfRow);
//		Bitmap bmp = BitmapUtils.createBitmapWithText("慧", YaHeiFont.getFont(), fontSize, fontColor, fontSize, 
//													 Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
//		int imageHeight = bmp.getHeight(); 
//		int imageWidth = bmp.getWidth();
//		LogUtils.d(TAG, " -- fontSize=" + fontSize + ", width=" + width + ", imageWidth=" + imageWidth + ", imageHeight=" + imageHeight);
//		
//		int newBitmapWidth = imageWidth * fontNumberOfRow;
//		int newBitmapHeight = imageHeight * (int)(Math.ceil(((double)length)/fontNumberOfRow));
//		Bitmap newBitmap = Bitmap.createBitmap(newBitmapWidth, newBitmapHeight, Config.ARGB_8888);
//		Canvas cv = new Canvas(newBitmap);
//		LogUtils.d(TAG, " -- newBitmapWidth=" + newBitmapWidth + ", newBitmapHeight=" + newBitmapHeight + ", input length=" + inputChar.length);
//		
//		Bitmap bitmap = null;
//		for (int i = 0; i < length; i++) {
//			bitmap = BitmapUtils.createBitmapWithText(String.valueOf(inputChar[i]), YaHeiFont.getFont(), fontSize, fontColor, fontSize, 
//					 Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false);
//			int x = i % fontNumberOfRow;
//			int y = i / fontNumberOfRow;
//			cv.drawBitmap(bitmap, imageWidth*x, y*imageHeight, null);
//			bitmap.recycle();
//		}
//
//		cv.save(Canvas.ALL_SAVE_FLAG); // save all clip
//		cv.restore(); // store
//		return newBitmap;
//    }
	
	// 将大存储图片采样后生成Bitmap
	// filename 图片文件路径
	public static Bitmap decodeSampledBitmapFromFile(String filename,
			int reqWidth, int reqHeight) {

		// First decode with inJustDecodeBounds=true to check dimensions
		final BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeFile(filename, options);

		// Calculate inSampleSize
		options.inSampleSize = calculateInSampleSize(options, reqWidth,
				reqHeight);
		// options.inSampleSize = 2;
		// Decode bitmap with inSampleSize set
		options.inJustDecodeBounds = false;
		return BitmapFactory.decodeFile(filename, options);
	}
	
	public static Bitmap decodeSampleBitmapFromRes(Resources res, int id, int reqWidth, int reqHeight) {
		// First decode with inJustDecodeBounds=true to check dimensions
		final BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeResource(res, id, options);

		// Calculate inSampleSize
		options.inSampleSize = calculateInSampleSize(options, reqWidth,
				reqHeight);
		// options.inSampleSize = 2;
		// Decode bitmap with inSampleSize set
		options.inJustDecodeBounds = false;
		return BitmapFactory.decodeResource(res, id, options);
	}

	// 计算图片采样率
	public static int calculateInSampleSize(BitmapFactory.Options options,
			int reqWidth, int reqHeight) {
		// Raw height and width of image
		final int height = options.outHeight;
		final int width = options.outWidth;

		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {
			if (width > height) {
				inSampleSize = Math.round((float) height / (float) reqHeight);
			} else {
				inSampleSize = Math.round((float) width / (float) reqWidth);
			}
		}

		return inSampleSize;
	}
	
	/**
	 * add watermark to src
	 * @param src: the bitmap object you want process
	 * @param watermark: the watermark above src
	 * @param left: horizontal location of src
	 * @param top: vertical location of src
	 * @return: a new bitmap object, if src is null, return null 
	 */
	@SuppressWarnings("JavaDoc")
	public static Bitmap addWatermark(Bitmap src, Bitmap watermark, float left, float top) {
		Bitmap dst = null;
		
		if (src == null) {
			Log.d("mtest", "src == null");
			return null;
		}
		
		int w = src.getWidth();
		int h = src.getHeight();
		
		dst = Bitmap.createBitmap(w, h, Config.ARGB_4444);
		Canvas cv = new Canvas(dst);
		
		cv.drawBitmap(src, 0, 0, null); // draw src into canvas
		
		if (watermark != null) {
			cv.drawBitmap(watermark, left, top, null); // draw watermark into canvas at (left, top)
		}
		
		cv.save(Canvas.ALL_SAVE_FLAG); // save all clip
		cv.restore(); // store all clip
		
		return dst;
	}
	
	//放大缩小图片  
    public static Bitmap zoomBitmap(Bitmap bitmap,int w,int h) {  
    	Bitmap newBmp = null;
    	
    	if (bitmap != null) {
			int width = bitmap.getWidth();
			int height = bitmap.getHeight();
			Matrix matrix = new Matrix();
			float scaleWidth = ((float) w / width);
			float scaleHeight = ((float) h / height);
			matrix.postScale(scaleWidth, scaleHeight);
			newBmp = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix,
					true);
    	}
    	
        return newBmp;
    }  
	
	//获得带倒影的图片方法  
    public static Bitmap createReflectionWithOrigin(Bitmap bitmap){  
    	Bitmap bitmapWithReflection = null;
    	
    	if (bitmap != null) {
			// 图片与倒影间隔距离
			final int reflectionGap = 4;
			// 图片的宽度
			int width = bitmap.getWidth();
			// 图片的高度
			int height = bitmap.getHeight();

			Matrix matrix = new Matrix();
			// 图片缩放，x轴变为原来的1倍，y轴为-1倍,实现图片的反转
			matrix.preScale(1, -1);
			// 创建反转后的图片Bitmap对象，图片高是原图的一半。
			Bitmap reflectionImage = Bitmap.createBitmap(bitmap, 0, height / 2,
					width, height / 2, matrix, false);
			// 创建标准的Bitmap对象，宽和原图一致，高是原图的1.5倍。 可以理解为这张图将会在屏幕上显示 是原图和倒影的合体
			bitmapWithReflection = Bitmap.createBitmap(width,
					(height + height / 2), Config.ARGB_8888);
			// 构造函数传入Bitmap对象，为了在图片上画图
			Canvas canvas = new Canvas(bitmapWithReflection);
			// 画原始图片
			canvas.drawBitmap(bitmap, 0, 0, null);
			// 画间隔矩形
			Paint deafalutPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
			deafalutPaint.setColor(Color.TRANSPARENT);
			canvas.drawRect(0, height, width, height + reflectionGap,
					deafalutPaint);
			// 画倒影图片
			canvas.drawBitmap(reflectionImage, 0, height + reflectionGap, null);
			// 实现倒影渐变效果
			Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
			LinearGradient shader = new LinearGradient(0, bitmap.getHeight(),
					0, bitmapWithReflection.getHeight() + reflectionGap,
					0x70ffffff, 0x00ffffff, TileMode.CLAMP);
			paint.setShader(shader);

			// Set the Transfer mode to be porter duff and destination in
			// 覆盖效果
			paint.setXfermode(new PorterDuffXfermode(Mode.DST_IN));
			// Draw a rectangle using the paint with our linear gradient
			canvas.drawRect(0, height, width, bitmapWithReflection.getHeight()
					+ reflectionGap, paint);
    	}
   
        return bitmapWithReflection;  
    }  
	
	public static Bitmap drawable2Bitmap(Drawable drawable) {
		Bitmap bitmap = null;
		
		if (drawable != null) {
			int width = drawable.getIntrinsicWidth();
			int height = drawable.getIntrinsicHeight();
			Config config = (drawable.getOpacity() != PixelFormat.OPAQUE) ? 
							Config.ARGB_8888 : Config.RGB_565;
			bitmap = Bitmap.createBitmap(width, height, config);
			Canvas cvs = new Canvas(bitmap);
			drawable.setBounds(0, 0, width, height);
			drawable.draw(cvs);
		}
		
		return bitmap;
	}
	
	public static Bitmap addText(String txt, int txtSize, int txtColor,
			Typeface tf, float degrees, int width, int height, float x,
			float y, Bitmap bmp, boolean up) {
		long mills = System.currentTimeMillis();

		Bitmap dst = Bitmap.createBitmap(width, height, Config.ARGB_4444);
		Canvas cv = new Canvas(dst);

		Paint p = new Paint();
		int alpha = txtColor >>> 24;
		p.setAlpha(alpha);

		if (null == bmp) {
			cv.drawARGB(0, 0, 0, 0);
			Log.d("mtest", "bmp == null");
		} else if (!up) {
			Rect r = new Rect(0, 0, width, height);
			cv.drawBitmap(bmp, null, r, p); // draw bmp into canvas
			Log.d("mtest", "bmp below");
		}

		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextSize(txtSize);
		paint.setColor(txtColor);
		paint.setTextAlign(Align.LEFT);
		if (tf != null) {
			paint.setTypeface(tf);
		}

		//noinspection UnusedAssignment
		BlurMaskFilter blurFilter = new BlurMaskFilter(8,
				BlurMaskFilter.Blur.NORMAL);
		// paint.setMaskFilter(blurFilter);

		float[] direction = new float[] { 1, 1, 1 };
		float light = 0.4f;
		float specular = 6;
		float blur = 3.5f;
		EmbossMaskFilter emboss = new EmbossMaskFilter(direction, light,
				specular, blur);
		paint.setMaskFilter(emboss);

//		AvoidXfermode avoid = new AvoidXfermode(Color.BLUE, 10,
//				AvoidXfermode.Mode.TARGET);
		// paint.setXfermode(avoid);

		cv.rotate(degrees, x, y);
		cv.drawText(txt, x, y, paint);
		cv.rotate(-degrees, x, y);

		if (up && (null != bmp)) {
			Rect r = new Rect(0, 0, width, height);
			cv.drawBitmap(bmp, null, r, p); // draw bmp into canvas
			Log.d("mtest", "bmp up");
		}

		cv.save(Canvas.ALL_SAVE_FLAG); // save all clip
		cv.restore(); // store all clip

		mills = System.currentTimeMillis() - mills;
		Log.d("mtest", "addText mills=" + mills);

		return dst;
	}
	
	// 给图片加边框
	public static Bitmap createBorderBitmap(Bitmap src, int width, int height, int borderWidth, int borderColor) {
		Bitmap bmp = null;
		
		if ((src!=null) && (width>0) && (height>0)) {
			bmp = Bitmap.createBitmap(width, height, Config.ARGB_4444);
			Canvas cv = new Canvas(bmp);

			Rect r = new Rect(0, 0, width, height);
			cv.drawBitmap(src, null, r, null);

			r = cv.getClipBounds();
			Paint paint = new Paint();
			paint.setColor(borderColor);
			paint.setStyle(Paint.Style.STROKE);
			paint.setStrokeWidth(borderWidth);
			cv.drawRect(r, paint);

			cv.save(Canvas.ALL_SAVE_FLAG); // save all clip
			cv.restore(); // store all clip
		}
		
		return bmp;
	}
	
	public static void createCenterBitmap(String path, String name, Bitmap bmp, int width, int height) {
		long mills = System.currentTimeMillis();
		
		FileOutputStream fOut = null;
		try {
			String dirPath = path + "_" + width + "-" + height;
			File dir = new File(dirPath);
			if (!dir.exists() && !dir.mkdir()) {
				return;
			}
			
			File f = new File(dirPath, name + "_" + width + "-" + height + ".jpg");
			if (f.exists()) {
				//noinspection ResultOfMethodCallIgnored
				f.delete();
			}
			fOut = new FileOutputStream(f);
			
			int out_width;
			int out_height;
	
			double hr = (double)bmp.getHeight() / height;
			double wr = (double)bmp.getWidth() / width;
			double r = Math.min(hr, wr);

			out_width = (int) Math.ceil(bmp.getWidth() / r);
			out_height = (int) Math.ceil(bmp.getHeight() / r);
			
//			Log.d("mtest", "out_width=" + out_width + ", out_height=" + out_height +
//					", width=" + bmp.getWidth() + ", height=" + bmp.getHeight());
			
			Bitmap src = Bitmap.createScaledBitmap(bmp, out_width, out_height, false);
			
			Bitmap tmp = Bitmap.createBitmap(width, height, Config.RGB_565);
			Canvas cv = new Canvas(tmp);
			
			Rect dstR = new Rect(0, 0, width, height);
			
			Rect srcR = new Rect((out_width-width)/2, (out_height-height)/2, 
					              width+(out_width-width)/2, height+(out_height-height)/2);
//			Log.d("mtest", "srcR left=" + srcR.left + ", top=" + srcR.top + ", right=" + srcR.right + ", bottom=" + srcR.bottom);
					
			cv.drawBitmap(src, srcR, dstR, null);
			cv.save(Canvas.ALL_SAVE_FLAG); // save all clip
			cv.restore(); // store all clip
			
			tmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
			
			mills = System.currentTimeMillis() - mills;
			Log.d("mtest", "createScaledBitmap mills=" + mills);
		} catch (Exception  e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (fOut != null) {
					fOut.close();
				}
			} catch (Exception  e) {
				e.printStackTrace();
				//Log.e("createScaledBitmap ERROR!!! " + e.getMessage());
			}
		}
	}
	
	// 按照width, height取图片的中间部分
	public static Bitmap createCenterBitmap(Bitmap bmp, int width, int height) {
		Bitmap tmp = null;
		
		if ((bmp!=null) && (width>0) && (height>0)) {
			int out_width;
			int out_height;
	
			double hr = (double)bmp.getHeight() / height;
			double wr = (double)bmp.getWidth() / width;
			double r = Math.min(hr, wr);

			out_width = (int) Math.ceil(bmp.getWidth() / r);
			out_height = (int) Math.ceil(bmp.getHeight() / r);
			
			Bitmap src = Bitmap.createScaledBitmap(bmp, out_width, out_height, false);
			
			tmp = Bitmap.createBitmap(width, height, Config.RGB_565);
			Canvas cv = new Canvas(tmp);
			
			Rect dstR = new Rect(0, 0, width, height);
			
			Rect srcR = new Rect( (out_width-width)/2, 
					              (out_height-height)/2, 
					              width+(out_width-width)/2, 
					              height+(out_height-height)/2
					             );
					
			cv.drawBitmap(src, srcR, dstR, null);
			cv.save(Canvas.ALL_SAVE_FLAG); // save all clip
			cv.restore(); // store all clip
		}
		
		return tmp;
	}
	
	public static void createScaledBitmap(String path, String name, Bitmap bmp, int width, int height) {
		//Log.d("mtest", "path = " + path);
		long mills = System.currentTimeMillis();
		
		FileOutputStream fOut = null;
		try {
			String dirPath = path + "_" + width + "-" + height;
			File dir = new File(dirPath);
			if (!dir.exists() && !dir.mkdir()) {
				return;
			}
			
			File f = new File(dirPath, name + "_" + width + "-" + height + ".jpg");
			if (f.exists()) {
				//noinspection ResultOfMethodCallIgnored
				f.delete();
			}
			fOut = new FileOutputStream(f);
			Bitmap tmp = Bitmap.createScaledBitmap(bmp, width, height, false);
			tmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
			
			mills = System.currentTimeMillis() - mills;
			Log.d("mtest", "createScaledBitmap mills=" + mills);
		} catch (Exception  e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (fOut != null) {
					fOut.close();
				}
			} catch (Exception  e) {
				e.printStackTrace();
				//Log.e("createScaledBitmap ERROR!!! " + e.getMessage());
			}
		}
	}
	
	public static Bitmap createScaledBitmap(Bitmap bmp, int width, int height) {
		Bitmap tmp = null;
		if ((bmp!=null) && (width>0) && (height>0) ) {
			tmp = Bitmap.createScaledBitmap(bmp, width, height, false);
		}
		
		return tmp;
	}
	
	// 创建圆角图片
	public static Bitmap createRoundBitmap(Bitmap bitmap, int round) {
		if ((bitmap!=null) && (round>0)) {
			int diameter = 2 * round;
			
			int out_width;
			int out_height;

			double hr = (double) bitmap.getHeight() / diameter;
			double wr = (double) bitmap.getWidth() / diameter;
			double r = Math.min(hr, wr);

			out_width = (int) Math.ceil(bitmap.getWidth() / r);
			out_height = (int) Math.ceil(bitmap.getHeight() / r);
			
			Log.d("mtest", "width=" + bitmap.getWidth() + ", height=" + bitmap.getHeight() +
					", out_width=" + out_width + ", out_height=" + out_height);

			Bitmap src = Bitmap.createScaledBitmap(bitmap, out_width,
					out_height, false);

			Rect dstR = new Rect(0, 0, out_width, out_height);
			
			final Paint paint = new Paint();
			paint.setAntiAlias(true);
			Bitmap roundBitmap = Bitmap.createBitmap(out_width, out_height, Config.ARGB_8888);
			Canvas cvs = new Canvas(roundBitmap);
			RectF rect = new RectF(dstR);
			cvs.drawRoundRect(rect, round, round, paint);

			paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
			cvs.drawBitmap(src, dstR, dstR, paint);
			return roundBitmap;
		}
		
		return null;
	}
	
	// 创建圆形图片,只取中间部分
	public static Bitmap createCircleBitmap(Bitmap bitmap, int radius) {		
		if ((bitmap!=null) && (radius>0) ) {
			int out_width;
			int out_height;

			double hr = (double) bitmap.getHeight() / radius;
			double wr = (double) bitmap.getWidth() / radius;
			double r = Math.min(hr, wr);

			out_width = (int) Math.ceil(bitmap.getWidth() / r);
			out_height = (int) Math.ceil(bitmap.getHeight() / r);

			Bitmap src = Bitmap.createScaledBitmap(bitmap, out_width,
					out_height, false);

			Rect dstR = new Rect(0, 0, radius, radius);
			Rect srcR = new Rect( (out_width - radius) / 2, 
					              (out_height - radius) / 2, 
					              radius + (out_width - radius) / 2, 
					              radius + (out_height - radius) / 2
					            );

			final Paint paint = new Paint();
			paint.setAntiAlias(true);
			Bitmap circleBitmap = Bitmap.createBitmap(radius, radius, Config.ARGB_8888);

			Canvas cvs = new Canvas(circleBitmap);
			cvs.drawCircle(radius / 2, radius / 2, radius / 2, paint);

			paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
			cvs.drawBitmap(src, srcR, dstR, paint);

			return circleBitmap;
		} 
		
		return null;
	}
	
	public static Bitmap createBitmapByColor(int color, int width, int height) {
		Bitmap bmp = Bitmap.createBitmap(width, height,
				Config.ARGB_8888);
		Canvas canvas = new Canvas(bmp);
		canvas.drawColor(color);
		return bmp;
	}
	
	/***
	 * 图片切圆角，方向自由.
	 */
	public static class Round {
		public static final int POS_ALL = 0x00000001;
		public static final int POS_TOP = 0x00000010;
		public static final int POS_LEFT = 0x00000100;
		public static final int POS_RIGHT = 0x00001000;
		public static final int POS_BOTTOM = 0x00010000;

		public static Bitmap createRoundBitmapByPos(int type, Bitmap bitmap,
													int radiusInPx) {
			try {
				// 其原理就是：先建立一个与图片大小相同的透明的Bitmap画板
				// 然后在画板上画出一个想要的形状的区域。
				// 最后把源图片帖上。
				final int width = bitmap.getWidth();
				final int height = bitmap.getHeight();

				Bitmap paintingBoard = Bitmap.createBitmap(width, height,
						Config.ARGB_8888);
				Canvas canvas = new Canvas(paintingBoard);
				canvas.drawARGB(Color.TRANSPARENT, Color.TRANSPARENT,
						Color.TRANSPARENT, Color.TRANSPARENT);

				final Paint paint = new Paint();
				paint.setAntiAlias(true);
				paint.setColor(Color.BLACK);

				if (POS_TOP == type) {
					clipTop(canvas, paint, radiusInPx, width, height);
				} else if (POS_LEFT == type) {
					clipLeft(canvas, paint, radiusInPx, width, height);
				} else if (POS_RIGHT == type) {
					clipRight(canvas, paint, radiusInPx, width, height);
				} else if (POS_BOTTOM == type) {
					clipBottom(canvas, paint, radiusInPx, width, height);
				} else {
					clipAll(canvas, paint, radiusInPx, width, height);
				}

				paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));

				// 帖子图
				final Rect src = new Rect(0, 0, width, height);
				canvas.drawBitmap(bitmap, src, src, paint);
				return paintingBoard;
			} catch (Exception exp) {
				return bitmap;
			}
		}

		private static void clipLeft(final Canvas canvas, final Paint paint,
									 int offset, int width, int height) {
			final Rect block = new Rect(offset, 0, width, height);
			canvas.drawRect(block, paint);
			final RectF rectF = new RectF(0, 0, offset * 2, height);
			canvas.drawRoundRect(rectF, offset, offset, paint);
		}

		private static void clipRight(final Canvas canvas, final Paint paint,
									  int offset, int width, int height) {
			final Rect block = new Rect(0, 0, width - offset, height);
			canvas.drawRect(block, paint);
			final RectF rectF = new RectF(width - offset * 2, 0, width, height);
			canvas.drawRoundRect(rectF, offset, offset, paint);
		}

		private static void clipTop(final Canvas canvas, final Paint paint,
									int offset, int width, int height) {
			final Rect block = new Rect(0, offset, width, height);
			canvas.drawRect(block, paint);
			final RectF rectF = new RectF(0, 0, width, offset * 2);
			canvas.drawRoundRect(rectF, offset, offset, paint);
		}

		private static void clipBottom(final Canvas canvas, final Paint paint,
									   int offset, int width, int height) {
			final Rect block = new Rect(0, 0, width, height - offset);
			canvas.drawRect(block, paint);
			final RectF rectF = new RectF(0, height - offset * 2, width, height);
			canvas.drawRoundRect(rectF, offset, offset, paint);
		}

		private static void clipAll(final Canvas canvas, final Paint paint,
									int offset, int width, int height) {
			final RectF rectF = new RectF(0, 0, width, height);
			canvas.drawRoundRect(rectF, offset, offset, paint);
		}
	}

	public static void recycleSilently(Bitmap bitmap) {
		if (bitmap == null) return;
		try {
			bitmap.recycle();
		} catch (Throwable t) {
			Log.w(TAG, "unable recycle bitmap", t);
		}
	}

	public static Bitmap createVideoThumbnail(String filePath) {
		// MediaMetadataRetriever is available on API Level 8
		// but is hidden until API Level 10
		Class<?> clazz = null;
		Object instance = null;
		try {
			clazz = Class.forName("android.media.MediaMetadataRetriever");
			instance = clazz.newInstance();
			Method method = clazz.getMethod("setDataSource", String.class);
			method.invoke(instance, filePath);

			// The method name changes between API Level 9 and 10.
			if (Build.VERSION.SDK_INT <= 9) {
				return (Bitmap) clazz.getMethod("captureFrame").invoke(instance);
			} else {
				byte[] data = (byte[]) clazz.getMethod("getEmbeddedPicture").invoke(instance);
				if (data != null) {
					Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
					if (bitmap != null) return bitmap;
				}
				Bitmap bitmap = (Bitmap) clazz.getMethod("getFrameAtTime").invoke(instance);
				return bitmap;
				/// @}
			}
		} catch (IllegalArgumentException ex) {
			// Assume this is a corrupt video file
		} catch (RuntimeException ex) {
			// Assume this is a corrupt video file.
		} catch (InstantiationException e) {
			Log.e(TAG, "createVideoThumbnail", e);
		} catch (InvocationTargetException e) {
			Log.e(TAG, "createVideoThumbnail", e);
		} catch (ClassNotFoundException e) {
			Log.e(TAG, "createVideoThumbnail", e);
		} catch (NoSuchMethodException e) {
			Log.e(TAG, "createVideoThumbnail", e);
		} catch (IllegalAccessException e) {
			Log.e(TAG, "createVideoThumbnail", e);
		} finally {
			try {
				if (instance != null) {
					clazz.getMethod("release").invoke(instance);
				}
			} catch (Exception ignored) {
			}
		}
		return null;
	}

    public static byte[] compressToBytes(Bitmap bitmap, int quality) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(65536);
        bitmap.compress(CompressFormat.JPEG, quality, baos);
        return baos.toByteArray();
    }

    public static Bitmap alignBitmapToEven(Bitmap bitmap, boolean recycle) {
        int h = bitmap.getHeight();
        int w = bitmap.getWidth();
        int targetW = w + w % 2;
        int targetH = h + h % 2;

        if (targetW == w && targetH == h)
            return bitmap;
        else {
            Bitmap res = Bitmap.createScaledBitmap(bitmap, targetW, targetH,
                                                   true);
            bitmap.recycle();
            return res;
        }
    }

    // replace Bitmap's back ground with specified color
    public static Bitmap replaceBackgroundColor(Bitmap bitmap, int color,
                                                boolean recycleInput) {
        if (null == bitmap) {
            Log.i(TAG, "<replaceBackgroundColor> Input bitmap == null, return null");
            return null;
        }
        if (bitmap.getConfig() == Bitmap.Config.RGB_565) {
            Log.i(TAG, "<replaceBackgroundColor> no alpha, return");
            return bitmap;
        }
        // Bitmap has alpha channel, and should be replace its background color
        // 1,create a new bitmap with same dimension and ARGB_8888
        if (bitmap.getWidth() <= 0 || bitmap.getHeight() <= 0) {
            Log.w(TAG, "<replaceBackgroundColor> invalid Bitmap dimension");
            return bitmap;
        }
        Bitmap res = null;
        try {
            res = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(),
                                      Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError e) {
            Log.e(TAG, "<replaceBackgroundColor> out of memory", e);
            return bitmap;
        }
        // framework handled out-of-memory exception will lead to null res
        if (res == null) {
            return bitmap;
        }

        // 2,create Canvas to encapulate new Bitmap
        Canvas canvas = new Canvas(res);
        // 3,draw background color
        canvas.drawColor(color);
        // 4,draw original Bitmap on background
        canvas.drawBitmap(bitmap, new Matrix(), null);
        // 5,recycle original Bitmap if needed
        if (recycleInput) {
            bitmap.recycle();
            bitmap = null;
        }
        // 6,return the output Bitmap
        return res;
    }

    public static int retrieveVideoDurationMs(String path) {
        int durationMs = 0;
        // Calculate the duration of the destination file.
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(path);
        } catch (Exception ex) {
            //Assume this is a corrupt video file
            ex.printStackTrace();
        }
        String duration = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION);
        if (duration != null) {
            durationMs = Integer.parseInt(duration);
        }
        retriever.release();
        return durationMs;
    }

}
