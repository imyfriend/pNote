package iyf.exdroid.support.common.utils;

import java.util.HashMap;
import java.util.Map;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build;

@SuppressWarnings("unused")
public class SharedPrefUtils {

    private static Map<String, SharedPrefUtils> map = new HashMap<>();

    public synchronized static SharedPrefUtils getInstance(String prefName) {
        if (map.containsKey(prefName)) {
            return map.get(prefName);
        } else {
            SharedPrefUtils instance = new SharedPrefUtils(prefName);
            map.put(prefName, instance);
            return instance;
        }
    }

    public synchronized static void clear() {
        map.clear();
        map = null;
    }

    private SharedPrefUtils(String prefName) {
        sharedPreferenceName = prefName;
    }

    private final String sharedPreferenceName;

    private int getSharedModeBySDKVersion(@SuppressWarnings("SameParameterValue") int mode) {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.GINGERBREAD) {
            //noinspection deprecation
            mode |= Context.MODE_MULTI_PROCESS;
        }
        return mode;
    }

    public synchronized boolean contains(Context ctx, String key) {
        int mode = getSharedModeBySDKVersion(Context.MODE_PRIVATE);
        return contains(ctx, sharedPreferenceName, key, mode);
    }

    public synchronized boolean contains(Context ctx, String prefs, String key, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        return sharedPreferences.contains(key);
    }

    public synchronized void remove(Context ctx, String key) {
        int mode = getSharedModeBySDKVersion(Context.MODE_PRIVATE);
        remove(ctx, sharedPreferenceName, key, mode);
    }

    public synchronized void remove(Context ctx, String prefs, String key, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        Editor editor = sharedPreferences.edit();
        editor.remove(key);
        editor.apply();
    }

    // String 操作
    public synchronized void putString(Context ctx, String key, String value) {
        int mode = getSharedModeBySDKVersion(Context.MODE_PRIVATE);
        putString(ctx, sharedPreferenceName, key, value, mode);
    }

    public synchronized void putString(Context ctx, String prefs, String key, String value, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public synchronized String getString(Context ctx, String key, String defValue) {
        //noinspection deprecation
        return getString(ctx, sharedPreferenceName, key, defValue, Context.MODE_MULTI_PROCESS);
    }

    public synchronized String getString(Context ctx, String prefs, String key, String defValue, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        return sharedPreferences.getString(key, defValue);
    }

    // int 操作
    public synchronized void putInt(Context ctx, String key, int value) {
        int mode = getSharedModeBySDKVersion(Context.MODE_PRIVATE);
        putInt(ctx, sharedPreferenceName, key, value, mode);
    }

    public synchronized void putInt(Context ctx, String prefs, String key, int value, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        Editor editor = sharedPreferences.edit();
        editor.putInt(key, value);
        editor.apply();
    }

    public synchronized int getInt(Context ctx, String key, int defValue) {
        int mode = getSharedModeBySDKVersion(Context.MODE_PRIVATE);
        return getInt(ctx, sharedPreferenceName, key, defValue, mode);
    }

    public synchronized static int getInt(Context ctx, String prefs, String key, int defValue, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        return sharedPreferences.getInt(key, defValue);
    }

    // Long 操作
    public synchronized void putLong(Context ctx, String key, Long value) {
        int mode = getSharedModeBySDKVersion(Context.MODE_PRIVATE);
        putLong(ctx, sharedPreferenceName, key, value, mode);
    }

    public synchronized void putLong(Context ctx, String prefs, String key, Long value, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        Editor editor = sharedPreferences.edit();
        editor.putLong(key, value);
        editor.apply();
    }

    public synchronized Long getLong(Context ctx, String key, Long defValue) {
        int mode = getSharedModeBySDKVersion(Context.MODE_PRIVATE);
        return getLong(ctx, sharedPreferenceName, key, defValue, mode);
    }

    public synchronized Long getLong(Context ctx, String prefs, String key, Long defValue, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        return sharedPreferences.getLong(key, defValue);
    }

    // Float 操作
    public synchronized void putFloat(Context ctx, String key, Float value) {
        int mode = getSharedModeBySDKVersion(Context.MODE_PRIVATE);
        putFloat(ctx, sharedPreferenceName, key, value, mode);
    }

    public synchronized void putFloat(Context ctx, String prefs, String key, Float value, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        Editor editor = sharedPreferences.edit();
        editor.putFloat(key, value);
        editor.apply();
    }

    public synchronized Float getFloat(Context ctx, String key, Float defValue) {
        int mode = getSharedModeBySDKVersion(Context.MODE_PRIVATE);
        return getFloat(ctx, sharedPreferenceName, key, defValue, mode);
    }

    public synchronized Float getFloat(Context ctx, String prefs, String key, Float defValue, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        return sharedPreferences.getFloat(key, defValue);
    }

    // boolean 操作
    public synchronized void putBoolean(Context ctx, String key, boolean value) {
        int mode = getSharedModeBySDKVersion(Context.MODE_PRIVATE);
        putBoolean(ctx, sharedPreferenceName, key, value, mode);
    }

    public synchronized void putBoolean(Context ctx, String prefs, String key, boolean value, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        Editor editor = sharedPreferences.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    public synchronized boolean getBoolean(Context ctx, String key, boolean defValue) {
        int mode = getSharedModeBySDKVersion(Context.MODE_PRIVATE);
        return getBoolean(ctx, sharedPreferenceName, key, defValue, mode);
    }

    public synchronized boolean getBoolean(Context ctx, String prefs, String key, boolean defValue, int mode) {
        SharedPreferences sharedPreferences = ctx.getSharedPreferences(prefs, mode);
        return sharedPreferences.getBoolean(key, defValue);
    }
}
