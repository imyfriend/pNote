package iyf.exdroid.support.common.utils;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.telecom.PhoneAccount;
import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.telecom.VideoProfile;
import android.text.TextUtils;
import android.util.Log;

import java.util.List;

/**
 * 类名称：CallUtils
 * 作者：David
 * 内容摘要：Utilities related to calls that can be used by non system apps. These
 *                  use {@link Intent#ACTION_CALL} instead of ACTION_CALL_PRIVILEGED.
 * 创建日期：2016/12/21
 * 修改者， 修改日期， 修改内容
 */
public class CallUtils {
    ///M: @{
    public static final String SCHEME_SMSTO = "smsto";
    public static final String SCHEME_MAILTO = "mailto";
    public static final String EXTRA_CALL_ORIGIN = "com.android.phone.CALL_ORIGIN";
    public static final String EXTRA_IS_VIDEO_CALL = "com.android.phone.extra.video";
    public static final String EXTRA_IS_IP_DIAL = "com.android.phone.extra.ip";
    //VOLTE IMS Call feature.
    public static final String EXTRA_IS_IMS_CALL = "com.mediatek.phone.extra.ims";

    public static final int DIAL_NUMBER_INTENT_NORMAL = 0;
    public static final int DIAL_NUMBER_INTENT_IP = 1;
    public static final int DIAL_NUMBER_INTENT_VIDEO = 2;
    //VOLTE IMS Call feature.
    public static final int DIAL_NUMBER_INTENT_IMS = 4;
    ///@}

    private static final String TAG = "CallUtil";
    ///@}

    /**
     * Return an Intent for making a phone call. Scheme (e.g. tel, sip) will be determined
     * automatically.
     */
    public static Intent getCallIntent(String number) {
        return getCallIntent(getCallUri(number));
    }

    /**
     * Return an Intent for making a phone call. A given Uri will be used as is (without any
     * sanity check).
     */
    public static Intent getCallIntent(Uri uri) {
        return new Intent(Intent.ACTION_CALL, uri);
    }

    /**
     * A variant of {@link #getCallIntent} for starting a video call.
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    public static Intent getVideoCallIntent(String number, String callOrigin) {
        final Intent intent = new Intent(Intent.ACTION_CALL, getCallUri(number));
        intent.putExtra(TelecomManager.EXTRA_START_CALL_WITH_VIDEO_STATE,
                Build.VERSION.SDK_INT >= 23 ? VideoProfile.STATE_BIDIRECTIONAL : (0x1 | 0x2));
        if (!TextUtils.isEmpty(callOrigin)) {
            intent.putExtra(EXTRA_CALL_ORIGIN, callOrigin);
        }
        return intent;
    }

    /**
     * Return Uri with an appropriate scheme, accepting both SIP and usual phone call
     * numbers.
     */
    public static Uri getCallUri(String number) {
        if (PhoneNumberUtils.isUriNumber(number)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Uri.fromParts(PhoneAccount.SCHEME_SIP, number, null);
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Uri.fromParts(PhoneAccount.SCHEME_TEL, number, null);
        }
        return null;
    }

    /**
     * Determines if one of the call capable phone accounts defined supports video calling.
     *
     * @param context The context.
     * @return {@code true} if one of the call capable phone accounts supports video calling,
     *      {@code false} otherwise.
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    public static boolean isVideoEnabled(Context context) {
        TelecomManager telecomManager = (TelecomManager)
                context.getSystemService(Context.TELECOM_SERVICE);
        if (telecomManager == null) {
            return false;
        }

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return false;
        }
        List<PhoneAccountHandle> accountHandles = telecomManager.getCallCapablePhoneAccounts();
        for (PhoneAccountHandle accountHandle : accountHandles) {
            PhoneAccount account = telecomManager.getPhoneAccount(accountHandle);
            if (account != null && account.hasCapabilities(PhoneAccount.CAPABILITY_VIDEO_CALLING)) {
                //return true;
                return false;
            }
        }
        return false;
    }

    /**
     * M:
     * @param uri
     * @param callOrigin
     * @param type
     * @return
     */
    public static Intent getCallIntent(Uri uri, String callOrigin, int type) {
        final Intent intent = new Intent(Intent.ACTION_CALL, uri);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (callOrigin != null) {
            intent.putExtra(EXTRA_CALL_ORIGIN, callOrigin);
        }
        if ((type & DIAL_NUMBER_INTENT_IP) != 0) {
            intent.putExtra(EXTRA_IS_IP_DIAL, true);
        }

        if ((type & DIAL_NUMBER_INTENT_VIDEO) != 0) {
            intent.putExtra(EXTRA_IS_VIDEO_CALL, true);
        }

        //M: VOLTE IMS Call feature @{
        if ((type & DIAL_NUMBER_INTENT_IMS) != 0) {
            Log.d(TAG, "VOLTE Ims Call put extra 'com.mediatek.phone.extra.ims' true.");
            intent.putExtra(EXTRA_IS_IMS_CALL, true);
        }
        ///@}
        return intent;
    }
}
