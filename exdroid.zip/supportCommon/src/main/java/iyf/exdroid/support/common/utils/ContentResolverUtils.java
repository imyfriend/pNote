package iyf.exdroid.support.common.utils;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

/**
 * Created by ii on 2017/3/17.
 */

public class ContentResolverUtils {
    public interface ContentResolverQueryCallback {
        void onCursorResult(Cursor cursor);
    }

    public static void querySource(ContentResolver contentResolver, Uri uri,
                                    String[] projection, ContentResolverQueryCallback callback) {
        Cursor cursor = null;
        try {
            //query from "content://....."
            cursor = contentResolver.query(uri, projection, null, null, null);
            //query from "file:///......"
            if (cursor == null) {
                String data = Uri.decode(uri.toString());
                if (data == null) {
                    return;
                }
                data = data.replaceAll("'", "''");
                final String where = "_data LIKE '%" + data.replaceFirst("file:///", "") + "'";
                cursor = contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                                               projection, where, null, null);
            }
            if ((cursor != null) && cursor.moveToNext()) {
                callback.onCursorResult(cursor);
            }
        } catch (Exception e) {
            // Ignore error for lacking the data column from the source.
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }


}
