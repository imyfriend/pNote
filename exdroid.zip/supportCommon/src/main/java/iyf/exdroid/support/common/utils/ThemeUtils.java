package iyf.exdroid.support.common.utils;

import android.content.res.Resources;
import android.os.Build;
import android.util.TypedValue;

@SuppressWarnings("unused")
public final class ThemeUtils {
    /**
     * Resolves the given attribute id of the theme to a resource id
     */
    @SuppressWarnings("all")
    public static int getAttribute(Resources.Theme theme, int attrId) {
        final TypedValue outValue = new TypedValue();
        theme.resolveAttribute(attrId, outValue, true);
        return outValue.resourceId;
    }

    /**
     * Returns the resource id of the background used for buttons to show pressed and focused state
     */
    @SuppressWarnings("unused")
    public static int getSelectableItemBackground(Resources.Theme theme) {
        return getAttribute(theme, android.R.attr.selectableItemBackground);
    }

    @SuppressWarnings("unused")
    public static int getSelectableItemBackgroundBorderless(Resources.Theme theme) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            return getAttribute(theme, android.R.attr.selectableItemBackgroundBorderless);
        } else {
            return -1;
        }
    }

    /**
     * Returns the resource id of the background used for list items that show activated background
     */
    @SuppressWarnings("unused")
    public static int getActivatedBackground(Resources.Theme theme) {
        return getAttribute(theme, android.R.attr.activatedBackgroundIndicator);
    }
}
