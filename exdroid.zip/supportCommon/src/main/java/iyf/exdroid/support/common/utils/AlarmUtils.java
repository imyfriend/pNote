package iyf.exdroid.support.common.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/**
 * 类名称：AlarmUtils
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/21
 * 修改者， 修改日期， 修改内容
 */
public class AlarmUtils {
    /**
     * 开启定时器
     * @param context
     * @param triggerAtMillis
     * @param pendingIntent
     */
    public static void start(Context context, int triggerAtMillis, PendingIntent pendingIntent) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        manager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
    }

    /**
     * 停止定时器
     * @param context
     * @param pendingIntent
     */
    public static void stop(Context context, PendingIntent pendingIntent) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        manager.cancel(pendingIntent);
    }

    /**
     * 开启轮询闹钟
     * @param context
     * @param triggerAtMillis
     * @param cls
     * @param action
     */
    public static void start(Context context, int triggerAtMillis, Class<?> cls, String action) {
        Intent intent = new Intent(context, cls);
        intent.setAction(action);
        PendingIntent pendingIntent = PendingIntent.getService(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        start(context, triggerAtMillis, pendingIntent);
    }

    /**
     * 停止轮询闹钟
     * @param context
     * @param cls
     * @param action
     */
    public static void stop(Context context, Class<?> cls, String action) {
        Intent intent = new Intent(context, cls);
        intent.setAction(action);
        PendingIntent pendingIntent = PendingIntent.getService(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        stop(context, pendingIntent);
    }

}
