package iyf.exdroid.support.common.utils;

import java.io.File;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;

@SuppressWarnings("unused")
@SuppressLint("SdCardPath")
public final class MemoryUtils {
	private static final String TAG = "MemoryUtils";
	private static final boolean DEBUG = true;

	/**
	 * 计算剩余空间
	 * 
	 * @param path
	 */
	@SuppressWarnings({"deprecation", "JavaDoc"})
	@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
	private static long getAvailableSize(String path) {
		if (DEBUG) {
			Log.d(TAG, "in getAvailableSize(path: " + path + ")");
		}
		StatFs fileStats = new StatFs(path);
		fileStats.restat(path);
		long avaiableSize;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
			avaiableSize = fileStats.getAvailableBlocksLong() * fileStats.getBlockSizeLong();
		} else {
			avaiableSize = (long) fileStats.getAvailableBlocks() * fileStats.getBlockSize();
		}
		return avaiableSize;
	}

	/**
	 * 计算总空间
	 * 
	 * @param path
	 */
	@SuppressWarnings({"deprecation", "JavaDoc"})
	@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
	private static long getTotalSize(String path) {
		if (DEBUG) {
			Log.d(TAG, "in getTotalSize(path: " + path + ")");
		}
		StatFs fileStats = new StatFs(path);
		fileStats.restat(path);
		long totalSize;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
			totalSize = fileStats.getBlockCountLong() * fileStats.getBlockSizeLong();
		} else {
			totalSize = (long) fileStats.getBlockCount() * fileStats.getBlockSize();
		}
		return totalSize;
	}

	/**
	 * 计算SD卡的剩余空间
	 * 
	 * @return 剩余空间
	 */
	@SuppressWarnings("WeakerAccess")
	public static long getSDAvailableSize() {
		if (DEBUG) {
			Log.d(TAG, "in getSDAvailableSize()");
		}
		if (Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {
			return getAvailableSize(Environment.getExternalStorageDirectory()
					.toString());
		}

		return 0;
	}

	/**
	 * 计算系统的剩余空间
	 * 
	 * @return 剩余空间
	 */
	@SuppressWarnings("WeakerAccess")
	public static long getSystemAvailableSize() {
		if (DEBUG) {
			Log.d(TAG, "in getSystemAvailableSize()");
		}
		return getAvailableSize("/data");
	}

	/**
	 * 是否有足够的空间
	 * 
	 * @param filePath
	 *            文件路径，不是目录的路径
	 */
	public static boolean hasEnoughMemory(String filePath) {
		if (DEBUG) {
			Log.d(TAG, "in hasEnoughMemory(filePath: " + filePath + ")");
		}
		File file = new File(filePath);
		long length = file.length();

		if (filePath.startsWith("/sdcard")
				|| filePath.startsWith("/mnt/sdcard")) {
			return getSDAvailableSize() > length;
		} else {
			return getSystemAvailableSize() > length;
		}
	}

	public static boolean hasSpaceForSize(long size) {
		String state = Environment.getExternalStorageState();
		if (!Environment.MEDIA_MOUNTED.equals(state)) {
			return false;
		}

		String path = Environment.getExternalStorageDirectory().getPath();
		try {
			StatFs stat = new StatFs(path);
			if (Build.VERSION.SDK_INT  < 18) {
				return stat.getAvailableBlocks() * (long) stat.getBlockSize() > size;
			} else {
				return stat.getAvailableBlocksLong() * stat.getBlockSizeLong() > size;
			}
		} catch (Exception e) {
			Log.i(TAG, "Fail to access external storage", e);
		}
		return false;
	}

	/**
	 * 获取SD卡的总空间
	 */
	public static long getSDTotalSize() {
		if (DEBUG) {
			Log.d(TAG, "in getSDTotalSize()");
		}
		if (Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {
			return getTotalSize(Environment.getExternalStorageDirectory()
					.toString());
		}

		return 0;
	}

	/**
	 * 获取系统可读写的总空间
	 */
	public static long getSysTotalSize() {
		if (DEBUG) {
			Log.d(TAG, "in getSysTotalSize()");
		}
		return getTotalSize("/data");
	}

	/**
	 * Checks if SD card available
	 *
	 * @return boolean
	 */
	public static boolean isExternalStorageAvailable() {
		String state = Environment.getExternalStorageState();
		return Environment.MEDIA_MOUNTED.equals(state)
				|| Environment.MEDIA_MOUNTED_READ_ONLY.equals(state);
	}
}
