package iyf.exdroid.support.common.Java8Lambda;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;

/**
 * Created by imyfriend on 2017/6/24.
 */

public class Chapter3 {
    @Test
    public void test_collect() {
        List<String> collected = Stream.of("a", "b", "c")
                .filter(it -> {
                    System.out.println("it=" + it);
                    return true;
                })
                .collect(Collectors.toList());
        assertEquals(Arrays.asList("a", "b", "c"), collected);
        //System.out.println(collected.toArray(new String[1]).toString());
        for (String item :collected.toArray(new String[1])) {
            System.out.println("item=" + item);
        }

    }
}
