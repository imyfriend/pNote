package iyf.exdroid.support.common.guava;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Multiset;
import com.google.common.collect.Table;

import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

/**
 * 类名称：GuavaTableTest
 * 作者：David
 * 内容摘要：Table是Guava提供的一个接口 Interface Table<R,C,V>，由rowKey+columnKey+value组成
 * 创建日期：2016/12/28
 * 修改者， 修改日期， 修改内容
 */
// http://blog.csdn.net/bazingaea/article/details/51233969
/*
主要使用的方法有：
* 所有行数据：cellSet（）
* 所有第一个key值：rowKeySet（）
* 所有课程：columnKeySet（）
* 所有成绩：values（）
* 课程成绩表：rowMap（）+get（stu）/row（stu）
* 学生成绩表 columnMap（）+get（course）/column（course）
*
* 学生    课程      成绩表
    a        javase     80
    b       javaee      90
    c       javame     100
    d       guava       70
 */
// A table is a collection that takes two keys, a row, and a column,
// and maps those keys to a single value.

public class GuavaTableTest {
    // HashBasedTable stores data in Map<R, Map<C, V>>.
    Table<String, String, Integer> tables = HashBasedTable.create();

    @Before
    public void setup() { // 学生-课程-成绩表
        tables.put("a","javase",80);
        tables.put("b","javaee",90);
        tables.put("c","javame",100);
        tables.put("d","guava",70);
    }

    @Test
    public void Table_cellSet() {
        // cellSet用元素类型为Table.Cell<R, C, V>的Set表现Table<R, C, V>。Cell类似于Map.Entry，但它是用行和列两个键区分的
        Set<Table.Cell<String,String,Integer>> cells = tables.cellSet();
        for(Table.Cell<String,String,Integer> temp : cells){
            System.out.println(temp.getRowKey()+" "+temp.getColumnKey()+" "+temp.getValue());
        }
        /*
        a javase 80
        b javaee 90
        c javame 100
        d guava 70
         */
    }

    @Test
    public void Table_rowKeySet() {
        Set<String> students=tables.rowKeySet();
        for(String str : students){
            System.out.print(str+"\t");
        }
        // a	b	c	d
    }

    @Test
    public void Table_columnKeySet() {
        Set<String> courses=tables.columnKeySet();
        for(String str : courses){
            System.out.print(str+"\t");
        }
        // javase	javaee	javame	guava
    }

    @Test
    public void Table_values() {
        Collection<Integer> scores=tables.values();
        for(Integer in : scores){
            System.out.print(in+"\t");
        }
        // 80	90	100	70
    }

    @Test
    public void Table_rowMap() {
        Set<String> students=tables.rowKeySet();
        for(String str : students){
            Map<String,Integer> rowMap=tables.row(str);
            Set<Map.Entry<String,Integer>> setEntry=rowMap.entrySet();
            for(Map.Entry<String,Integer> entry : setEntry){
                System.out.println(entry.getKey()+" "+entry.getValue());
            }
        }
        /*
        javase 80
        javaee 90
        javame 100
        guava 70
         */
    }

    @Test
    public void Table_columnMap() {
        Set<String> courses=tables.columnKeySet();
        for (String str : courses) {
            Map<String, Integer> rowMap2 = tables.column(str);
            Set<Map.Entry<String, Integer>> setEntry2 = rowMap2.entrySet();
            for (Map.Entry<String, Integer> entry : setEntry2) {
                System.out.println(entry.getKey() + " " + entry.getValue());
            }
        }
        /*
        a 80
        b 90
        c 100
        d 70
         */
    }

    @Test
    public void Table_operations() {
        HashBasedTable<Integer,Integer,String> table = HashBasedTable.create();
        table.put(1,1,"Rook");
        table.put(1,2,"Knight");
        table.put(1,3,"Bishop");
        boolean contains11 = table.contains(1,1);
        System.out.println("contains11=" + contains11); //true
        boolean containColumn2 = table.containsColumn(2);
        System.out.println("containColumn2=" + containColumn2); //true
        boolean containsRow1 = table.containsRow(1);
        System.out.println("containsRow1=" + containsRow1); //true
        boolean containsRook = table.containsValue("Rook");
        System.out.println("containsRook=" + containsRook);//true
        table.remove(1,3);
        System.out.println("table.get(1, 3)=" + table.get(1, 3));//table.get(1,3)=null
        System.out.println("table.get(1, 2)=" + table.get(1, 2));//table.get(1,2)=Knight
    }

    @Test
    public void Table_views() {
        HashBasedTable<Integer,Integer,String> table = HashBasedTable.create();
        table.put(1,1,"11");
        table.put(1,2,"12");
        table.put(1,3,"13");
        table.put(2,1,"21");
        table.put(2,2,"22");
        table.put(2,3,"23");

        // The column method returns a map where the keys are all row-value mappings
        // with the given column's key value.
        Map<Integer,String> columnMap = table.column(1);
        System.out.println("columnMap=" + columnMap);//columnMap={1=11, 2=21}

        // The row method returns the converse, returning
        // column-value mappings with the given row's key value.
        Map<Integer,String> rowMap = table.row(2);
        System.out.println("rowMap=" + rowMap);//rowMap={1=21, 2=22, 3=23}
    }

    /*
    1. ArrayTable is an implementation of the table backed by a
two-dimensional array.
    2. There is an ImmutableTable implementation. Since ImmutableTable
can't be updated after it's created, the row, key, and values are added
using ImmutableTable.Builder, which leverages a ﬂuent interface
for ease of construction.
    3. A TreeBasedTable table where the row and column keys are ordered,
either by the natural order or by specifed comparators for the row and
column keys.
     */

}
