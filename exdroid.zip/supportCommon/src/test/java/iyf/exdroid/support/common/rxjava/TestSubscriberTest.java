package iyf.exdroid.support.common.rxjava;

import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import rx.Observable;
import rx.observers.TestSubscriber;

/**
 * Created by admin on 2017/8/24.
 */

public class TestSubscriberTest {
    @Test
    public void test_001() {
        TestSubscriber<Integer> subscriber =
                new TestSubscriber<>();
        Observable.just(1,2,3).subscribe(subscriber);

        List<Integer> expected = Arrays.asList(1,2,3);
        Assert.assertEquals(expected, subscriber.getOnNextEvents());

        Assert.assertSame(1, subscriber.getCompletions());

        Assert.assertTrue(subscriber.getOnErrorEvents().isEmpty());

        Assert.assertTrue(subscriber.isUnsubscribed());
    }

    @Test
    public void test_002() {
        TestSubscriber<Integer> subscriber =
                new TestSubscriber<>();
        Observable.just(1,2,3).subscribe(subscriber);

        List<Integer> expected = Arrays.asList(1,2,3);
        subscriber.assertReceivedOnNext(expected);
        subscriber.assertTerminalEvent();
        subscriber.assertNoErrors();
        subscriber.assertUnsubscribed();
    }




}
