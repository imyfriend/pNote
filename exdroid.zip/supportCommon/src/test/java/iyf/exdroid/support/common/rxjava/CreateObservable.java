package iyf.exdroid.support.common.rxjava;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.observables.ConnectableObservable;

/**
 * Created by ii on 2017/4/27.
 */

public class CreateObservable {

    public static ConnectableObservable<String> from(final InputStream stream) {
        return from(new BufferedReader(new InputStreamReader(stream)));
    }

    public static ConnectableObservable<String> from(final BufferedReader reader) {
        return Observable.create(new OnSubscribe<String>() {

            /*
            This call(Subscriber) method is used to implement the behavior of the Observable instance because the Subscriber
            instance passed to it can be used to emit messages to the Observable instance's subscriber. A subscriber is the client
            of an Observable instance, which consumes its notifications.
             */
            @Override
            public void call(Subscriber<? super String> subscriber) {
                try {
                    String line;

                    if (subscriber.isUnsubscribed()) {
                        return;
                    }

                    while (!subscriber.isUnsubscribed() && (line = reader.readLine()) != null) {
                        if (line.equals("exit")) {
                            break;
                        }
                        System.out.println("in CreateObservable.from(), line=" + line);
                        subscriber.onNext(line);
                    }
                } catch (IOException e) {
                    subscriber.onError(e);
                }

                if (!subscriber.isUnsubscribed()) {
                    subscriber.onCompleted();
                }
            }
        }).publish();
    }


}
