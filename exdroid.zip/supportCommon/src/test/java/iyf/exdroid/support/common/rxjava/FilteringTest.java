package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.Arrays;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Func1;

/**
 * Created by imyfriend on 2017/5/15.
 */

public class FilteringTest {
    /*
    Like all the other operators,
filter() creates a new Observable instance from the source. This Observable
instance emits only items that comply to the condition, defined by the filter()
operator.
     */
    @Test
    public void filter() {
        Observable<Integer> numbers = Observable
                .just(1, 13, 32, 45, 21, 8, 98, 103, 55);
        Observable<Integer> filter = numbers.filter(new Func1<Integer, Boolean>() {
            @Override
            public Boolean call(Integer n) {
                return n % 2 == 0;
            }
        });
        subscribePrint(filter, "Filter");
    }

    /*
    The takeLast() operator returns a new Observable instance that emits only the last n
items from the source Observable instance, only when it completes.
     */
    @Test
    public void takeLast() {
        Observable<Integer> numbers = Observable
                .just(1, 13, 32, 45, 21, 8, 98, 103, 55);
        subscribePrint(numbers.takeLast(4), "Last 4");
    }

    /*
    The last() operator outputs only the last
item emitted by the source Observable instance when it completes. If the source doesn't
emit an item, a NoSuchElementException exception will be emitted as an OnError()
notification.
     */
    @Test
    public void last() {
        Observable<?> various = Observable
                .from(Arrays.asList("1", 2, 3.0, 4, 5L));
        subscribePrint(various.last(), "Last");
    }

    /*
    The takeLastBuffer() method behaves much like the takeLast() method, but the
Observable instance created by it emits only one item—a List instance containing the
last N items from the source
     */
    @Test
    public void takeLastBuffer() {
        Observable<?> various = Observable
                .from(Arrays.asList("1", 2, 3.0, 4, 5L));
        subscribePrint(various.takeLastBuffer(4), "Last 4");
    }

    /*
    The lastOrDefault() operator behaves like and has the same overload with a
predicate as the last() operator. However, if the source doesn't emit anything, the lastOrDefault() operator emits the
default value instead of the OnError notification.
     */
    @Test
    public void lastOrDefault() {
        subscribePrint(
                Observable.empty().lastOrDefault(200), "Last or default"
        );
    }

    /*
    The skipLast() operator is the exact opposite of the takeLast() method; it emits
everything except the last N items from the source when it completes
     */
    @Test
    public void skipLast() {
        Observable<Integer> numbers = Observable
                .just(1, 13, 32, 45, 21, 8, 98, 103, 55);
        subscribePrint(numbers.skipLast(4), "Skip last 4");
    }

    /*
    The skip() method is the same as the skipLast() method but skips the first N items
instead of the last
     */
    @Test
    public void skip() {
        Observable<Integer> numbers = Observable
                .just(1, 13, 32, 45, 21, 8, 98, 103, 55);
        subscribePrint(numbers.skip(4), "Skip 4");
    }

    /*
    The take() operator is similar to the takeLast() operator, but instead of the last N
items of the source, it emits the first N items.
     */
    @Test
    public void take() {
        Observable<Integer> numbers = Observable
                .just(1, 13, 32, 45, 21, 8, 98, 103, 55);
        subscribePrint(numbers.take(4), "First 4");
    }

    /*
    The first() operator is similar to the last() operator but emits only the first item
emitted by the source. It emits the same OnError notification if there is no first item. Its
predicate form has an alias— the takeFirst() operator. There is also a
firstOrDefault() operator form of this operator.
     */
    @Test
    public void first() {
        Observable<Integer> numbers = Observable
                .just(1, 13, 32, 45, 21, 8, 98, 103, 55);
        subscribePrint(numbers.firstOrDefault(40), "firstOrDefault 40");
    }

    /*
    The elementAt() operator is similar to the first() and last() operators but has no
    predicate form. There is an elementAtOrDefault() form though. It emits only the
element at the specified index in the sequence of items, emitted by the source
Observable instance.
     */
    @Test
    public void elementAtOrDefault() {
        Observable<Integer> numbers = Observable
                .just(1, 13, 32, 45, 21, 8, 98, 103, 55);
        subscribePrint(numbers.elementAtOrDefault(100, 40), "elementAtOrDefault 40");
    }

    /*
    The Observable instance produced by the distinct() operator emits the items from
the source, excluding the repeated ones.
     */
    @Test
    public void distinct() {
        Observable<String> words = Observable
                .just(
                        "One", "of", "the", "few", "of",
                        "the", "crew", "crew"
                );
        subscribePrint(words.distinct(), "Distinct");
        subscribePrint(words.distinct(new Func1<String, Integer>() {
            @Override
            public Integer call(String s) {
                return s.length();
            }
        }), "Distinct with func1");
    }

    /*
    The distinctUntilChanged() operator is similar to the distinct() method, but the
Observable instance that it returns emits all items emitted by the source Observable
instance that are distinct from their immediate predecessors.
     */
    @Test
    public void distinctUntilChanged() {
        Observable<String> words = Observable
                .just(
                        "One", "of", "the", "few", "of",
                        "the", "crew", "crew"
                );
        subscribePrint(words.distinctUntilChanged(), "distinct Until Changed");
    }

    /*
    The ofType() operator creates an Observable instance that emits only the items
emitted by the source of a given type. It basically is a shortcut to this call: filter(v ->
Class.isInstance(v))
     */
    @Test
    public void ofType() {
        Observable<?> various = Observable
                .from(Arrays.asList("1", 2, 3.0, 4, 5L));
        subscribePrint(various.ofType(Integer.class), "ofType");
    }





    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                        + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }
}
