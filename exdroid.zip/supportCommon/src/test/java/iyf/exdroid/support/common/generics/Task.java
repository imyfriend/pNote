package iyf.exdroid.support.common.generics;

/**
 * Created by imyfriend on 2017/7/15.
 */

public abstract class Task implements Comparable<Task>{
    protected Task() {}

    public boolean equals(Object o) {
        if (o instanceof Task) {
            return toString().equals(o.toString());
        } else {
            return false;
        }
    }

    public int compareTo(Task t) {
        return toString().compareTo(t.toString());
    }

    public int hashCode() {
        return toString().hashCode();
    }

    public abstract String toString();
}

final class CodingTask extends Task {
    private final String spec;

    public CodingTask(String spec) {
        this.spec = spec;
    }

    public String getSpec() {
        return spec;
    }

    public String toString() {
        return "code " + spec;
    }
}

final class PhoneTask extends Task {
    private final String name;
    private final String number;

    public PhoneTask(String name, String number) {
        this.name = name;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public String getNumber() {
        return number;
    }

    @Override
    public String toString() {
        return "phone " + name;
    }
}

class EmptyTask extends Task {
    public EmptyTask() {}

    @Override
    public String toString() {
        return "";
    }
}