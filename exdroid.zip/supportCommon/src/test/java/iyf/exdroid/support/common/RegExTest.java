package iyf.exdroid.support.common;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

/**
 * Created by admin on 2017/8/11.
 */

public class RegExTest {

    @Test
    public void regEx_001() {
        Pattern pattern = Pattern.compile("Java");
        log(pattern.pattern());
        assertThat(pattern.pattern(), equalTo("Java"));
    }

    @Test
    public void regEx_002() {
        Pattern pattern = Pattern.compile("Java", Pattern.CASE_INSENSITIVE);
        String test="123Java456JaVa789JAVA";
        String[] result = pattern.split(test); // 根据匹配模式拆分输入序列
        for(String s : result) {
            log(s);
        }

        List<String> expected = Arrays.asList("123", "456", "789");
        assertThat(Arrays.asList(result), equalTo(expected));
    }

    @Test
    public void regEx_003() {
        /*
        split(CharSequence input， int limit)，当limit值大于所能返回的字符串的最多个数或者为负数，
        返回的字符串个数将不受限制，但结尾可能包含空串，而当limit=0时与split(CharSequence input)等价，
        但结尾的空串会被丢弃。
         */
        Pattern pattern = Pattern.compile("Java");
        String test = "123Java456Java789Java";

        log("pattern.split(test,2): ");
        String[] result = pattern.split(test,2);
        for(String s : result) {
            log(s);
        }
        List<String> expected = Arrays.asList("123", "456Java789Java");
        assertThat(Arrays.asList(result), equalTo(expected));


        log("pattern.split(test,10): ");
        result = pattern.split(test,10);
        System.out.println("length:" + result.length);
        for(String s : result) {
            log(s);
        }
        List<String> expected1 = Arrays.asList("123", "456", "789", "");
        assertThat(Arrays.asList(result), equalTo(expected1));

        log("pattern.split(test,-2): ");
        result = pattern.split(test,-2);
        System.out.println("length:" + result.length);
        for(String s : result) {
            log(s);
        }
        assertThat(Arrays.asList(result), equalTo(expected1));

        log("pattern.split(test,0): ");
        result = pattern.split(test,0);
        System.out.println("length:" + result.length);
        for(String s : result) {
            log(s);
        }
        expected = Arrays.asList("123", "456", "789");
        assertThat(Arrays.asList(result), equalTo(expected));
    }

    @Test
    public void regEx_004() {
        /*
        Pattern类也自带一个静态匹配方法matches(String regex, CharSequence input)，
        但只能进行全字符串匹配并且只能返回是否匹配上的boolean值
         */
        String test1 = "Java";
        String test2 = "Java123456";

        System.out.println(Pattern.matches("Java",test1));//返回true
        System.out.println(Pattern.matches("Java",test2));//返回false
    }

    @Test
    public void matcher_matches_001() {
        /*
        matches()用于全字符串匹配
         */
        Pattern pattern = Pattern.compile("Java");
        String  test1   = "Java";
        String  test2   = "Java1234";

        Matcher matcher = pattern.matcher(test1);
        System.out.println(matcher.matches());//返回true
        assertEquals(matcher.matches(), true);

        matcher = pattern.matcher(test2);
        System.out.println(matcher.matches());//返回false
        assertEquals(matcher.matches(), false);
    }

    @Test
    public void matcher_find_001() {
        /*
        find可以对任意位置字符串匹配,其中start为起始查找索引值。
         */
        Pattern pattern = Pattern.compile("Java");
        String test1 = "Java";
        String test2 = "Java1234";
        String test3 = "1234Java";

        Matcher matcher = pattern.matcher(test1);
        System.out.println(matcher.find());//返回true
        matcher = pattern.matcher(test2);
        System.out.println(matcher.find());//返回true

        matcher = pattern.matcher(test3);
        System.out.println(matcher.find(2));//返回true
        matcher = pattern.matcher(test3);
        System.out.println(matcher.find(5));//返回false
    }

    @Test
    public void matcher_lookingAt_001() {
        /*
        lookingAt从字符串最开头开始匹配满足的子串
         */
        Pattern pattern = Pattern.compile("Java");
        String test1 = "Java";
        String test2 = "Java1234";
        String test3 = "1234Java";
        Matcher matcher = pattern.matcher(test2);
        System.out.println(matcher.lookingAt());//返回true
        matcher = pattern.matcher(test3);
        System.out.println(matcher.lookingAt());//返回false
    }

    /*
    组的概念：组是用括号划分的正则表达式，可以根据组的编号来引用这个组。组号为0表示整个表达式，
    组号为1表示被第一对括号括起的组，依次类推，例如A(B(C))D，组0是ABCD，组1是BC，组2是C。
     */
    @Test
    public void matcher_001() {
        /*
        Matcher类提供了start()，end()，group()分别用于返回字符串的起始索引，结束索引，以及匹配到到的字符串。
         */
        Pattern pattern = Pattern.compile("Java");
        String test = "123Java456";

        Matcher matcher = pattern.matcher(test);
        matcher.find();
        System.out.println(matcher.start());//返回3
        System.out.println(matcher.end());//返回7
        System.out.println(matcher.group());//返回Java
    }

    @Test
    public void matcher_002() {
        Pattern pattern = Pattern.compile("(Java)(Python)");
        String test = "123JavaPython456";
        Matcher matcher = pattern.matcher(test);
        matcher.find();
        System.out.println(matcher.groupCount());//返回2
        assertEquals(matcher.groupCount(), 2);

        System.out.println(matcher.group(1));//返回第一组匹配到的字符串"Java"，注意起始索引是1
        assertEquals(matcher.group(1), "Java");
        System.out.println(matcher.start(1));//返回3，第一组起始索引
        assertEquals(matcher.start(1), 3);
        System.out.println(matcher.end(1));//返回7 第一组结束索引
        assertEquals(matcher.end(1), 7);

        System.out.println(matcher.group(2));//返回第二组匹配到的字符串"Python"
        System.out.println(matcher.start(2));//返回7，第二组起始索引
        System.out.println(matcher.end(2));//返回13 第二组结束索引
    }

    @Test
    public void region_001() {
        Pattern pattern = Pattern.compile("Java");
        String test = "123JavaJava";
        Matcher matcher = pattern.matcher(test);
        matcher.region(7, 11);
        System.out.println(matcher.regionStart());//返回7
        System.out.println(matcher.regionEnd());//返回11
        matcher.find();
        System.out.println(matcher.group());//返回Java
        assertEquals(matcher.group(), "Java");
    }

    @Test
    public void reset_001() {
        Pattern pattern = Pattern.compile("Java");
        String test = "Java";
        Matcher matcher = pattern.matcher(test);

        matcher.find();
        System.out.println(matcher.group());//返回Java
        assertEquals(matcher.group(), "Java");

        matcher.reset();//从起始位置重新匹配

        matcher.find();
        System.out.println(matcher.group());//返回Java
        assertEquals(matcher.group(), "Java");

        matcher.reset("Python");
        System.out.println(matcher.find());//返回false
    }

    @Test
    public void replace_001() {
        /*
        replaceAll(String replacement) 和 replaceFirst(String replacement)，
        其中replaceAll是替换全部匹配到的字符串，而replaceFirst仅仅是替换第一个匹配到的字符串。
         */
        Pattern pattern = Pattern.compile("Java");
        String test = "JavaJava";
        Matcher matcher = pattern.matcher(test);
        System.out.println(matcher.replaceAll("Python"));//返回PythonPython
        System.out.println(matcher.replaceFirst("python"));//返回PythonJava
    }

    @Test
    public void appendReplacement_001() {
        StringBuffer sb = new StringBuffer();
        String replacement = "Smith";
        Pattern pattern = Pattern.compile("Bond");
        Matcher matcher =pattern.matcher("My name is Bond. James Bond. I would like a martini.");
        while(matcher.find()){
            matcher.appendReplacement(sb,replacement);//结果是My name is Smith. James Smith
        }
        log(sb);
        assertEquals(sb.toString(), "My name is Smith. James Smith");
    }

    @Test
    public void appendTail_001() {
        StringBuffer sb = new StringBuffer();
        String replacement = "Smith";
        Pattern pattern = Pattern.compile("Bond");
        Matcher matcher =pattern.matcher("My name is Bond. James Bond. I would like a martini.");
        while(matcher.find()){
            matcher.appendReplacement(sb,replacement);//结果是My name is Smith. James Smith
        }
        matcher.appendTail(sb);
        log(sb);
        assertEquals(sb.toString(), "My name is Smith. James Smith. I would like a martini.");
    }

    @Test
    public void groupTest_001() {
        /*
    组的概念：组是用括号划分的正则表达式，可以根据组的编号来引用这个组。组号为0表示整个表达式，
    组号为1表示被第一对括号括起的组，依次类推，例如A(B(C))D，组0是ABCD，组1是BC，组2是C。
     */
        String regex = "\\w(\\d\\d)(\\w+)";
        String candidate = "x99SuperJava";

        Pattern p = Pattern.compile(regex);
        Matcher matcher = p.matcher(candidate);
        if(matcher.find()){
            int gc = matcher.groupCount();
            for(int i = 0; i <= gc; i++)
                System.out.println("group " + i + " :" + matcher.group(i));
        }
    }

    @Test
    public void groupTest_002() {
        String regex = "\\d\\d";
        String candidate = "x99Super12Java";

        Pattern p = Pattern.compile(regex);
        Matcher matcher = p.matcher(candidate);
        if(matcher.find()){
            int gc = matcher.groupCount();
            for(int i = 0; i <= gc; i++)
                System.out.println("group " + i + " :" + matcher.group(i));
        }

        System.out.println();
        matcher.reset();
        while (matcher.find()) {
            int gc = matcher.groupCount();
            for(int i = 0; i <= gc; i++)
                System.out.println("group " + i + " :" + matcher.group(i));
        }
    }

    static void sleep(int timeout, TimeUnit unit) {
        try {
            unit.sleep(timeout);
        } catch (InterruptedException ignored) {
            //intentionally ignored
        }
    }

    private static void log(Object msg) {
        System.out.println(
                Thread.currentThread().getName() +
                        ": " + msg);
    }

}
