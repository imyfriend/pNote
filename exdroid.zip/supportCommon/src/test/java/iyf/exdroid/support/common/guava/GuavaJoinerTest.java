package iyf.exdroid.support.common.guava;

import com.google.common.base.Charsets;
import com.google.common.base.Joiner;

import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * 类名称：GuavaJoinerTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/27
 * 修改者， 修改日期， 修改内容
 */

// https://my.oschina.net/indestiny/blog/214668
public class GuavaJoinerTest {
    @Test
    public void Joiner_skipNulls() {
        String delimiter = ",";
        // Joiner类一旦创建则不可变，满足不可变性，因此线程安全
        Joiner joiner = Joiner.on(delimiter);

        // 忽略null
        List<String> langs = new ArrayList<>();
        langs.add("hello");
        langs.add(null);
        langs.add("world");
        String excludeNullString = joiner.skipNulls().join(langs);
        System.out.println("excludeNullString=" + excludeNullString);
    }

    @Test
    public void Joiner_useForNull() {
        String delimiter = ",";
        // Joiner类一旦创建则不可变，满足不可变性，因此线程安全
        Joiner joiner = Joiner.on(delimiter);

        // 将null替代为empty字符串
        List<String> langs = new ArrayList<>();
        langs.add("hello");
        langs.add(null);
        langs.add("world");

        String replaceNullString = joiner.useForNull("empty").join(langs);
        System.out.println("replaceNullString: " + replaceNullString);
    }

    @Test
    public void Joiner_joinMultiString() {
        String delimiter = ",";
        // Joiner类一旦创建则不可变，满足不可变性，因此线程安全
        Joiner joiner = Joiner.on(delimiter).skipNulls();
        //joiner.useForNull("empty"); //重复定义null操作会抛异常
        String res = joiner.join(null, "foo", null, "bar");
        System.out.println(res); //foo,bar
    }

    @Test
    public void Joiner_appendTo() {
        //append到StringBuilder
        StringBuilder stringBuilder = new StringBuilder();
        Joiner joiner = Joiner.on(",").skipNulls();
        joiner.appendTo(stringBuilder, "appendTo", null, "StringBuilder");
        System.out.println(stringBuilder); //appendTo,StringBuilder

        List<String> list = new ArrayList<>();
        list.add("item 1");
        list.add("item 2");
        list.add("item 3");
        stringBuilder = new StringBuilder();
        joiner.appendTo(stringBuilder, list);
        System.out.println(stringBuilder); //item 1,item 2,item 3
    }

    @Test
    public void Joiner_mapJoiner() {
        Map<String, String> map = new HashMap<>();
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        Joiner.MapJoiner mapJoiner = Joiner.on(",").withKeyValueSeparator("=");
        String str = mapJoiner.join(map);
        System.out.println(str);//结果如:key3=value3,key2=value2,key1=value1
    }


}
