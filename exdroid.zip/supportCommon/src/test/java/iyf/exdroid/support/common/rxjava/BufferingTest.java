package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Action1;
import rx.functions.Func0;
import rx.functions.Func1;

/**
 * Created by imyfriend on 2017/5/20.
 */

public class BufferingTest {
    /*
    Using the  sample() operator, we can control the emissions of an  Observable instance
using another one, or a time interval.
     */
    @Test
    public void sample() {
        Observable<Long> data = Observable.interval(50L, TimeUnit.MILLISECONDS)
                .sample(
                Observable
                        .interval(100L, TimeUnit.MILLISECONDS)
                        .take(10)
                        .concatWith(
                                Observable
                                        .interval(200L, TimeUnit.MILLISECONDS)
                        )
        );
        subscribePrint(data, "Too many lines");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    /*
    buffer： 它定期从Observable收集数据到一个集合，然后把这些数据集合打包发射，而不是一次发射一个
     */
    @Test
    public void buffer_001() {
        Observable observable = Observable.range(0, 100)
                .buffer(3);
        subscribePrint(observable, "buffer_001");
    }

    /*
    the  buffer(int count, int skip) method, a version of
the  buffer() operator that collects count items and skips skip items
     */
    @Test
    public void buffer_002() {
        Observable observable = Observable.range(0, 100)
                .buffer(3, 20);
        subscribePrint(observable, "buffer_002");
    }

    @Test
    public void buffer_003() {
        Observable observable = Observable.interval(0, 50L, TimeUnit.MILLISECONDS)
                //.timeInterval()
                .buffer(100L, 300L, TimeUnit.MILLISECONDS);
        subscribePrint(observable, "buffer_003");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void buffer_004() {
        Observable observable = Observable.interval(100,TimeUnit.MILLISECONDS)
                .take(10)
                .buffer(Observable.interval(250,TimeUnit.MILLISECONDS));

        subscribePrint(observable, "buffer_004");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void buffer_005() {
        Observable observable = Observable.interval(100,TimeUnit.MILLISECONDS)
                .take(10)
                .buffer(new Func0<Observable<Long>>() {
                    @Override
                    public Observable<Long> call() {
                        return Observable.interval(250,TimeUnit.MILLISECONDS);
                    }
                });

        subscribePrint(observable, "buffer_005");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void buffer_006() {
        Observable observable = Observable.interval(100, TimeUnit.MILLISECONDS)
                .take(10)
                .doOnNext(new Action1<Long>() {
                    @Override
                    public void call(Long aLong) {
                        System.out.println("interval aLong=" + aLong);
                    }
                })
                .buffer(Observable.interval(250, TimeUnit.MILLISECONDS), new Func1<Long, Observable<Long>>() {
                    @Override
                    public Observable<Long> call(Long aLong) {
                        System.out.println("aLong=" + aLong);
                        return Observable.timer(200,TimeUnit.MILLISECONDS);
                    }
                });

        subscribePrint(observable, "buffer_006");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    /*
    The  window() operator has exactly the same set of overloads as the  buffer() operator.
The difference is that instead of arrays of the buffered elements, the  Observable
instance created by the  window() operator emits  Observable instances emitting the
collected elements.
     */
    @Test
    public void window_001() {
        Observable observable = Observable.range(0, 10)
                .window(3)
                .flatMap(new Func1<Observable<Integer>, Observable<Integer>>() {
                    @Override
                    public Observable<Integer> call(Observable<Integer> integerObservable) {
                        return integerObservable.count();
                    }
                });
        subscribePrint(observable, "window_001");
    }

    /*
    the window(long timespan, long timeshift, TimeUnit units) method. This
operator collects elements emitted within the timespan interval and skips all the
elements emitted within the timeshift interval. This is repeated until the source
Observable instance is complete.
     */
    @Test
    public void window_002() {
        /*subscribePrint(Observable.interval(50L, TimeUnit.MILLISECONDS), "interval 50");
        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }*/

        Observable observable = Observable.interval(50L, TimeUnit.MILLISECONDS)
                .window(100L, 300L, TimeUnit.MILLISECONDS)
                .flatMap(new Func1<Observable<Long>, Observable<?>>() {
                    @Override
                    public Observable<?> call(Observable<Long> integerObservable) {
                        return integerObservable;
                    }
                });
        subscribePrint(observable, "window_002");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                        + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }

}
