package iyf.exdroid.support.common.rxjava.kind;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import iyf.exdroid.support.common.rxjava.TestSubscriberEx;
import rx.Observable;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.observables.GroupedObservable;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

/**
 * Created by admin on 2017/7/27.
 */

public class TransformingObservables {
    @Test
    public void buffer_001() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.just(2, 3, 5, 6)
                .buffer(3)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
    }

    @Test
    public void flatMap_001() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();

        Observable<Integer> flatMapped = Observable
                .just(-1, 0, 1)
                .map(v -> 2 / v)
                .flatMap(
                        v -> Observable.just(v),
                        e -> Observable.just(0),
                        () -> Observable.just(42)
                        );

        flatMapped.subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertValueCount(2);
        List<Integer> expected = Arrays.asList(-2, 0);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void groupBy_001() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        List<String> albums = Arrays.asList("The Piper at the Gates of Dawn",
                                            "A Saucerful of Secrets",
                                            "More", "Ummagumma", "Atom Heart Mother",
                                            "Meddle", "Obscured by Clouds",
                                            "The Dark Side of the Moon",
                                            "Wish You Were Here", "Animals", "The Wall"
                                           );
        Observable<GroupedObservable<Integer,String>> observable = Observable.from(albums)
                .groupBy(album -> album.split(" ").length)
                .filter(groupedObservable -> (groupedObservable.getKey().longValue() >= 3));
                //.flatMap(groupedObservable -> groupedObservable);

        observable.flatMap(new Func1<GroupedObservable<Integer, String>, GroupedObservable<Integer, String>>() {
           @Override
           public GroupedObservable<Integer, String> call(GroupedObservable<Integer, String> groupedObservable) {
               return groupedObservable;
           }
       }).subscribe(new Action1<String>() {
            @Override
            public void call(String s) {

            }
        });

        //observable.subscribe(subscriber);
        /*observable.subscribe(sub -> {
            Utils.log(sub);
        });*/

        subscriber.assertCompleted();
        subscriber.awaitTerminalEvent();
        subscriber.assertValueCount(6);
    }


}
