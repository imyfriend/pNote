package iyf.exdroid.support.common.generics;

import android.support.annotation.NonNull;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by imyfriend on 2017/6/18.
 */

public class Generics002 {
    class Fruit implements Comparable<Fruit> {
        String name;
        int size;

        @Override
        public int compareTo(@NonNull Fruit o) {
            return this.size < o.size ? -1 :
                    this.size == o.size ? 0 : 1;
        }

        @Override
        public String toString() {
            return "name=" + name
                    + ", size=" + size;
        }
    }

    class Apple extends Fruit {
        Apple(int size) {
            name = "Apple";
            this.size = size;
        }
    }

    class Orange extends Fruit {
        Orange(int size) {
            name = "Orange";
            this.size = size;
        }
    }


    @Test
    public void test() {
        List<Orange> oranges = Arrays.asList(new Orange(3), new Orange(5));
        System.out.println(Collections.max(oranges));

        List<Fruit> fruits = Arrays.asList(new Apple(3), new Orange(5));
        System.out.println(Collections.max(fruits));
    }
}
