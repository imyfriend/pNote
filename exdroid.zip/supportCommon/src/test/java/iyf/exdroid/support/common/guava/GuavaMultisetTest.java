package iyf.exdroid.support.common.guava;

import android.annotation.TargetApi;

import com.google.common.collect.HashMultiset;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Multiset;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * 类名称：GuavaMultisetTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/28
 * 修改者， 修改日期， 修改内容
 */
public class GuavaMultisetTest {
    @Test
    public void Multiset_addAll() {
        String strWorld="wer|dfd|dd|dfd|dda|de|dr";
        String[] words=strWorld.split("\\|");
        List<String> wordList=new ArrayList<String>();
        for (String word : words) {
            wordList.add(word);
        }
        Multiset<String> wordsMultiset = HashMultiset.create();
        wordsMultiset.addAll(wordList);

        for(String key : wordsMultiset.elementSet()){
            System.out.println(key+" count："+wordsMultiset.count(key));
        }
    }

    @Test
    public void Multiset_retainAll() {
        String strWorld="wer|dfd|dd|dfd|dda|de|dr";
        String[] words=strWorld.split("\\|");
        List<String> wordList=new ArrayList<String>();
        for (String word : words) {
            wordList.add(word);
        }
        Multiset<String> wordsMultiset = HashMultiset.create();
        wordsMultiset.addAll(wordList);
        System.out.println("words: " + wordsMultiset); // words: [dd, dda, de, dfd x 2, wer, dr]

        List<String> retainList = ImmutableList.of("dfd");
        wordsMultiset.retainAll(retainList);

        System.out.println("words: " + wordsMultiset); // words: [dfd x 2]
        for(String key : wordsMultiset.elementSet()){
            System.out.println(key+" count："+wordsMultiset.count(key)); // dfd count：2
        }
    }
}
