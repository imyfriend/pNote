package iyf.exdroid.support.common.guava;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

import org.junit.Before;
import org.junit.Test;

import java.util.Iterator;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * 类名称：GuavaFluentIterableTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/2/13
 * 修改者， 修改日期， 修改内容
 */
public class GuavaFluentIterableTest {

    // The FluentIterable class presents a powerful interface for working with Iterable
    // instances in the fluent style of programming. The fluent programming style allows
    // us to chain method calls together, making for a more readable code.

    private Person       person1;
    private Person       person2;
    private Person       person3;
    private Person       person4;
    private List<Person> personList;

    @Before
    public void setUp() {
        person1 = new Person(1, "Wilma", 30);
        person2 = new Person(2, "Fred", 32);
        person3 = new Person(3, "Betty", 31);
        person4 = new Person(4, "Barney", 33);
        personList = Lists.newArrayList(person1, person2, person3,
                                        person4);
    }

    // The FluentIterable.filter method takes a Predicateas an argument. Then
    // every element is examined and retained if the given Predicate holds true for it.
    // If no objects satisfy the Predicate, an empty Iterable will be returned.
    @Test
    public void FluentIterable_filter() {
        FluentIterable<Person> filter = FluentIterable.from(personList).filter(new Predicate<Person>() {
            @Override
            public boolean apply(Person user) {
                return user.getAge() > 31;
            }
        });

        assertThat(Iterables.contains(filter, person2), is(true));
        assertThat(Iterables.contains(filter, person4), is(true));
        assertThat(Iterables.contains(filter, person1), is(false));
        assertThat(Iterables.contains(filter, person3), is(false));

        Iterator<Person> i = filter.iterator();
        while (i.hasNext()) {
            System.out.println("年龄大于31的是：" + i.next().getName());
        }
    }

    // The FluentIterable.transform method is a mapping operation where Function
    // is applied to each element. This yields a new iterable having the same size as the
    // original one, composed of the transformed objects. This differs from the filter
    // method, which may remove any or all of the original elements.
    @Test
    public void FluentIterable_transform() {
        List<String> transformed =
                FluentIterable.from(personList).transform(new Function<Person, String>() {
                    @Override
                    public String apply(Person input) {
                        return Joiner.on('#').join(input.getName(), input.getAge());
                    }
                }).toList();

        assertThat(transformed.get(1), is("Fred#32"));
    }


}
