package iyf.exdroid.support.common.generics;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import org.junit.Test;
import iyf.exdroid.support.common.guava.Person;


/**
 * Created by admin on 2017/7/4.
 */

public class GenericsReflection001 {

    /*
    Type
    它是所有类型的公共接口。包括原始类型、参数化类型、数组类型、类型变量和基本类型。ParameterizedType, TypeVariable, WildcardType,GenericArrayType这四个接口都是它的子接口。
    GenericDeclaration
    这个接口Class、Method、Constructor都有实现，我们就是要用这个接口的getTypeParameters方法，它返回一个TypeVariable[]数组，这个数组里面就是我们定义的类型变量T和K，顺序与我们声明时一样。如果用循环语句将数组打印出来，你会发现只会输出T和K，这可不是我们想要的结果，那么想要获得预期的结果怎么办呢？请继续往下看。
    TypeVariable
    它表示类型变量。比如T，比如K extends Comparable<? super T> & Serializable，这个接口里面有个getBounds()方法，它用来获得类型变量上限的Type数组，如果没有定义上限，则默认设定上限为Object，请注意TypeVariable是接口，实际得到的是TypeVariableImpl实现类，下面几个接口都一样。
    拿T和K来说明，T没有定义任何上限，所以它就有一个默认上限java.lang.Object，实际跟踪代码的时候你会发现T的bounds属性为空，只有在调用了getBounds()方法后，才会有一个Type[1]数组[class java.lang.Object]。而对于K来说，调用了getBounds方法后，得到的数组是[java.lang.Comparable<? super T>, interface java.io.Serializable]，它们的类型却是不一样的，第1个是ParameterizedType，而第二个是Class
    ParameterizedType
    ParameterizedType表示参数化类型，就是上面说的java.lang.Comparable<? super T>，再比如List<T>，List<String>，这些都叫参数化类型。得到Comparable<? super T>之后，再调用getRawType()与getActualTypeArguments()两个方法，就可以得到声明此参数化类型的类(java.lang.Comparable)和实际的类型参数数组([? super T])，而这个? super T又是一个WildcardType类型。
    WildcardType
    它用来描述通配符表达式，上面返回的? super T正好是这个类型。然后调用getUpperBounds()上限和getLowerBounds()下限这两个方法，获得类型变量?的限定类型(上下限)，对于本例的通配符(?)，它的上限为java.lang.Object，下限为T
     */

    /*
        如何才能获取到泛型的类型
        ①.必须具有真实类型的存在
        ②.泛型的类型是明确的如(List<User>是明确的，List<T>是不明确的)
         */

    @Test
    public void testGeneric01() {
        Class<?> cls = String.class;
        List<String> lst = new ArrayList<String>(){}; // 匿名子类
        Type genType = lst.getClass().getGenericSuperclass();
        System.out.println("genType=" + genType);
        Class<?> templatClazz = null;
        if(ParameterizedType.class.isAssignableFrom(genType.getClass())) {
            ParameterizedType parameterizedType = (ParameterizedType) genType;
            templatClazz = (Class) parameterizedType.getActualTypeArguments()[0];
            System.out.println("templatClazz=" + templatClazz + ", ");
            if (templatClazz.isAssignableFrom(cls)) {
                System.out.println("OK!! do it");
            }
        }

    }

    @Test
    public void testGeneric02() {
        Class<?> cls = String.class;
        List<String> lst = new Stack<String>(){};
        Type genType = lst.getClass().getGenericSuperclass();
        System.out.println("genType=" + genType);
        Class<?> templatClazz = null;
        if(ParameterizedType.class.isAssignableFrom(genType.getClass())) {
            ParameterizedType parameterizedType = (ParameterizedType) genType;
            templatClazz = (Class) parameterizedType.getActualTypeArguments()[0];
            System.out.println("templatClazz=" + templatClazz + ", ");
            if (templatClazz.isAssignableFrom(cls)) {
                System.out.println("OK!! do it");
            }
        }

    }

    @Test
    public void test_001() {
        try {
            System.out.println(">>>>>>>>>>>testList>>>>>>>>>>>");
            TestClassA.testList();
            System.out.println("<<<<<<<<<<<testList<<<<<<<<<<<\n");
            System.out.println(">>>>>>>>>>>testMap>>>>>>>>>>>");
            TestClassA.testMap();
            System.out.println("<<<<<<<<<<<testMap<<<<<<<<<<<\n");
            System.out.println(">>>>>>>>>>>testClassA>>>>>>>>>>>");
            new TestClassA().testClassA();
            System.out.println("<<<<<<<<<<<testClassA<<<<<<<<<<<");
        } catch (Exception e) {

        }
    }

    @Test
    public void test_002() {
        try {
            //获得指定方法参数泛型信息
            Method m = Demo.class.getMethod("test01", Map.class,List.class);
            Type[] t = m.getGenericParameterTypes();

            for (Type paramType : t) {
                System.out.println("#"+paramType);
                if(paramType instanceof ParameterizedType){
                    //获取泛型中的具体信息
                    Type[] genericTypes = ((ParameterizedType) paramType).getActualTypeArguments();
                    for (Type genericType : genericTypes) {
                        System.out.println("泛型类型："+genericType);
                    }
                }
            }

            //获得指定方法返回值泛型信息
            Method m2         = Demo.class.getMethod("test02", new Class<?>[]{});
            Type   returnType = m2.getGenericReturnType();
            if(returnType instanceof ParameterizedType){
                Type[] genericTypes = ((ParameterizedType) returnType).getActualTypeArguments();

                for (Type genericType : genericTypes) {
                    System.out.println("返回值，泛型类型："+genericType);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

class  ClassA <T>{
    private T obj;
    public void setObject(T obj) {      this.obj = obj;  }
    public T getObject() {    return obj;   }

    /**
     * 获取T的实际类型
     *
     * Class类的isAssignableFrom是个不常用的方法，感觉这个方法的名字取得不是很好，所以有必要在此解析一下，以免在看源码时产生歧义，这个方法的签名如下：
     * 有两个Class类型的类象，一个是调用isAssignableFrom方法的类对象（后称对象a），以及方法中作为参数的这个类对象（称之为对象b），
     * 这两个对象如果满足以下条件则返回true，否则返回false：
     * 1, a对象所对应类信息是b对象所对应的类信息的父类或者是父接口，简单理解即a是b的父类或接口
     * 2, a对象所对应类信息与b对象所对应的类信息相同，简单理解即a和b为同一个类或同一个接口
     */
    public void testClassA() throws NoSuchFieldException, SecurityException {
        System.out.print("getSuperclass:");
        System.out.println(this.getClass().getSuperclass().getName());
        System.out.print("getGenericSuperclass:");
        Type t = this.getClass().getGenericSuperclass();
        System.out.println(t);
        if (ParameterizedType.class.isAssignableFrom(t.getClass())) {
            System.out.print("getActualTypeArguments:");
            for (Type t1 : ((ParameterizedType) t).getActualTypeArguments()) {
                System.out.print(t1 + ",");
            }
            System.out.println();
        }
    }
}

class TestClassA extends ClassA<String> {
    private List<String>        list;
    private Map<String, Object> map;

    /***
     * 获取List中的泛型
     */
    public static void testList() throws NoSuchFieldException, SecurityException {
        Type t = TestClassA.class.getDeclaredField("list").getGenericType();
        if (ParameterizedType.class.isAssignableFrom(t.getClass())) {
            for (Type t1 : ((ParameterizedType) t).getActualTypeArguments()) {
                System.out.print(t1 + ",");
            }
            System.out.println();
        }
    }

    /***
     * 获取Map中的泛型
     */
    public static void testMap() throws NoSuchFieldException, SecurityException {
        Type t = Test.class.getDeclaredField("map").getGenericType();
        if (ParameterizedType.class.isAssignableFrom(t.getClass())) {
            for (Type t1 : ((ParameterizedType) t).getActualTypeArguments()) {
                System.out.print(t1 + ",");
            }
            System.out.println();
        }
    }
}

class Demo {
    //定义两个带泛型的方法
    public void test01(Map<String, Person> map, List<Person> list) {
        System.out.println("Demo.test01()");
    }

    public Map<Integer, Person> test02() {
        System.out.println("Demo.test02()");
        return null;
    }
}
