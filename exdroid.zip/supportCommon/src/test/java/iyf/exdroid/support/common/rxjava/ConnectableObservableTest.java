package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscription;
import rx.observables.ConnectableObservable;

import static iyf.exdroid.support.common.rxjava.Utils.subscribePrint;

/**
 * Created by admin on 2017/8/21.
 */

public class ConnectableObservableTest {

    @Test
    public void publish_001() {
        Observable<Long> interval = Observable.interval(100L,
                                                        TimeUnit.MILLISECONDS);
        ConnectableObservable<Long> published = interval.publish();

        Subscription                sub1      = subscribePrint(published, "First");
        Subscription                sub2      = subscribePrint(published, "Second");
        published.connect();

        Utils.sleep(500, TimeUnit.MILLISECONDS);
        Subscription sub3 = subscribePrint(published, "Third");
        Utils.sleep(500, TimeUnit.MILLISECONDS);
        sub1.unsubscribe();
        sub2.unsubscribe();
        sub3.unsubscribe();

        Utils.sleep(500, TimeUnit.MILLISECONDS);
    }

    @Test
    public void replay_001() {
        Observable<Long> interval = Observable.interval(100L,
                                                        TimeUnit.MILLISECONDS);
        ConnectableObservable<Long> published = interval.replay();

        Subscription                sub1      = subscribePrint(published, "First");
        Subscription                sub2      = subscribePrint(published, "Second");
        published.connect();

        Utils.sleep(500, TimeUnit.MILLISECONDS);
        Subscription sub3 = subscribePrint(published, "Third");
        Utils.sleep(500, TimeUnit.MILLISECONDS);
        sub1.unsubscribe();
        sub2.unsubscribe();
        sub3.unsubscribe();

        Utils.sleep(500, TimeUnit.MILLISECONDS);
    }

    @Test
    public void refCount_001() {
        Observable<Long> interval = Observable.interval(100L,
                                                        TimeUnit.MILLISECONDS);
        Observable<Long> refCount = interval.publish().refCount();
        Subscription sub1 = subscribePrint(refCount, "First");
        Subscription sub2 = subscribePrint(refCount, "Second");

        Utils.sleep(300, TimeUnit.MILLISECONDS);
        sub1.unsubscribe();
        sub2.unsubscribe();

        //  it will begin emitting the sequence from the beginning
        Subscription sub3 = subscribePrint(refCount, "Third");

        Utils.sleep(300, TimeUnit.MILLISECONDS);
        sub3.unsubscribe();

        Utils.sleep(500, TimeUnit.MILLISECONDS);
    }

    @Test
    public void share_001() {
        Observable<Long> interval = Observable.interval(100L,
                                                        TimeUnit.MILLISECONDS);
        Observable<Long> refCount = interval.share();
        Subscription sub1 = subscribePrint(refCount, "First");
        Subscription sub2 = subscribePrint(refCount, "Second");

        Utils.sleep(300, TimeUnit.MILLISECONDS);
        sub1.unsubscribe();
        sub2.unsubscribe();
        Subscription sub3 = subscribePrint(refCount, "Third");

        Utils.sleep(300, TimeUnit.MILLISECONDS);
        sub3.unsubscribe();

        Utils.sleep(500, TimeUnit.MILLISECONDS);
    }


}
