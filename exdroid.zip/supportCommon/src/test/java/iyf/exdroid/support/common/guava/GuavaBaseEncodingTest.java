package iyf.exdroid.support.common.guava;

import com.google.common.io.BaseEncoding;
import com.google.common.io.Files;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Created by ii on 2017/3/28.
 */

public class GuavaBaseEncodingTest {
    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    private File output = null;

    @Before
    public void setup() {
        try {
            output = temporaryFolder.newFile("output.txt");
            // 向文件写入内容(输出流)
            String            str       = "亲爱的小南瓜！\n";
            String            str1      = "\"Savage, Tom\",Being A Great Cook,Acme Publishers,ISBN-" + "123456,29.99,1\n";
            String            str2      = "\"Smith, Jeff\",Art is Fun,Acme Publishers,ISBN-456789,19.99,2\n";
            String            str3      = "\"Vandeley, Art\",Be an Architect,Acme Publishers,ISBN-" + "234567,49.99,3\n";
            String            str4      = "\"Jones, Fred\",History of Football,Acme Publishers,ISBN-" + "345678,24.99,4\n";
            String            str5      = "\"Timpton, Patty\",Gardening My Way,Acme Publishers,ISBN-" + "4567891,34.99,5\n";
            ArrayList<String> arrayList = new ArrayList<>();
            // arrayList.add(str);
            arrayList.add(str1);
            arrayList.add(str2);
            arrayList.add(str3);
            arrayList.add(str4);
            arrayList.add(str5);

            byte[] bt;

            try {
                FileOutputStream in = new FileOutputStream(output);
                try {
                    for (String string : arrayList) {
                        bt = string.getBytes();
                        in.write(bt, 0, bt.length);
                        // boolean success=true;
                        // System.out.println("写入文件成功");
                    }
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        } catch (Exception e) {

        }
    }

    @Test
    public void BaseEncoding_base64() {
        try {
            byte[]       bytes        = Files.toByteArray(output);
            BaseEncoding baseEncoding = BaseEncoding.base64();
            String       encoded      = baseEncoding.encode(bytes);
            assertThat(baseEncoding.decode(encoded), is(bytes));
        } catch (Exception e) {
            System.out.println("Exception: e=" + e);
        }
    }

}
