package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Func2;

/**
 * Created by imyfriend on 2017/5/15.
 */

public class AccumulatorTest {

    /*
    The scan(Func2) operator takes a function with two arguments as a parameter. Its
result is an Observable instance. The first item, emitted by the result of the scan()
method, is the first item of the source Observable instance. The second item emitted is
created by applying the function that was passed to the scan() method on the previous
item emitted by the result Observable instance and the second item, emitted by the
source Observable instance. The third item, emitted by the scan() method result, is
created by applying the function, passed to the scan() method to the previous item,
emitted by it and the third item emitted by the source Observable instance. This pattern
continues in order to create the rest of the sequence emitted by the Observable instance
creates by the scan() method.
     */
    @Test
    public void scan() {
        Observable<Integer> scan = Observable
                .range(1, 10)
                .scan(new Func2<Integer, Integer, Integer>() {
                    @Override
                    public Integer call(Integer integer, Integer integer2) {
                        return integer + integer2;
                    }
                })
                .doOnNext(System.out::println )
                ;
        subscribePrint(scan, "Sum");
        /*
        using the last() filtering operator emits only the last element,
        It's worth mentioning that there is a reduce(Func2) operator, an
alias for the scan(Func2).last().
         */
        subscribePrint(scan.last(), "Final sum");
    }

    /*
    The scan() operator has one overload which can be used with a seed/initial
parameter. In this case, the function passed to the scan(T, Func2) operator is applied
to the first item emitted by the source and this seed parameter.
     */
    @Test
    public void scan_001() {
        Observable<Integer> scan = Observable
                .range(1, 10)
                .scan(0, new Func2<Integer, Integer, Integer>() {
                    @Override
                    public Integer call(Integer integer, Integer integer2) {
                        return integer + integer2;
                    }
                });
                //.doOnNext(System.out::println );
        subscribePrint(scan, "Final sum");
    }

    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                        + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }
}
