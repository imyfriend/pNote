package iyf.exdroid.support.common.rxjava;

import rx.observers.TestSubscriber;

/**
 * Created by admin on 2017/7/27.
 */

public class TestSubscriberEx<T> extends TestSubscriber<T> {
    @Override
    public void onCompleted() {
        super.onCompleted();
        Utils.log("onCompleted");
    }

    @Override
    public void onError(Throwable e) {
        super.onError(e);
        Utils.log("onError e=" + e);
    }

    @Override
    public void onNext(T t) {
        super.onNext(t);
        Utils.log("onNext t=" + t);
    }

}
