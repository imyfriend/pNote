package iyf.exdroid.support.common.guava;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.SetMultimap;

import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 类名称：GuavaMultimapTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/28
 * 修改者， 修改日期， 修改内容
 */

// Multimap associates more than one value with a given key.

public class GuavaMultimapTest {
    Multimap<String, String> myMultimap = ArrayListMultimap.create();

    @Before
    public void setup() {
        // Adding some key/value
        myMultimap.put("Fruits", "Bannana");
        myMultimap.put("Fruits", "Apple");
        myMultimap.put("Fruits", "Pear");
        myMultimap.put("Fruits", "Pear");
        myMultimap.put("Vegetables", "Carrot");
    }

    // The call to size() takes into account all values found in each List,
    // and not the total number of List instances in the map.
    @Test
    public void Multimap_size() {
        // Getting the size
        int size = myMultimap.size();
        System.out.println(size); // 5
    }

    // the multimap is not a true map.
    // if we need typical map behavior, we would do the following
    @Test
    public void Multimap_asMap() {
        // The call to asMap() returns a map where each key points to the corresponding
        // collection in the original multimap.
        Map<String,Collection<String>> map = myMultimap.asMap();
        System.out.println(map); //{Vegetables=[Carrot], Fruits=[Bannana, Apple, Pear, Pear]}
    }

    @Test
    public void Multimap_value() {
        // Getting values
        Collection<String> fruits = myMultimap.get("Fruits");
        System.out.println(fruits); //  [Bannana, Apple, Pear, Pear]
        System.out.println(ImmutableSet.copyOf(fruits));// [Bannana, Apple, Pear]
    }

    // a call to values() returns a collection containing all 5 values,
    // not a collection containing two lists with three elements each.
    @Test
    public void Multimap_iterate() {
        // Iterating over entire Mutlimap
        for (String value : myMultimap.values()) {
            System.out.println(value);
        }
        System.out.println(myMultimap.values()); //[Carrot, Bannana, Apple, Pear, Pear]
    }

    // ArrayListMulitmap is a map that uses ArrayList to store the values for the given key.
    @Test
    public void Multimap_list() {
        // The method simply creates an empty ArrayListMultimap instance with the
        // default sizes for the keys and ArrayList value.
        ListMultimap<String, String> myMutlimap = ArrayListMultimap.create();
        myMutlimap.put("Fruits", "Bannana");
        myMutlimap.put("Fruits", "Apple");
        myMutlimap.put("Fruits", "Pear");
        myMutlimap.put("Fruits", "Pear"); // List does not force its elements to be unique
        myMutlimap.put("Vegetables", "Carrot");
        System.out.println(myMutlimap); // {Vegetables=[Carrot], Fruits=[Bannana, Apple, Pear, Pear]}

        List<String> myValues = myMutlimap.get("Fruits");  // Returns a List, not a Collection.
        System.out.println(myValues); // [Bannana, Apple, Pear, Pear]
    }

    // HashMultimap is based on hash tables. Unlike ArrayListMultimap, inserting
    // the same key-value pair multiple times is not supported.
    @Test
    public void Multimap_set() {
        HashMultimap<String, String> myMutlimap = HashMultimap.create();
        myMutlimap.put("Fruits", "Bannana");
        myMutlimap.put("Fruits", "Apple");
        myMutlimap.put("Fruits", "Pear");
        myMutlimap.put("Fruits", "Pear");
        myMutlimap.put("Vegetables", "Carrot");
        System.out.println(myMutlimap); // {Vegetables=[Carrot], Fruits=[Apple, Bannana, Pear]}

        Set<String> myValues = myMutlimap.get("Fruits");  // Returns a Set, not a Collection.
        System.out.println(myValues); // [Apple, Bannana, Pear]

        int size = myMutlimap.size(); //only distinct key-value pairs are kept
        System.out.println(size); //4
    }

    @Test
    public void Multimap_remove() {
        // Removing a single value
        myMultimap.remove("Fruits", "Pear");
        System.out.println(myMultimap.get("Fruits")); // [Bannana, Apple, Pear]

        // Remove all values for a key
        myMultimap.removeAll("Fruits");
        System.out.println(myMultimap.get("Fruits")); // [] (Empty Collection!)
    }

    // First, there are three immutable implementations:
    // ImmutableListMultimap, ImmutableMultimap, and ImmutableSetMultimap.
    // There is LinkedHashMultimap, which returns collections for a given key that have
    // the values in the same order as they were inserted.
    // Finally, we have TreeMultimap that keeps the keys and values sorted by their natural order
    // or the order specifed by a comparator.

}
