package iyf.exdroid.support.common.rxjava.kind;

import org.junit.Test;

import rx.Observable;

/**
 * Created by admin on 2017/7/27.
 */

public class MathematicalAggregateOperators {

    @Test
    public void average_001() {
        Observable.just(1, 2, 3).count();

    }


}
