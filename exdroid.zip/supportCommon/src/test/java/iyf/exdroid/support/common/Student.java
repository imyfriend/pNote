package iyf.exdroid.support.common;

import com.google.common.base.Objects;
import com.google.gson.annotations.SerializedName;

/**
 * Created by imyfriend on 2017/7/22.
 */

public class Student {
    /**
     * name : John
     * age : 20
     * grade : {"course":"English","score":100,"level":"A"}
     */

    @SerializedName("name")
    private String mName;
    @SerializedName("age")
    private Integer mAge;
    @SerializedName("grade")
    private GradeBean mGrade;

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public int getAge() {
        return mAge;
    }

    public void setAge(int age) {
        mAge = age;
    }

    public GradeBean getGrade() {
        return mGrade;
    }

    public void setGrade(GradeBean grade) {
        mGrade = grade;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this) //toString
                .omitNullValues() //忽略null属性
                .add("name", mName)
                .add("age", mAge)
                .add("grade", mGrade)
                .toString();
    }

    public static class GradeBean {
        /**
         * course : English
         * score : 100
         * level : A
         */

        @SerializedName("course")
        private String mCourse;
        @SerializedName("score")
        private int mScore;
        @SerializedName("level")
        private String mLevel;

        public String getCourse() {
            return mCourse;
        }

        public void setCourse(String course) {
            mCourse = course;
        }

        public int getScore() {
            return mScore;
        }

        public void setScore(int score) {
            mScore = score;
        }

        public String getLevel() {
            return mLevel;
        }

        public void setLevel(String level) {
            mLevel = level;
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this) //toString
                    .omitNullValues() //忽略null属性
                    .add("course", mCourse)
                    .add("score", mCourse)
                    .add("level", mLevel)
                    .toString();
        }
    }
}
