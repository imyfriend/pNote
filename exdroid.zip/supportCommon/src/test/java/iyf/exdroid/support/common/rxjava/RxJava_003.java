package iyf.exdroid.support.common.rxjava;


import com.google.common.util.concurrent.ThreadFactoryBuilder;

import org.junit.Test;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Scheduler;
import rx.schedulers.Schedulers;

import static java.util.concurrent.Executors.newFixedThreadPool;

/**
 * Created by admin on 2017/7/21.
 */

public class RxJava_003 {
    @Test
    public void test_001() {
        log("Starting");
        final Observable<String> obs = simple();
        log("Created");
        obs.subscribeOn(schedulerA).subscribe(x -> log("Got " + x), Throwable::printStackTrace, () -> log("Completed"));
        log("Exiting");

        sleep(5, TimeUnit.SECONDS);
    }

    @Test
    public void test_002() {
        log("Starting");
        Observable<String> obs = simple();
        log("Created");
        obs
                .subscribeOn(schedulerA)
                //many other operators
                .doOnNext(i -> log("A doOnNext: " + i))
                .subscribeOn(schedulerB)
                .doOnNext(i -> log("doOnNext: " + i))
                .subscribe(
                        x -> log("Got " + x),
                        Throwable::printStackTrace,
                        () -> log("Completed")
                          );
        log("Exiting");

        sleep(5, TimeUnit.SECONDS);
    }

    @Test
    public void test_003() {
        RxGroceries rxGroceries = new RxGroceries();
        Observable<BigDecimal> totalPrice = Observable
                .just("bread", "butter", "milk", "tomato", "cheese")
                .subscribeOn(schedulerA) //BROKEN!!!
                .map(prod -> rxGroceries.doPurchase(prod, 1))
                .reduce(BigDecimal::add)
                .single();
        totalPrice.subscribe(x -> log("totalPrice=" + x));
        sleep(5, TimeUnit.SECONDS);
    }

    @Test
    public void test_004() {
        RxGroceries rxGroceries = new RxGroceries();
        Observable
                .just("bread", "butter", "milk", "tomato", "cheese")
                .subscribeOn(schedulerA)
                .flatMap(prod -> rxGroceries.purchase(prod, 1))
                .reduce(BigDecimal::add)
                .single()
                .subscribe(x -> log("totalPrice=" + x));
        sleep(5, TimeUnit.SECONDS);
    }

    @Test
    public void test_005() {
        RxGroceries rxGroceries = new RxGroceries();
        Observable<BigDecimal> totalPrice = Observable
                .just("bread", "butter", "milk", "tomato", "cheese")
                .flatMap(prod ->
                                 rxGroceries
                                         .purchase(prod, 1)
                                         .subscribeOn(schedulerA))
                .reduce(BigDecimal::add)
                .single();
        totalPrice.subscribe(x -> log("totalPrice=" + x));
        sleep(5, TimeUnit.SECONDS);
    }

    @Test
    public void test_006() {
        RxGroceries rxGroceries = new RxGroceries();
        Observable<BigDecimal> totalPrice = Observable
                .just("bread", "butter", "egg", "milk", "tomato",
                      "cheese", "tomato", "egg", "egg")
                .groupBy(prod -> prod)
                .flatMap(grouped -> grouped
                        .count()
                        .map(quantity -> {
                                 String productName = grouped.getKey();
                            return Pair.create(productName, quantity);
                        }))
                .flatMap(order -> rxGroceries
                        .purchase(order.first, order.second)
                        .subscribeOn(schedulerA))
                .reduce(BigDecimal::add)
                .single();
        totalPrice.subscribe(x -> log("totalPrice=" + x));
        sleep(5, TimeUnit.SECONDS);
    }

    @Test
    public void test_007() {
        log("Starting");
        final Observable<String> obs = simple();
        log("Created");
        obs
                .doOnNext(x -> log("Found 1: " + x))
                .observeOn(schedulerB)
                .doOnNext(x -> log("Found 2: " + x))
                .observeOn(schedulerC)
                .doOnNext(x -> log("Found 3: " + x))
                .subscribeOn(schedulerA)
                .subscribe(
                        x -> log("Got 1: " + x),
                        Throwable::printStackTrace,
                        () -> log("Completed")
                          );
        log("Exiting");

        sleep(5, TimeUnit.SECONDS);
    }

    @Test
    public void test_008() {
        log("Starting");
        Observable<String> obs = Observable.create(subscriber -> {
            log("Subscribed");
            subscriber.onNext("A");
            subscriber.onNext("B");
            subscriber.onNext("C");
            subscriber.onNext("D");
            subscriber.onCompleted();
        });
        log("Created");
        obs
                .subscribeOn(schedulerA)
                .flatMap(record -> store(record).subscribeOn(schedulerB))
                .observeOn(schedulerC)
                .subscribe(
                        x -> log("Got: " + x),
                        Throwable::printStackTrace,
                        () -> log("Completed")
                          );
        log("Exiting");

        sleep(5, TimeUnit.SECONDS);
    }

    Observable<String> simple() {
        return Observable.create(subscriber -> {
            log("Subscribed");
            subscriber.onNext("A");
            subscriber.onNext("B");
            subscriber.onCompleted();
        });
    }

    Observable<UUID> store(String s) {
        return Observable.create(subscriber -> {
            log("Storing " + s);
            //hard work
            subscriber.onNext(UUID.randomUUID());
            subscriber.onCompleted();
        });
    }

    static void sleep(int timeout, TimeUnit unit) {
        try {
            unit.sleep(timeout);
        } catch (InterruptedException ignored) {
            //intentionally ignored
        }
    }

    private static void log(Object msg) {
        System.out.println(
                Thread.currentThread().getName() +
                        ": " + msg);
    }

    ExecutorService poolA      = newFixedThreadPool(10, threadFactory("Sched-A-%d"));
    Scheduler       schedulerA = Schedulers.from(poolA);
    ExecutorService poolB      = newFixedThreadPool(10, threadFactory("Sched-B-%d"));
    Scheduler       schedulerB = Schedulers.from(poolB);
    ExecutorService poolC      = newFixedThreadPool(10, threadFactory("Sched-C-%d"));
    Scheduler       schedulerC = Schedulers.from(poolC);
    private ThreadFactory threadFactory(String pattern) {
        return new ThreadFactoryBuilder()
                .setNameFormat(pattern)
                .build();
    }

    class RxGroceries {
        Observable<BigDecimal> purchase(String productName, int quantity) {
            return Observable.fromCallable(() ->
                                                   doPurchase(productName, quantity));
        }
        BigDecimal doPurchase(String productName, int quantity) {
            log("Purchasing " + quantity + " " + productName);
            //real logic here
            log("Done " + quantity + " " + productName);
            BigDecimal priceForProduct = new BigDecimal(quantity);
            return priceForProduct;
        }
    }


}

class Pair<F, S> {
    public final F first;
    public final S second;

    /**
     * Constructor for a Pair.
     *
     * @param first the first object in the Pair
     * @param second the second object in the pair
     */
    public Pair(F first, S second) {
        this.first = first;
        this.second = second;
    }

    /**
     * Checks the two objects for equality by delegating to their respective
     * {@link Object#equals(Object)} methods.
     *
     * @param o the {@link Pair} to which this one is to be checked for equality
     * @return true if the underlying objects of the Pair are both considered
     *         equal
     */
    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Pair)) {
            return false;
        }
        Pair<?, ?> p = (Pair<?, ?>) o;
        return Objects.equals(p.first, first) && Objects.equals(p.second, second);
    }

    /**
     * Compute a hash code using the hash codes of the underlying objects
     *
     * @return a hashcode of the Pair
     */
    @Override
    public int hashCode() {
        return (first == null ? 0 : first.hashCode()) ^ (second == null ? 0 : second.hashCode());
    }

    @Override
    public String toString() {
        return "Pair{" + String.valueOf(first) + " " + String.valueOf(second) + "}";
    }

    /**
     * Convenience method for creating an appropriately typed pair.
     * @param a the first object in the Pair
     * @param b the second object in the pair
     * @return a Pair that is templatized with the types of a and b
     */
    public static <A, B> Pair <A, B> create(A a, B b) {
        return new Pair<A, B>(a, b);
    }
}
