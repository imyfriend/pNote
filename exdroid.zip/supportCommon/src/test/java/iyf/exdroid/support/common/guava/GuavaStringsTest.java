package iyf.exdroid.support.common.guava;


import com.google.common.base.Strings;

import org.junit.Test;

/**
 * 类名称：GuavaStringsTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/27
 * 修改者， 修改日期， 修改内容
 */

// https://my.oschina.net/indestiny/blog/214668
public class GuavaStringsTest {
    @Test
    public void Strings_padEnd() {
        //用padChar填充string后面, 使string最小长度为minLength
        //padEnd(String string, int minLength, char padChar)
        String str = Strings.padEnd("He", 5, 'f');
        System.out.println(str); //Hefff
    }

    @Test
    public void Strings_padStart() {
        //用padChar填充string前面, 使string最小长度为minLength
        //padStart(String string, int minLength, char padChar)
        String str = Strings.padStart("He", 5, 'f');
        System.out.println(str); //fffHe
    }

    @Test
    public void Strings_nullToEmpty() {
        //null转换为""
        //nullToEmpty(String string)
        String str = Strings.nullToEmpty(null);
        System.out.println(str); //
    }

    @Test
    public void Strings_emptyToNull() {
        //""转换为null
        //emptyToNull(String string)
        String str = Strings.emptyToNull("");
        System.out.println(str); //null
    }


}
