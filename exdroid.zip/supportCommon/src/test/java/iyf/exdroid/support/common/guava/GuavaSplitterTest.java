package iyf.exdroid.support.common.guava;

import com.google.common.base.Splitter;

import org.junit.Test;

import java.util.Map;
import java.util.regex.Pattern;

/**
 * 类名称：GuavaSplitterTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/27
 * 修改者， 修改日期， 修改内容
 */

// https://my.oschina.net/indestiny/blog/214668
public class GuavaSplitterTest {
    @Test
    public void Splitter_split() {
        String str = "try ,d o , your , best";
        Splitter splitter = Splitter.on(",");
        //splitter.trimResults(); //这样是不会去掉各个元素空格的, 它仅返回一个新的Splitter
        Iterable<String> res = splitter.split(str);
        System.out.println(res); //[try , d o ,  your ,  best]

        res = splitter.trimResults().split(str); //用逗号分割且removes any leading or trailing whitespace
        System.out.println(res); //[try, d o, your, best]
    }

    @Test
    public void Splitter_mapSplitter() {
        String str = "key3=value3,key2=value2,key1=value1";
        Splitter.MapSplitter splitter = Splitter.on(",").withKeyValueSeparator("=");
        Map<String, String> map = splitter.split(str);
        System.out.println("key3=" + map.get("key3"));
        System.out.println(map);// {key3=value3, key2=value2, key1=value1}
    }

    @Test
    public void Splitter_regularExpression() {
        String str = "d12345#44#5r#f7";
        Splitter splitter = Splitter.on(Pattern.compile("\\d+"));
        System.out.println(splitter.split(str)); //[d, #, #, r#f, ]
    }



}
