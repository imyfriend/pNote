package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import iyf.exdroid.support.common.Student;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.observables.GroupedObservable;

/**
 * Created by imyfriend on 2017/5/14.
 */

public class TransformationGroupTest {
    /*
    Items can be grouped by specific property or key.
     */

    /*
    groupBy method that divides a source Observable
instance into multiple Observable instances. Each of these Observable instances emits
some of the source's items depending on a grouping function.
The groupBy() operator returns an Observable instance that emits Observable
instances. These Observable instances are special; they are of type
GroupedObservable, and you can retrieve their grouping keys using the getKey()
method. Once the groupBy() operator is used, the different groups can be handled in a
different or a common way.
Note that when the groupBy() operator creates an observable that emits the
GroupedObservables instances, each of them buffers its items. So, if we ignore any of
them, this buffer will present a potential memory leak.
     */
    @Test
    public void groupBy_001() {
        List<String> albums = Arrays.asList("The Piper at the Gates of Dawn",
                "A Saucerful of Secrets",
                "More", "Ummagumma", "Atom Heart Mother",
                "Meddle", "Obscured by Clouds",
                "The Dark Side of the Moon",
                "Wish You Were Here", "Animals", "The Wall"
        );
        Observable.from(albums)
                // 在GroupBy的Func1()函数中按你的逻辑分组，并将每个信息对应的组的key标志返回
                .groupBy(new Func1<String, Integer>() {
                    @Override
                    public Integer call(String s) {
                        return s.split(" ").length;
                    }
                })
                /*
                The order the items are emitted in is the same, but they are emitted by different
GroupedObservable instances. Also, all the GroupedObservable instances are
completed after the source completes.
                 */
                .subscribe(new Action1<GroupedObservable<Integer, String>>() {
                    @Override
                    public void call(GroupedObservable<Integer, String> integerStringGroupedObservable) {
                        subscribePrint(integerStringGroupedObservable,
                                integerStringGroupedObservable.getKey() + " word(s)");
                    }
                });


    }

    @Test
    public void groupBy_002() {
        List<String> albums = Arrays.asList("The Piper at the Gates of Dawn",
                "A Saucerful of Secrets",
                "More", "Ummagumma", "Atom Heart Mother",
                "Meddle", "Obscured by Clouds",
                "The Dark Side of the Moon",
                "Wish You Were Here", "Animals", "The Wall"
        );
        Observable.from(albums)
                .groupBy(new Func1<String, Integer>() {
                    @Override
                    public Integer call(String s) {
                        return s.replaceAll("[^mM]", "").length();
                    }
                }, new Func1<String, String>() { // 作用跟单个参数的差不多，唯一差别是第二个Func1()则是用来变换返回的信息的
                    @Override
                    public String call(String s) {
                        return s.replaceAll("[mM]", "*");
                    }
                })
                .subscribe(new Action1<GroupedObservable<Integer, String>>() {
                    @Override
                    public void call(GroupedObservable<Integer, String> obs) {
                        subscribePrint(obs, obs.getKey()+" occurences of 'm'");
                    }
                });
    }

    @Test
    public void groupBy_003() {
        Observable.just(new Student(), new Student())
                .groupBy(student -> student.getName());
    }

    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                        + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }

}
