package iyf.exdroid.support.common.guava;

import org.junit.Test;

import iyf.exdroid.support.common.utils.MathUtils;

/**
 * Created by ii on 2017/3/17.
 */

public class MathUtilsTest {
    @Test
    public void nextPowerOf2_test() {
        int n = MathUtils.nextPowerOf2(127);
        System.out.println(n); // 128

        n = MathUtils.nextPowerOf2(128);
        System.out.println(n); // 128

        n = MathUtils.nextPowerOf2(129);
        System.out.println(n); // 256
    }

    @Test
    public void prevPowerOf2_test() {
        int n = MathUtils.prevPowerOf2(127);
        System.out.println(n); // 64

        n = MathUtils.prevPowerOf2(128);
        System.out.println(n); // 128

        n = MathUtils.prevPowerOf2(129);
        System.out.println(n); // 128
    }

}
