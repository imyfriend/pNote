package iyf.exdroid.support.common.guava;

import com.google.common.util.concurrent.Monitor;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * 类名称：GuavaMonitorTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/3/6
 * 修改者， 修改日期， 修改内容
 */
public class GuavaMonitorTest {
    private              List<String>  list              = new ArrayList<String>();
    private static final int           MAX_SIZE          = 10;
    private              Monitor       monitor           = new Monitor();
    private              Monitor.Guard listBelowCapacity = new  Monitor.Guard(monitor) {
                @Override
                public boolean isSatisfied() {
                    return list.size() < MAX_SIZE;
                }
            };

    // a thread will enter the Monitor and add an item to the list when our Guard condition
    // evaluates to true, otherwise, the thread will wait.
    public void addToListWait(String item) throws InterruptedException {
        monitor.enterWhen(listBelowCapacity, 5, TimeUnit.SECONDS);
        try {
            list.add(item);
            System.out.println("in addToListWait(), item=" + item + ", size=" + list.size());
        } finally {
            monitor.leave();
        }
    }

    public void addToListSkipWait(String item) throws InterruptedException {
        // 超过MAX_SIZE， 会锁死
        //this.monitor.enterWhen(listBelowCapacity);

        // 超过返回false  不会锁死
        Boolean isOK = monitor.tryEnterIf(listBelowCapacity);
        System.out.println("Thread[" + Thread.currentThread().getName() + "] item=" + item + ",获取令牌：isOK=" + isOK);
        if (isOK) {
            try {
                list.add(item);
                System.out.println("添加元素[" + item + "]成功，当前List.size=" + list.size() + "～");
            } finally { // 确保线程会退出Monitor锁
                monitor.leave();
            }
        } else {
            System.out.println("添加元素[" + item + "]失败");
        }
    }

    // When a thread enters a Monitor block, it is considered to occupy that Monitor
    // instance, and once the thread leaves, it no longer occupies the Monitor block. Only
    // one thread can enter a Monitor block at any time. The semantics are the same as
    // using synchronized or ReentrantLocks; a thread enters and no other thread can
    // enter that area until the current thread releases the lock or in our case, leaves the
    // Monitor block. The same thread can enter and exit the same Monitor block any
    // number of times but each entry must be followed by an exit.
    @Test
    public void Monitor_enterWhen() {
        /*try {
            for (int i = 0; i < MAX_SIZE + 10 ; i++) {
                addToListWait("monitor " + i);
            }
        } catch (InterruptedException e) {
            System.out.println("Monitor_enterWhen: e=" + e);
        }*/

        final CountDownLatch cdl = new CountDownLatch(5);

        for (int i=0; i<5; i++) {
            new Thread() {
                @Override
                public void run() {
                    try {
                        for (int k = 0; k < 6; k++) {
                            addToListWait("item " + k);
                        }
                        cdl.countDown();
                    } catch (InterruptedException e) {
                        System.out.println("Monitor_tryEnterIf: e=" + e);
                    }
                }
            }.start();
        }

        try {
            cdl.await();
        } catch (Exception e) {

        }
    }

    @Test
    public void Monitor_tryEnterIf() {
        /*try {
            for (int k = 0; k < 16; k++) {
                addToListSkipWait("item " + k);
            }
        } catch (InterruptedException e) {
            System.out.println("Monitor_tryEnterIf: e=" + e);
        }*/

        final CountDownLatch cdl = new CountDownLatch(5);

        for (int i=0; i<5; i++) {
            new Thread() {
                @Override
                public void run() {
                    try {
                        for (int k = 0; k < 6; k++) {
                            addToListSkipWait("item " + k);
                        }
                        cdl.countDown();
                    } catch (InterruptedException e) {
                        System.out.println("Monitor_tryEnterIf: e=" + e);
                    }
                }
            }.start();
        }

        try {
            cdl.await();
        } catch (Exception e) {

        }
    }

    /*
    Monitor methods that return boolean values should always be used within an
    if statement that contains a try/finally block to ensure the thread will always
    be able to exit the Monitor block.
    if (monitor.enterIf(guardCondition)) {
        try {
            doWork();
        } finally {
            monitor.leave();
        }
    }

    For Monitor methods that don't return any values, the method class should
    immediately be followed by a try/finally block as follows:
    monitor.enterWhen(guardCondition);
    try {
        doWork();
    } finally {
        monitor.leave()
    }

    Different Monitor access methods
    1. Monitor.enter: The Monitor.enter method will attempt to enter a
    monitor and will block indefnitely until the thread enters the monitor.
    2. Monitor.enterIf: The Monitor.enterIf method takes Monitor.Guard as
    an argument and will block to enter the monitor. Once it enters the monitor,
    it will not wait for the condition to be satisfed, but it will return a boolean
    indicating whether the Monitor block was entered.
    3. Monitor.enterWhen: The Monitor.enterWhen method also takes Monitor.
    Guard as an argument and blocks, waiting to enter the monitor. However, once
    the lock is obtained, it will wait indefnitely for the condition to be satisfed.
    4. Monitor.tryEnter: The Monitor.tryEnter method will attempt to access
    the monitor but if it is already occupied by another thread, it will not wait
    at all to obtain the lock but will return a boolean indicating whether the
    Monitor block was entered.
    5. Monitor.tryEnterIf: The Monitor.tryEnterIf method attempts to
    immediately enter the monitor only if the lock is available and the condition is
    satisfied; otherwise, it will not wait for the lock or the condition to be satisfed
    but will return a boolean indicating whether the Monitor block was entered.
     */

}
