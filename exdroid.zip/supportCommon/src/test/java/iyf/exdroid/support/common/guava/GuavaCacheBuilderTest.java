package iyf.exdroid.support.common.guava;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;

import org.junit.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by ii on 2017/3/24.
 */

public class GuavaCacheBuilderTest {

    @Test
    public void CacheBuilder_test01() {
        //缓存接口这里是LoadingCache，LoadingCache在缓存项不存在时可以自动加载缓存
        LoadingCache<Integer, String> studentCache
                //CacheBuilder的构造函数是私有的，只能通过其静态方法newBuilder()来获得CacheBuilder的实例
                = CacheBuilder.newBuilder()
                //设置并发级别为8，并发级别是指可以同时写缓存的线程数
                .concurrencyLevel(8)
                //设置写缓存后8秒钟过期
                .expireAfterWrite(8, TimeUnit.SECONDS)
                //设置缓存容器的初始容量为10
                .initialCapacity(10)
                //设置缓存最大容量为100，超过100之后就会按照LRU最近虽少使用算法来移除缓存项
                .maximumSize(100)
                //设置要统计缓存的命中率
                .recordStats()
                //设置缓存的移除通知
                .removalListener(new RemovalListener<Object, Object>() {
                    @Override
                    public void onRemoval(RemovalNotification<Object, Object> notification) {
                        System.out.println(notification.getKey() + " was removed, cause is " + notification.getCause());
                    }
                })
                // build方法中可以指定CacheLoader，在缓存不存在时通过CacheLoader的实现自动加载缓存
                .build(
                        new CacheLoader<Integer, String>() {
                            @Override
                            public String load(Integer key) throws Exception {
                                System.out.println("load student " + key);
                                String student = new String("name " + key);
                                return student;
                            }
                        }
                      );

        try {
            for (int i = 0; i < 20; i++) {
                // 从缓存中得到数据，由于我们没有设置过缓存，所以需要通过CacheLoader加载缓存数据
                String student = studentCache.get(1);
                System.out.println(student);
                // 休眠1秒
                TimeUnit.SECONDS.sleep(1);
            }
        } catch (Exception e) {

        }

        // 从缓存中移除缓存项
        studentCache.invalidate(1);
        System.out.println("cache stats:");
        // 最后打印缓存的命中率等 情况
        System.out.println(studentCache.stats().toString());
    }

    @Test
    public void CacheBuilder_test02() {
        //缓存接口这里是LoadingCache，LoadingCache在缓存项不存在时可以自动加载缓存
        LoadingCache<Integer, String> studentCache
                //CacheBuilder的构造函数是私有的，只能通过其静态方法newBuilder()来获得CacheBuilder的实例
                = CacheBuilder.newBuilder()
                //设置并发级别为8，并发级别是指可以同时写缓存的线程数
                .concurrencyLevel(8)
                //每8秒钟刷新一次缓存
                .refreshAfterWrite(8, TimeUnit.SECONDS)
                //设置缓存容器的初始容量为10
                .initialCapacity(10)
                //设置缓存最大容量为100，超过100之后就会按照LRU最近虽少使用算法来移除缓存项
                .maximumSize(100)
                //设置要统计缓存的命中率
                .recordStats()
                //设置缓存的移除通知
                .removalListener(new RemovalListener<Object, Object>() {
                    @Override
                    public void onRemoval(RemovalNotification<Object, Object> notification) {
                        System.out.println(notification.getKey() + " was removed, cause is " + notification.getCause());
                        /*
                        The possible values of the RemovalCause enum are as follows:
                        • COLLECTED: This value indicates that either the key or value were garbage-collected
                            这个是key或者value被垃圾回收了
                        • EXPIRED: This value indicates that the entry's last-written or last-accessed time limit has expired
                            这个是这个entry最后一次访问时间或则最后一次写入时间超时了
                        • EXPLICIT: This value indicates that the user manually removed the entry
                            这个表示是用户手动移出
                        • REPLACED: This value indicates that the entry was not actually removed but the value was replaced
                            这个表明 这个entry没有被移出，但是 value被重新写过
                        • SIZE: This value indicates that the entry was removed because the size of Cache approached or met the specified size limitation
                            这个表明因为cache的空间不足原因被移出
                         */
                    }
                })
                // build方法中可以指定CacheLoader，在缓存不存在时通过CacheLoader的实现自动加载缓存
                .build(
                        new CacheLoader<Integer, String>() {
                            private int cnt = 0;

                            @Override
                            public String load(Integer key) throws Exception {
                                System.out.println("load student " + key);
                                key = key + cnt;
                                cnt++;
                                String student = new String("name " + key);
                                return student;
                            }
                        }
                      );

        try {
            for (int i = 0; i < 20; i++) {
                // 从缓存中得到数据，由于我们没有设置过缓存，所以需要通过CacheLoader加载缓存数据
                String student = studentCache.get(1);
                System.out.println(student);
                // 休眠1秒
                TimeUnit.SECONDS.sleep(1);
            }
        } catch (Exception e) {

        }

        // 从缓存中移除缓存项
        studentCache.invalidate(1);

        System.out.println("cache stats:");
        // 最后打印缓存的命中率等 情况
        System.out.println(studentCache.stats().toString());
        // CacheStats{hitCount=19, missCount=1, loadSuccessCount=3, loadExceptionCount=0, totalLoadTime=55537466, evictionCount=0}

        /*
        下面是可以从CacheStats中获取到的监控信息:
        – 每次获取新的值的时间 The average time spent loading new values
        – 缓存的命中率 The fraction of requests to the cache that were hits
        – 缓存失败率 The fraction of requests to the cache that were misses
        – 值被剔除的次数 The number of evictions made by the cache
         */
    }

    @Test
    public void CacheBuilder_test03() {
        //缓存接口这里是LoadingCache，LoadingCache在缓存项不存在时可以自动加载缓存
        LoadingCache<Integer, Person> studentCache
                //CacheBuilder的构造函数是私有的，只能通过其静态方法newBuilder()来获得CacheBuilder的实例
                = CacheBuilder.newBuilder()
                //设置并发级别为8，并发级别是指可以同时写缓存的线程数
                .concurrencyLevel(8)
                //每8秒钟刷新一次缓存
                .refreshAfterWrite(8, TimeUnit.SECONDS)
                //设置缓存容器的初始容量为10
                .initialCapacity(10)
                //设置缓存最大容量为100，超过100之后就会按照LRU最近虽少使用算法来移除缓存项
                .maximumSize(100)
                //设置要统计缓存的命中率
                .recordStats()
                //设置缓存的移除通知
                .removalListener(new RemovalListener<Integer, Person>() {
                    @Override
                    public void onRemoval(RemovalNotification<Integer, Person> notification) {
                        System.out.println("[key=" + notification.getKey()
                                                   + ", value=" + notification.getValue()
                                                   + "] was removed, cause is " + notification.getCause());
                    }
                })
                // build方法中可以指定CacheLoader，在缓存不存在时通过CacheLoader的实现自动加载缓存
                .build(
                        new CacheLoader<Integer, Person>() {
                            private int cnt = 0;

                            @Override
                            public Person load(Integer key) throws Exception {
                                System.out.println("load student " + key);
                                key = key + cnt;
                                cnt++;
                                Person student = new Person(key, "name " + key, 20);
                                return student;
                            }
                        }
                      );

        try {
            for (int i = 0; i < 20; i++) {
                // 从缓存中得到数据，由于我们没有设置过缓存，所以需要通过CacheLoader加载缓存数据
                Person student = studentCache.get(1);
                System.out.println(student);
                // 休眠1秒
                TimeUnit.SECONDS.sleep(1);
            }
        } catch (Exception e) {

        }

        // 从缓存中移除缓存项
        studentCache.invalidate(1);
        System.out.println("cache stats:");
        // 最后打印缓存的命中率等 情况
        System.out.println(studentCache.stats().toString());
    }

}
