package iyf.exdroid.support.common.guava;

import com.google.common.base.Predicate;
import com.google.common.collect.Sets;

import org.junit.Test;

import java.util.Set;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * 类名称：GuavaSetsTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/2/13
 * 修改者， 修改日期， 修改内容
 */
public class GuavaSetsTest {
    // Sets is a utility class for working with Set instances. There are static factory
    // methods for creating HashSets, LinkedHashSets (Set instances that guarantee
    // items stay in the same order as they are added), and TreeSets (items are sorted
    // by their natural order or by a provided Comparator).

    // The Sets.difference method takes two set instance parameters and returns
    // SetView of the elements found in the frst set, but not in the second. SetView is a
    // static, abstract inner class of the Sets class and represents an unmodifable view of
    // a given Set instance. Any elements that exist in the second set but not in the frst set
    // are not included.
    @Test
    public void Sets_difference() {
        Set<String> s1 = Sets.newHashSet("1", "2", "3");
        Set<String> s2 = Sets.newHashSet("2", "3", "4");
        System.out.println(Sets.difference(s1, s2)); // [1]
    }

    // The Sets.symmetricDifference method returns elements that are contained in one
    // set or the other set, but not contained in both. The returned set is an unmodifable
    // view.
    @Test
    public void Sets_symmetricDifference() {
        Set<String>  s1      = Sets.newHashSet("1", "2", "3");
        Set<String>  s2      = Sets.newHashSet("2", "3", "4");
        Sets.SetView setView = Sets.symmetricDifference(s1, s2);
        System.out.println(setView); // [1, 4]
    }

    // The Sets.intersection method returns an unmodifable SetView instance
    // containing elements that are found in two Set instances.
    @Test
    public void Sets_intersection() {
        Set<String>          s1 = Sets.newHashSet("1", "2", "3");
        Set<String>          s2 = Sets.newHashSet("3", "2", "4");
        Sets.SetView<String> sv = Sets.intersection(s1, s2);
        assertThat(sv.size() == 2 && sv.contains("2") && sv.contains("3"), is(true));
    }

    // The Sets.union method takes two sets and returns a SetView instance that contains
    // elements that are found in either set.
    @Test
    public void Sets_union() {
        Set<String>          s1 = Sets.newHashSet("1", "2", "3");
        Set<String>          s2 = Sets.newHashSet("3", "2", "4");
        Sets.SetView<String> sv = Sets.union(s1, s2);
        assertThat(sv.size() == 4
                   && sv.contains("2")
                   && sv.contains("3")
                   && sv.contains("4")
                   && sv.contains("1"), is(true));
    }

    @Test
    public void Sets_filter() {
        Set<String>          s1 = Sets.newHashSet("1", "2", "3");
        Set<String>          s2 = Sets.newHashSet("3", "2", "4");
        Sets.SetView<String> sv = Sets.union(s1, s2);
        Set<String> filter = Sets.filter(sv, new Predicate<String>() {
            @Override
            public boolean apply(String input) {
                return Integer.valueOf(input) > 3;
            }
        });
        System.out.println(filter); // [4]
    }

}
