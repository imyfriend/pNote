package iyf.exdroid.support.common.guava;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheBuilderSpec;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import org.junit.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by ii on 2017/3/24.
 */

public class GuavaCacheBuilderSpecTest {
    @Test
    public void CacheBuilderSpec_test01() {
        String spec = "concurrencyLevel=10,expireAfterAccess=5m,softValues";
        CacheBuilderSpec cacheBuilderSpec = CacheBuilderSpec.parse(spec);
        CacheBuilder cacheBuilder = CacheBuilder.from(cacheBuilderSpec);
        // build方法中可以指定CacheLoader，在缓存不存在时通过CacheLoader的实现自动加载缓存
        LoadingCache<Integer, String> studentCache = cacheBuilder.build(
                        new CacheLoader<Integer, String>() {
                            private int cnt = 0;

                            @Override
                            public String load(Integer key) throws Exception {
                                System.out.println("load student " + key);
                                key = key + cnt;
                                cnt++;
                                String student = new String("name " + key);
                                return student;
                            }
                        }
                                                                    );

        try {
            for (int i = 0; i < 20; i++) {
                // 从缓存中得到数据，由于我们没有设置过缓存，所以需要通过CacheLoader加载缓存数据
                String student = studentCache.get(1);
                System.out.println(student);
                // 休眠1秒
                TimeUnit.SECONDS.sleep(1);
            }
        } catch (Exception e) {

        }
    }


}
