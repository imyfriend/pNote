package iyf.exdroid.support.common;

import org.junit.Test;

import java.util.Arrays;

/**
 * 类名称：ArraysTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/2/13
 * 修改者， 修改日期， 修改内容
 */
public class ArraysTest {

    @Test
    public void Arrays_sort() {
        int[] arr = {1, 3, 2, 6, 9, 7};
       /* for (int i : arr) {
            System.out.print(i);
        } //132697*/
        System.out.println(Arrays.toString(arr)); //[1, 3, 2, 6, 9, 7]

        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr)); //[1, 2, 3, 6, 7, 9]
       /* for (int i : arr) {
            System.out.print(i);
        } //123679*/

    }

    // binarySearch方法返回要搜索元素的索引值
    // 如果key在数组中，则返回搜索值的索引；否则返回-1或“-”（插入点）。插入点是索引键将要插入数组的那一点，即第一个大于该键的元素的索引。
    // http://blog.csdn.net/cxhply/article/details/49423501
    @Test
    public void Arrays_binarySearch() {
        int[] arr =new int[]{1,3,4,5,8,9};
        Arrays.sort(arr);
        int index1 = Arrays.binarySearch(arr,6); // 搜索值不是数组元素，且在数组范围内，从1开始计数，得“ - 插入点索引值”；
        int index2 = Arrays.binarySearch(arr,4); // 搜索值是数组元素，从0开始计数，得搜索值的索引值；
        int index3 = Arrays.binarySearch(arr, 10); // 搜索值不是数组元素，且大于数组内元素，索引值为 – (length + 1);
        int index4 = Arrays.binarySearch(arr, 0); // 搜索值不是数组元素，且小于数组内元素，索引值为 – 1。
        System.out.println("index1 = "+ index1 +", index2 = " + index2 +
                           ", index3 = " + index3 +", index4 = "+ index4); // index1 = -5, index2 = 2, index3 = -7, index4 = -1
    }

    @Test
    public void Arrays_fill() {
        int[] arr = new int[5];
        Arrays.fill(arr, 5);
        System.out.println(Arrays.toString(arr)); //[5, 5, 5, 5, 5]

        arr = new int[]{1,3,4,5,8,9};
        Arrays.fill(arr, 5);
        System.out.println(Arrays.toString(arr)); //[5, 5, 5, 5, 5, 5]
    }

    @Test
    public void Arrays_equals() {
        String[][] ticTacToe1 = { { " O ", " O ", " X " }, { " O ", " X ", " X " },{ " X ", " O ", " O " } };
        String[][] ticTacToe2 = { { " O ", " O ", " X " }, { " O ", " X ", " X " },{ " X ", " O ", " O " } };

        // equals方法比较的是地址
        System.out.println(Arrays.equals(ticTacToe1, ticTacToe2)); //false

        // deepEquals方法比较的是内容
        System.out.println(Arrays.deepEquals(ticTacToe1, ticTacToe2)); //true
    }

    // 如果元素e是一个基本类型的数组，那么通过调用Arrays.toString(e)的适当重载版本将其转变为一个字符串。
    // 如果元素e是一个引用类型数组，那么通过递归地调用上述方法将其转换为一个字符串。
    @Test
    public void Arrays_toString() {
        //聚集初始化多维数组
        String[][] str = {{"a","b","c"},{"d","e","f"},{"g","h","i"}};

        System.out.println(Arrays.toString(str)); //[[Ljava.lang.String;@48533e64, [Ljava.lang.String;@64a294a6, [Ljava.lang.String;@7e0b37bc]

        System.out.println(Arrays.deepToString(str)); //[[a, b, c], [d, e, f], [g, h, i]]
    }

}
