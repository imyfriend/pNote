package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rx.Observable;
import rx.Observer;
import rx.Subscription;
import rx.functions.Func1;
import rx.functions.Func2;
import rx.observables.ConnectableObservable;
import rx.schedulers.Schedulers;

/**
 * Created by ii on 2017/4/27.
 */

public class ReactiveSumV1 {
    /**
     * The sum is just an Observer, which subscribes to a stream created by combining 'a' and 'b', via summing.
     *
     * @author meddle
     */
    public static final class ReactiveSum implements Observer<Double> {

        private CountDownLatch latch = new CountDownLatch(1);

        private double sum;
        private Subscription subscription = null;

        public ReactiveSum(Observable<Double> a, Observable<Double> b) {
            this.sum = 0;

            subscribe(a, b);
        }

        private void subscribe(Observable<Double> a, Observable<Double> b) {
            // combineLatest creates an Observable, sending notifications on changes of either of its sources.
            // This notifications are formed using a Func2.
            this.subscription = Observable.combineLatest(a, b, new Func2<Double, Double, Double>() {
                public Double call(Double a, Double b) {
                    return a + b;
                }
            }).subscribeOn(Schedulers.io()).subscribe(this);
        }

        public void unsubscribe() {
            this.subscription.unsubscribe();
            this.latch.countDown();
        }

        public void onCompleted() {
            System.out.println("Exiting last sum was : " + this.sum);
            this.latch.countDown();
        }

        public void onError(Throwable e) {
            System.err.println("Got an error!");
            e.printStackTrace();
        }

        public void onNext(Double sum) {
            this.sum = sum;
            System.out.println("update : a + b = " + sum);
        }

        public CountDownLatch getLatch() {
            return latch;
        }
    }

    /**
     * The Observable returned by this method, only reacts to values in the form
     * <varName> = <value> or <varName> : <value>.
     * It emits the <value>.
     */
    public static Observable<Double> varStream(final String varName,
                                               Observable<String> input) {
        final Pattern pattern = Pattern.compile("^\\s*" + varName
                                                        + "\\s*[:|=]\\s*(-?\\d+\\.?\\d*)$");

        return input.map(new Func1<String, Matcher>() {
            public Matcher call(String str) {
                System.out.println("in varStream(), str=" + str);
                return pattern.matcher(str);
            }
        }).filter(new Func1<Matcher, Boolean>() {
            public Boolean call(Matcher matcher) {
                return matcher.matches() && matcher.group(1) != null;
            }
        }).map(new Func1<Matcher, String>() {
            public String call(Matcher matcher) {
                return matcher.group(1);
            }
        }).filter(new Func1<String, Boolean>() {
            public Boolean call(String str) {
                return str != null;
            }
        }).map(new Func1<String, Double>() {
            public Double call(String str) {
                return Double.parseDouble(str);
            }
        });
    }

    public void run(InputStream inputStream) {
        ConnectableObservable<String> input = CreateObservable.from(inputStream);

        Observable<Double> a = varStream("a", input);
        Observable<Double> b = varStream("b", input);

        ReactiveSum sum = new ReactiveSum(a, b);

        input.connect();

        try {
            sum.getLatch().await();
        } catch (InterruptedException e) {}
    }

    @Test
    public void test_run() {
        System.out.println();
        System.out.println("Reacitve Sum. Type 'a: <number>' and 'b: <number>' to try it.");
        String      data  = "a:5\r\nb:3\r\n";

        ReactiveSumV1 reactiveSumV1 = new ReactiveSumV1();
        reactiveSumV1.run(new ByteArrayInputStream(data.getBytes()));
    }


}
