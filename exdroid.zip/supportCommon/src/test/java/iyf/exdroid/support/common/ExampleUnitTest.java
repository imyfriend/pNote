package iyf.exdroid.support.common;

import com.google.gson.Gson;

import org.junit.Test;

import java.text.NumberFormat;

import static org.junit.Assert.assertEquals;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);

        NumberFormat ddf1= NumberFormat.getNumberInstance() ;
        ddf1.setMaximumFractionDigits(2);
        String s= ddf1.format(4.8) ;
        System.out.println(s);
    }

    @Test
    public void tryTest() {
        /*
        point1 - i=1
        point2 - i=2
        point3 - i=3
        3
         */
        System.out.println(tcf()); // 3

    }

    private int tcf() {
        int i = 0;
        try {
            i = 1;
            System.out.println("point1 - i=" + i);
            String str = null;
            str.charAt(1);
            return i;
        } catch (Exception e) {
            i = 2;
            System.out.println("point2 - i=" + i);
            return i;
        } finally {
            i = 3;
            System.out.println("point3 - i=" + i);
            return i;
        }
    }

    @Test
    public void tryTest01() {
        try {
            System.out.println(tcf01());
            /*
            point1 - i=1
            point2 - i=2
            point3 - i=3
            3
             */
        } catch (Exception e) {
            System.out.println("Exception  e=" + e);
        }
    }

    private int tcf01() {
        int i = 0;
        try {
            i = 1;
            System.out.println("point1 - i=" + i);
            String str = null;
            str.charAt(1);
            return i;
        } catch (Exception e) {
            i = 2;
            System.out.println("point2 - i=" + i);
            throw e;
        } finally {
            i = 3;
            System.out.println("point3 - i=" + i);
            return i;
        }
    }

    @Test
    public void test_004() {
        String jsonData = "{'name':'John', 'age':20,'grade':{'course':'English','score':100,'level':'A'}}";
        Gson gson = new Gson();
        Student student = gson.fromJson(jsonData, Student.class);
        System.out.println("student =" + student);
    }

    @Test
    public void test_005() {
        String jsonData = "{'name':'John', 'grade':{'course':'English','score':100,'level':'A'}}";
        Gson gson = new Gson();
        Student student = gson.fromJson(jsonData, Student.class);
        System.out.println("student =" + student);
    }

    @Test
    public void test_006() {
        String jsonData = "{'age':20, 'name':'John', 'grade':{'course':'English','score':100,'level':'A'}}";
        Gson gson = new Gson();
        Student student = gson.fromJson(jsonData, Student.class);
        System.out.println("student =" + student);
    }

    @Test
    public void test_007() {
        String jsonData = "{'age':20, 'name':'John', 'grade':{'level':'A'}}";
        Gson gson = new Gson();
        Student student = gson.fromJson(jsonData, Student.class);
        System.out.println("student =" + student);
    }

    @Test
    public void test_008() {
        String jsonData = "{'age':20, 'name':'John'}";
        Gson gson = new Gson();
        Student student = gson.fromJson(jsonData, Student.class);
        System.out.println("student =" + student);
    }

    @Test
    public void test_009() {
        Student student = new Student();
        student.setName("john");
        Gson gson = new Gson();
        String gsonStr = gson.toJson(student);
        System.out.println("gsonStr =" + gsonStr);
    }

    @Test
    public void test_010() {
        Student student = new Student();
        student.setAge(10);
        Gson gson = new Gson();
        String gsonStr = gson.toJson(student);
        System.out.println("gsonStr =" + gsonStr);
    }

}