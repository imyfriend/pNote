package iyf.exdroid.support.common.Java8Lambda;

/**
 * Created by admin on 2017/7/25.
 */

public class Lambda_001 {

}
