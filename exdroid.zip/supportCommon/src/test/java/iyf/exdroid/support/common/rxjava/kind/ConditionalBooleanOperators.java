package iyf.exdroid.support.common.rxjava.kind;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import iyf.exdroid.support.common.rxjava.TestSubscriberEx;
import rx.Observable;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static rx.Observable.just;

/**
 * Created by admin on 2017/7/27.
 */

public class ConditionalBooleanOperators {

    @Test
    public void all_001() {
        /*
        传递一个谓词函数给All操作符，这个函数接受原始Observable发射的数据，根据计算返回一个布尔值。
        All返回一个只发射一个单个布尔值的Observable，如果原始Observable正常终止并且每一项数据都满足条件，
        就返回true；如果原始Observable的任何一项数据不满足条件就返回False。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(6, 1, 2, 5, 3).all(x -> x>0).subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertValueCount(1);
        List<Boolean> expected = Arrays.asList(true);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void all_002() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(6, 1, 2, 5, 3).all(x -> x>2).subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertValueCount(1);
        List<Boolean> expected = Arrays.asList(false);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void amb_001() {
        /*
        当你传递多个Observable给Amb时，它只发射其中一个Observable的数据和通知：首先发送通知给Amb的那个，
        不管发射的是一项数据还是一个onError或onCompleted通知。Amb将忽略和丢弃其它所有Observables的发射物。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.amb(just(1, 2, 3), just(4, 5).delay(10, TimeUnit.MILLISECONDS))
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertCompleted();
        subscriber.assertValueCount(3);
        List<Integer> expected = Arrays.asList(1,2,3);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void contains_001() {
        /*
        判定一个Observable是否发射一个特定的值。如果原始Observable发射了那个值，
        它返回的Observable将发射true，否则发射false。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3)
                .contains(2)
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertValueCount(1);
        List<Boolean> expected = Arrays.asList(true);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void contains_002() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3)
                .contains(22)
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertValueCount(1);
        List<Boolean> expected = Arrays.asList(false);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void isEmpty_001() {
        /*
        IsEmpty用于判定原始Observable是否没有发射任何数据。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3)
                .isEmpty()
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertValueCount(1);
        List<Boolean> expected = Arrays.asList(false);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void isEmpty_002() {
        /*
        IsEmpty用于判定原始Observable是否没有发射任何数据。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.empty()
                .isEmpty()
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertValueCount(1);
        List<Boolean> expected = Arrays.asList(true);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void exists_001() {
        /*
        exists操作符，它通过一个谓词函数测试原始Observable发射的数据，
        只要任何一项满足条件就返回一个发射true的Observable，否则返回一个发射false的Observable。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3)
                .exists(x -> x>2)
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertValueCount(1);
        List<Boolean> expected = Arrays.asList(true);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void defaultIfEmpty_001() {
        /*
        发射来自原始Observable的值，如果原始Observable没有发射任何值，就发射一个默认值
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.empty()
                .defaultIfEmpty(5)
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertValueCount(1);
        List<Integer> expected = Arrays.asList(5);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void sequenceEqual_001() {
        /*
        传递两个Observable给SequenceEqual操作符，它会比较两个Observable的发射物，
        如果两个序列是相同的（相同的数据，相同的顺序，相同的终止状态），它就发射true，否则发射false。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();

        Observable.sequenceEqual(just(1, 2, 3), just(1, 2, 3).delay(10, TimeUnit.MILLISECONDS))
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(1);
        List<Boolean> expected = Arrays.asList(true);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void sequenceEqual_002() {
        /*
        传递两个Observable给SequenceEqual操作符，它会比较两个Observable的发射物，
        如果两个序列是相同的（相同的数据，相同的顺序，相同的终止状态），它就发射true，否则发射false。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();

        Observable.sequenceEqual(just(1, 2, 3), just(2, 4, 6).delay(10, TimeUnit.MILLISECONDS),
                                 (x,y) -> x == y/2)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(1);
        List<Boolean> expected = Arrays.asList(true);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void skipUntil_001() {
        /*
        skipUntil订阅原始的Observable，但是忽略它的发射物，
        直到第二个Observable发射了一项数据那一刻，它开始发射原始Observable。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.interval(5, TimeUnit.MILLISECONDS)
                .take(5)
                .skipUntil(just(2).delay(13, TimeUnit.MILLISECONDS))
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        List<Long> expected = Arrays.asList(2L, 3L, 4L);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void skipWhile_001() {
        /*
        SkipWhile订阅原始的Observable，但是忽略它的发射物，
        直到你指定的某个条件变为false的那一刻，它开始发射原始Observable。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3,4,5,6)
                .skipWhile(x -> x!=3)
                .subscribe(subscriber);

        subscriber.assertCompleted();
        List<Integer> expected = Arrays.asList(3,4,5,6);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void takeUntil_001() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3,4,5,6)
                .takeUntil(x -> x==3)
                .subscribe(subscriber);

        subscriber.assertCompleted();
        List<Integer> expected = Arrays.asList(1,2,3);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void takeUntil_002() {
        /*
        TakeUntil订阅并开始发射原始Observable，它还监视你提供的第二个Observable。
        如果第二个Observable发射了一项数据或者发射了一个终止通知，
        TakeUntil返回的Observable会停止发射原始Observable并终止。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.interval(5, TimeUnit.MILLISECONDS)
                .take(5)
                .takeUntil(just(2).delay(13, TimeUnit.MILLISECONDS))
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        List<Long> expected = Arrays.asList(0L,1L);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void takeWhile_001() {
        /*
        发射Observable发射的数据，直到一个指定的条件不成立
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.interval(5, TimeUnit.MILLISECONDS)
                .take(5)
                .takeWhile(x -> x<3)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        List<Long> expected = Arrays.asList(0L,1L,2L);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }


}
