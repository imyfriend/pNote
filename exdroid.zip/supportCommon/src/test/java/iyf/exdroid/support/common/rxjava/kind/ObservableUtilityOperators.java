package iyf.exdroid.support.common.rxjava.kind;

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import iyf.exdroid.support.common.rxjava.TestSubscriberEx;
import iyf.exdroid.support.common.rxjava.Utils;
import rx.Observable;
import rx.Observer;
import rx.functions.Func1;

import static rx.Observable.just;

/**
 * Created by admin on 2017/7/27.
 */

public class ObservableUtilityOperators {

    @Test
    public void materialize_001() {
        /*
        一个合法的有限的Obversable将调用它的观察者的onNext方法零次或多次，
        然后调用观察者的onCompleted或onError正好一次。Materialize操作符将这一系列调用，
        包括原来的onNext通知和终止通知onCompleted或onError都转换为一个Observable发射的数据序列。
        RxJava的materialize将来自原始Observable的通知转换为Notification对象，
        然后它返回的Observable会发射这些数据。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4).materialize().subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void dematerialize_001() {
        /*
        Dematerialize操作符是Materialize的逆向过程，它将Materialize转换的结果还原成它原本的形式。
        dematerialize反转这个过程，将原始Observable发射的Notification对象还原成Observable的通知。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4).materialize().dematerialize().subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void doOnEach_001() {
        /*
        doOnEach操作符让你可以注册一个回调，它产生的Observable每发射一项数据就会调用它一次。
        你可以以Action的形式传递参数给它，这个Action接受一个onNext的变体Notification作为它的唯一参数，
        你也可以传递一个Observable给doOnEach，这个Observable的onNext会被调用，
        就好像它订阅了原始的Observable一样。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4)
                .doOnEach(x -> {
                    if (x.isOnNext()) {
                        Utils.log(x.getValue().toString() + 10);
                    } else {
                        Utils.log(x.getKind().toString() + 10);
                    }
                })
                .subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void doOnEach_002() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observer observer = new Observer() {

            @Override
            public void onCompleted() {
                Utils.log("onCompleted");
            }

            @Override
            public void onError(Throwable e) {
                Utils.log("onError");
            }

            @Override
            public void onNext(Object o) {
                Utils.log("onNext o=" + o);
            }
        };
        just(1, 2, 3, 4).doOnEach(observer).subscribe(subscriber);
        subscriber.assertCompleted();
    }

    @Test
    public void doOnNext_001() {
        /*
        doOnNext操作符类似于doOnEach(Action1)，但是它的Action不是接受一个Notification参数，
        而是接受发射的数据项。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4)
                .doOnNext(x -> Utils.log("* doOnNext x=" + x))
                .subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void doOnNext_002() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4)
                .doOnNext(x -> {
                    if (x > 2) {
                        throw new RuntimeException( "Item exceeds maximum value" );
                    } else {
                        Utils.log("* doOnNext x=" + x);
                    }
                })
                .subscribe(subscriber);


        subscriber.assertError(RuntimeException.class);
    }

    @Test
    public void doOnSubscribe_001() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4)
                .doOnSubscribe( () -> Utils.log("* doOnSubscribe"))
                .subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void doOnUnsubscribe_001() {
        /*
        doOnUnsubscribe操作符注册一个动作，当观察者取消订阅它生成的Observable它就会被调用。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable observable = Observable.just(1, 2, 3, 4)
                .doOnUnsubscribe( () -> Utils.log("* doOnUnsubscribe"));

        observable.subscribe(x -> Utils.log("! subscribe x=" + x));
        observable.subscribe(subscriber);
        subscriber.assertCompleted();
    }

    @Test
    public void doOnUnsubscribe_002() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable observable = Observable.create(sub -> {
                    if (!sub.isUnsubscribed()) {
                        sub.onNext(1);
                        sub.onCompleted();
                    }
                })
                .doOnUnsubscribe( () -> {
                    Utils.log("* doOnUnsubscribe");
                    Utils.findCaller();
                });
        observable.subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void doOnCompleted_001() {
        /*
        doOnCompleted 操作符注册一个动作，当它产生的Observable正常终止调用onCompleted时会被调用。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4)
                .doOnCompleted( () -> Utils.log("* doOnCompleted"))
                .subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void doOnError_001() {
        /*
        doOnError 操作符注册一个动作，当它产生的Observable异常终止调用onError时会被调用。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4)
                .doOnNext(x -> {
                    if (x > 2) {
                        throw new RuntimeException( "Item exceeds maximum value" );
                    } else {
                        Utils.log("* doOnNext x=" + x);
                    }
                })
                .doOnError(e -> Utils.log("! doOnError e=" + e))
                .subscribe(subscriber);


        subscriber.assertError(RuntimeException.class);
    }

    @Test
    public void doOnTerminate_001() {
        /*
        doOnTerminate 操作符注册一个动作，当它产生的Observable终止之前会被调用，无论是正常还是异常终止。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2)
                .doOnTerminate( () -> Utils.log("* doOnTerminate"))
                .subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void doAfterTerminate_001() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2)
                .doAfterTerminate( () -> Utils.log("* doAfterTerminate"))
                .subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void serialize_001() {
        /*
        一个Observable可以异步调用它的观察者的方法，可能是从不同的线程调用。
        这可能会让Observable行为不正确，它可能会在某一个onNext调用之前尝试调用onCompleted或onError方法，
        或者从两个不同的线程同时调用onNext方法。使用Serialize操作符，你可以纠正这个Observable的行为，
        保证它的行为是正确的且是同步的。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable observable = Observable.create(sub -> {
            if (!sub.isUnsubscribed()) {
                new Thread(() -> {
                    sub.onNext(2);
                    sub.onNext(3);
                    Utils.sleep(10, TimeUnit.SECONDS);
                    sub.onNext(5);
                }).start();

                sub.onNext(1);
                Utils.sleep(1, TimeUnit.SECONDS);
                sub.onNext(4);
                sub.onCompleted();
            }
        }).serialize();
        observable.subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.awaitTerminalEvent();
    }

    @Test
    public void toMap_001() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4)
                .toMap(x -> {
                    int value = x%2;
                    return String.valueOf(value) + "[x=" + x + "]";
                })
                .subscribe(subscriber);

        subscriber.assertCompleted();

    }

    @Test
    public void toMap_002() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4)
                .toMap(new Func1<Integer, String>() {
                    @Override
                    public String call(Integer integer) {
                        int value = integer % 2;
                        return String.valueOf(value);
                    }
                }, new Func1<Integer, Integer>() {
                    @Override
                    public Integer call(Integer integer) {
                        return integer * 2;
                    }
                })
                .subscribe(subscriber);

        subscriber.assertCompleted();

    }

    @Test
    public void toMultiMap_001() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4)
                .toMultimap(x -> {
                    int value = x%2;
                    return String.valueOf(value);
                })
                .subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void toMultiMap_002() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(1, 2, 3, 4)
                .toMultimap(new Func1<Integer, String>() {
                    @Override
                    public String call(Integer integer) {
                        int value = integer % 2;
                        return String.valueOf(value);
                    }
                }, new Func1<Integer, Integer>() {
                    @Override
                    public Integer call(Integer integer) {
                        return integer * 2;
                    }
                })
                .subscribe(subscriber);

        subscriber.assertCompleted();

    }

    @Test
    public void toSortedList_001() {
        /*
        toSortedList类似于toList，不同的是，它会对产生的列表排序，默认是自然升序，
        如果发射的数据项没有实现Comparable接口，会抛出一个异常。然而，你也可以传递一个函数作为用于比较两个数据项，
        这时toSortedList不会使用Comparable接口。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(6, 1, 2, 5, 3)
                .toSortedList()
                .subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void toSortedList_002() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(6, 1, 2, 5, 3)
                .toSortedList((Integer x, Integer y) -> {
                    if (x > y) {
                        return -1;
                    } else {
                        return 1;
                    }
                })
                .subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void nest_001() {
        /*
        nest操作符有一个特殊的用途：将一个Observable转换为一个发射这个Observable的Observable
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        just(6, 1, 2, 5, 3)
                .nest()
                .flatMap(x -> x)
                .subscribe(subscriber);
        subscriber.assertCompleted();
    }


}
