package iyf.exdroid.support.common.guava;


import com.google.common.collect.Lists;

import org.junit.Test;

import java.util.List;

/**
 * 类名称：GuavaListsTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/2/13
 * 修改者， 修改日期， 修改内容
 */
public class GuavaListsTest {

    // The Lists.partition() method is an interesting method that returns sublists
    // of size n from a given list. The partition method returns consecutive sublists of the same size,
    // with the exception of the last sublist, which may be smaller.
    @Test
    public void Lists_partition() {
        List<String> strings = Lists.newArrayList("String1", "String2", "String3", "String4", "String5", "String6");

        List<List<String>> subList = Lists.partition(strings, 4);

        for (List<String> lst : subList) {
            System.out.println(lst);
        }

        /*
        [String1, String2, String3, String4]
        [String5, String6]
         */
    }



}
