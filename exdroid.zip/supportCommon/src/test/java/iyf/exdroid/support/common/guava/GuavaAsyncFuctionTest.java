package iyf.exdroid.support.common.guava;

import com.google.common.collect.Maps;
import com.google.common.util.concurrent.AsyncFunction;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import com.google.common.util.concurrent.SettableFuture;

import org.junit.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;

/**
 * 类名称：GuavaAsyncFuctionTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/3/6
 * 修改者， 修改日期， 修改内容
 */
public class GuavaAsyncFuctionTest {
    // AsyncFuction接口是Function接口的异步表现，AsyncFunction和Function都需要接收一个input参数，
    // 不同的是AsyncFunction接口返回的是 ListenableFuture，当我们需要接收AsyncFunction转换后的结果时，
    // 我们需要调用 ListenableFuture.get()方法。
    // AsyncFunction接口常被用于当我们想要异步的执行转换而不造成线程阻塞时，
    // 尽管Future.get()方法会在任务没有完成时造成阻塞，但 是AsyncFunction接口并不被建议用来异步的执行转换，
    // 它常被用于返回Future实例。

    @Test
    public void AsyncFunction_test() {
        final ListeningExecutorService listeningExecutorService =
                MoreExecutors.listeningDecorator(Executors.newFixedThreadPool(2));

        AsyncFunction<String, String> asyncFunction = new AsyncFunction<String, String>() {
            @Override
            public ListenableFuture<String> apply(final String input) throws Exception {
                return listeningExecutorService.submit(new Callable<String>() {
                    @Override
                    public String call() throws Exception {
                        return input + "101";
                    }
                });
            }
        };


        ListenableFuture<String> lis = listeningExecutorService.submit(new Callable<String>() {
            @Override
            public String call() throws Exception {
                return "张三";
            }
        });

        ListenableFuture<String> lf = Futures.transform(lis, asyncFunction);
        try {
            System.out.println(lf.get()); // 张三101
        } catch (Exception e) {

        }
    }

    @Test
    public void AsyncFunction_test1() {
        final CountDownLatch cdl = new CountDownLatch(1);

        class AsyncFunctionSample implements
                AsyncFunction<Long, String> {
            private ConcurrentMap<Long, String> map = Maps.newConcurrentMap();
            private ListeningExecutorService listeningExecutorService =
                    MoreExecutors.listeningDecorator(Executors.newFixedThreadPool(1));
            //这里简单的模拟一个service
            private Map<Long,String> service = new HashMap<Long, String>(){
                {
                    put(1L,"retrieved");
                }
            };

            @Override
            public ListenableFuture<String> apply(final Long input) throws
                    Exception {
                if (map.containsKey(input)) {
                    SettableFuture<String> listenableFuture = SettableFuture.create();
                    listenableFuture.set(map.get(input));
                    cdl.countDown();
                    return listenableFuture;
                } else {
                    return listeningExecutorService.submit(new Callable<String>() {
                        @Override
                        public String call() throws Exception {
                            //service中通过input获取retrieved
                            String retrieved = service.get(input);
                            if (null != retrieved) {
                                map.putIfAbsent(input, retrieved);
                            } else {
                                retrieved = "absent " + input;
                                map.put(input, retrieved);
                            }
                            cdl.countDown();
                            return retrieved;
                        }
                    });
                }
            }
        }

        ListeningExecutorService executorService = MoreExecutors.listeningDecorator(Executors.newCachedThreadPool());
        final ListenableFuture<Long> listenableFuture = executorService.submit(new Callable<Long>() {
            @Override
            public Long call() throws Exception {
                return 2L;
            }
        });

        ListenableFuture<String> lf = Futures.transform(listenableFuture, new AsyncFunctionSample());
        try {
            cdl.await();
            System.out.println(lf.get()); //retrieved
        } catch (Exception e) {

        }

    }

}
