package iyf.exdroid.support.common.generics;

import org.junit.Test;

/**
 * Created by imyfriend on 2017/7/15.
 */

public class Collection_001 {
    @Test
    public void test_001() {

    }
}
