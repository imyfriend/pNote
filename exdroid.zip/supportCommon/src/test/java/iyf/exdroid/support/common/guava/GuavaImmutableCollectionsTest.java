package iyf.exdroid.support.common.guava;

import com.google.common.collect.ImmutableListMultimap;
import com.google.common.collect.Multimap;

import org.junit.Test;

/**
 * 类名称：GuavaImmutableCollectionsTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/2/22
 * 修改者， 修改日期， 修改内容
 */
public class GuavaImmutableCollectionsTest {
    // However, if we don't explicitly have a need for a mutable collection,
    // we should always favor using an immutable one. First of all, immutable collections
    // are completely thread-safe. Secondly, they offer protection from unknown users
    // who may try to access your code.

    @Test
    public void ImmutableListMultimap_test() {
        Multimap<Integer, String> map = new
                ImmutableListMultimap.Builder<Integer,String>()
                .put(1,"Foo")
                .putAll(2,"Foo","Bar","Baz")
                .putAll(4,"Huey","Duey","Luey")
                .put(3,"Single")
                .build();
        System.out.println(map);//{1=[Foo], 2=[Foo, Bar, Baz], 4=[Huey, Duey, Luey], 3=[Single]}
    }

}
