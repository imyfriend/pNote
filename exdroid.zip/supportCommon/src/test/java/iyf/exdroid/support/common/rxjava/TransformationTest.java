package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Func0;
import rx.functions.Func1;
import rx.functions.Func2;
import rx.observables.BlockingObservable;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import static rx.Observable.just;

/**
 * Created by imyfriend on 2017/5/14.
 */

public class TransformationTest {
    /*
     The higher order functions which transform the incoming values into something else
     are called transformations.
     The higher order functions that can be invoked on an Observable instance,
     producing a new Observable instance from it, are called operators.
     */

    /*
    Note the use of the Subscriber.add() operator to add a new Subscription
instance to the subscriber, created using the Subscriptions.create() operator.
This method creates a Subscription instance using an action. This action will be
executed when the Subscription instance is unsubscribed, which means when
the Subscriber instance is unsubscribed in this case. So this is similar to putting
the closing of the stream in the final block.
     */

    @Test
    public void transformation_001() {
        Observable<String> mapped = just(2, 3, 5, 8)
                .map(new Func1<Integer, Integer>() {
                    @Override
                    public Integer call(Integer integer) {
                        return integer * 3;
                    }
                })
                .map(new Func1<Integer, String>() {
                    @Override
                    public String call(Integer v) {
                        return (v % 2 == 0) ? "even" : "odd";
                    }
                });
        subscribePrint(mapped, "map");
    }


    /*
    The flatMap operator is just like the map() operator, but with two differences:
Instead of receiving a function that transforms a value into an arbitrary type of
value, the flatMap operator's argument always transforms a value or sequence of
values into the form of an Observable instance.
It merges the values emitted by those resulting Observable instances. This means
that instead of emitting the Observable instances as values it emits their
notifications.
     */
    @Test
    public void transformation_002() {
        Observable<Integer> flatMapped = just(-1, 0 ,1)
                .map(new Func1<Integer, Integer>() {
                    @Override
                    public Integer call(Integer integer) {
                        return 2/integer;
                    }
                })
                .flatMap(new Func1<Integer, Observable<Integer>>() {
                    @Override
                    public Observable<Integer> call(Integer integer) {
                        return just(integer);
                    }
                }, new Func1<Throwable, Observable<? extends Integer>>() {
                    @Override
                    public Observable<? extends Integer> call(Throwable throwable) {
                        return just(0);
                    }
                }, new Func0<Observable<? extends Integer>>() {
                    @Override
                    public Observable<? extends Integer> call() {
                        return just(42);
                    }
                });
        subscribePrint(flatMapped, "flatMap");
    }

    /*
    This one combines items from the source Observable instance with the Observable
instance triggered by those source items and calls a user-supplied function with the pair
of the original and derived items. The Observable instance will then emit the result of
this function.
This overload is useful when all of the derivative items need to have access to their
source item and usually saves us from using some kind of tuple or pair classes, saving
on memory and library dependencies.
     */
    @Test
    public void transformation_003() {
        Observable<Integer> flatMapped = just(5, 432)
                .flatMap(new Func1<Integer, Observable<Integer>>() {
                    @Override
                    public Observable<Integer> call(Integer integer) {
                        return Observable.range(integer, 2);
                    }
                }, new Func2<Integer, Integer, Integer>() {
                    @Override
                    public Integer call(Integer integer, Integer integer2) {
                        return integer + integer2;
                    }
                });
        subscribePrint(flatMapped, "flatMap");
        /*
        flatMap : 10, thread name=main
        flatMap : 11, thread name=main
        flatMap : 864, thread name=main
        flatMap : 865, thread name=main
        flatMap ended!
         */
    }

    @Test
    public void flatMap_001() {
        Observable observable = Observable.just(1, 2, 3, 4, 5, 6)
                .flatMap(integer -> {
                    int time = 1;
                    if (integer % 2 == 0) {
                        time = 2;
                    }
                    return just(integer).delay(time, TimeUnit.SECONDS);
                });

        subscribePrint(observable, "flatMap_001");

        sleep(5, TimeUnit.SECONDS);
    }

    /*
    The operator flatMapIterable doesn't take as parameter lambda that takes arbitrary
value as a parameter and returns an Observable instance. Instead the lambda passed to
it takes arbitrary value and returns an Iterable instance. All of these Iterable
instances are flattened to values emitted by the resulting Observable instance.
This simple example merges the two lists emitted by the source Observable instance,
and the result emits the four items. It is worth mentioning that invoking
flatMapIterable(list -> list) is the same as invoking flatMap(l →
Observable.from(l)).
     */
    @Test
    public void flatMapIterable_001() {
        Observable<?> fIterableMapped =
                just(Arrays.asList(2,4),
                    Arrays.asList("two", "four"))
                .flatMapIterable(new Func1<List<? extends Serializable>, Iterable<?>>() {
            @Override
            public Iterable<?> call(List<? extends Serializable> serializables) {
                return serializables;
            }
        });
        subscribePrint(fIterableMapped, "fIterableMapped");
    }

    /*
    Another form of the flatMap operator is the concatMap operator. It behaves just like
the original flatMap operator, except that it concatenates rather than merges the
resulting Observable instance in order to generate its own sequence.
The items from the different derivative Observables are not interleaved, as with the
flatMap operator. A significant difference between the flatMap and concatMap
operators is that the flatMap operator uses the inner Observable instances in parallel,
whereas the concatMap operator only subscribes to one of the Observable instances at
a time.
     */
        @Test
        public void concatMap() {
            Observable<Integer> concatMap = just(-1 ,1)
                    .map(new Func1<Integer, Integer>() {
                        @Override
                        public Integer call(Integer integer) {
                            return 2/integer;
                        }
                    })
                    .concatMap(new Func1<Integer, Observable<? extends Integer>>() {
                        @Override
                        public Observable<? extends Integer> call(Integer integer) {
                            return just(integer);
                        }
                    });
            subscribePrint(concatMap, "concatMap");
        }

        @Test
        public void concatMap_001() {
            TestSubscriberEx subscriber = new TestSubscriberEx<>();

            Observable observable = Observable.just(1, 2, 3, 4, 5, 6)
                    .concatMap(integer -> {
                        int time = 1;
                        if (integer % 2 == 0) {
                            time = 2;
                        }
                        return just(integer).delay(time, TimeUnit.MILLISECONDS);
                    });

            //subscribePrint(observable, "concatMap_001");
            //sleep(10, TimeUnit.SECONDS);

            observable.subscribe(subscriber);

            subscriber.awaitTerminalEvent();
            subscriber.assertValueCount(6);
            List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5, 6);
            assertThat(subscriber.getOnNextEvents(), equalTo(expected));
        }

        /*
        switchMap operates in similar fashion to the flatMap operator, except that whenever a new item
is emitted by the source Observable instance, it stops mirroring the Observable
instance generated from the previously emitted item and it begins mirroring only the
current Observable instance. In other words, it internally unsubscribes from the current
derivative Observable instance when the next one begins emitting its items.
         */
        @Test
        public void switchMap() {
            TestSubscriberEx subscriber = new TestSubscriberEx<>();

            Observable<Object> obs = Observable.interval(40L, TimeUnit.MILLISECONDS)
                    .take(10)
                    .switchMap(new Func1<Long, Observable<?>>() {
                        @Override
                        public Observable<?> call(final Long u) {
                            return Observable.interval(0L, 10L, TimeUnit.MILLISECONDS)
                                    .map(new Func1<Long, Object>() {
                                        @Override
                                        public Object call(Long v) {
                                            return "Observable <" + (u+1) +
                                                    "> :" + (u + v);
                                        }
                                    })
                                    .take(5);
                        }
                    });
            /*subscribePrint(obs, "switchMap");

            BlockingObservable blockingObservable = obs.toBlocking();
            blockingObservable.forEach(x -> log(x));
            try {
                //Thread.sleep(4000L);
            } catch (Exception e) {

            }*/

            obs.subscribe(subscriber);

            subscriber.awaitTerminalEvent();
        }

        @Test
        public void switchMap_001() {
            Observable observable = Observable.just(1, 2, 3, 4, 5, 6)
                       .switchMap( (Integer integer) -> {
                           int time = 1;
                           if (integer % 2 == 0) {
                               time = 2;
                           }
                           return just(integer).delay(time, TimeUnit.SECONDS);
                       });

            //subscribePrint(observable, "switchMap_001");
            //Scheduler scheduler = Schedulers.immediate();
            //observable.observeOn(scheduler).subscribe(x -> log("x="+x));

            //sleep(10, TimeUnit.SECONDS);

            BlockingObservable blockingObservable = observable.toBlocking();
            blockingObservable.forEach(x -> log("x"));
        }

    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                        + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }

    static void sleep(int timeout, TimeUnit unit) {
        try {
            unit.sleep(timeout);
        } catch (InterruptedException ignored) {
            //intentionally ignored
        }
    }

    private static void log(Object msg) {
        System.out.println(
                Thread.currentThread().getName() +
                        ": " + msg);
    }

}
