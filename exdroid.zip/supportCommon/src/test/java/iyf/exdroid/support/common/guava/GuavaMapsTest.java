package iyf.exdroid.support.common.guava;

import android.support.annotation.Nullable;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 类名称：GuavaMapsTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/2/20
 * 修改者， 修改日期， 修改内容
 */
public class GuavaMapsTest {

    private List<Person> mPersonList;

    @Before
    public void setup() {
        mPersonList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            Person p = new Person(i, "name" + i, i * 2);
            mPersonList.add(p);
        }
    }

    // the Maps.uniqueIndex method uses Function to generate keys from the
    // given values
    @Test
    public void Maps_uniqueIndex() {
        Map<Long, Person> personMap = Maps.uniqueIndex(mPersonList.iterator(), new Function<Person, Long>() {
            @Nullable
            @Override
            public Long apply(Person input) {
                return new Long(input.getId());
            }
        });

        Joiner.MapJoiner mapJoiner = Joiner.on(",").withKeyValueSeparator("=");
        String           str       = mapJoiner.join(personMap);
        System.out.println(
                str); //0=Person{id=0, name=name0, age=0},1=Person{id=1, name=name1, age=2},2=Person{id=2, name=name2, age=4},3=Person{id=3, name=name3, age=6},4=Person{id=4, name=name4, age=8}
    }

    // the Maps.asMap method does the inverse operation. The Maps.asMap
    // method takes a set of objects to be used as keys, and Function is applied to each key
    // object to generate the value for entry into a map instance.
    @Test
    public void Maps_asMap() {
        Set<Person> personSet = Sets.newHashSet(mPersonList);
        Map<Person, String> personStringMap = Maps.asMap(personSet, new Function<Person, String>() {
            @Nullable
            @Override
            public String apply(Person input) {
                return String.valueOf(input.getId());
            }
        });

        Joiner.MapJoiner mapJoiner = Joiner.on(",").withKeyValueSeparator("=");
        String           str       = mapJoiner.join(personStringMap);
        System.out.println(str); //Person{id=0, name=name0, age=0}=0,Person{id=1, name=name1, age=2}=1,Person{id=2, name=name2, age=4}=2,Person{id=3, name=name3, age=6}=3,Person{id=4, name=name4, age=8}=4
    }

    // the Maps.transformValues method
    // uses Function that takes the map's original value and transforms it into a new
    // value for the same key in the original map.
    @Test
    public void Maps_transformValues() {
        Map<Long, Person> personMap = Maps.uniqueIndex(mPersonList.iterator(), new Function<Person, Long>() {
            @Nullable
            @Override
            public Long apply(Person input) {
                return new Long(input.getId());
            }
        });

        Map<Long, String> transformValuesMap = Maps.transformValues(personMap, new Function<Person, String>() {
            @Override
            public String apply(Person input) {
                return input.getName();
            }
        });

        System.out.println(transformValuesMap); //{0=name0, 1=name1, 2=name2, 3=name3, 4=name4}
    }




}
