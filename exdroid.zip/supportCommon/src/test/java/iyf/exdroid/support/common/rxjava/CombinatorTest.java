package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Func2;
import rx.schedulers.Schedulers;

/**
 * 类名称：CombinatorTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/5/16
 * 修改者， 修改日期， 修改内容
 */
public class CombinatorTest {
    /*
    the zip(Observable, Observable, <Observable>..., Func)
operator, which can combine two or more Observable instances using a combining
function.
The function passed to the zip operator has as many parameters as the number of the
Observable instances passed to the zip() method. When all of these Observable
instances emit at least one item, the function is called with the parameter values first
emitted by each of the Observable instances. Its result will be the first emitted item by
the Observable instance created via the zip() method. The second item emitted by this
Observable instance will be a combination (computed using the function parameter of
the zip() method) of the second items of the source Observable instances. Even if one
of the source Observable instances has emitted three or more items, its second emitted
item is used. The resulting Observable instance always emits the same number of items
as the source Observable instance, which emits the fewest items and then completes.
     */
    @Test
    public void zip_001() {
        Observable<Integer> zip = Observable.zip(Observable.just(1, 2, 3), Observable.just(4, 5, 6), new Func2<Integer, Integer, Integer>() {
            @Override
            public Integer call(Integer v1, Integer v2) {
                return v1+ v2;
            }
        });
        subscribePrint(zip, "zip");
    }

    @Test
    public void zip_002() {
        Observable<String> timedZip = Observable.zip(Observable.from(Arrays.asList("Z", "I", "P", "P")), Observable.interval(300L, TimeUnit.MILLISECONDS), new Func2<String, Long, String>() {
            @Override
            public String call(String s, Long aLong) {
                return s;
            }
        });
        subscribePrint(timedZip, "timedZip");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void zipWith() {
        Observable<String> timedZip = Observable
                .from(Arrays.asList("Z", "I", "P", "W"))
                .zipWith(Observable.interval(300L, TimeUnit.MILLISECONDS), new Func2<String, Long, String>() {
                    @Override
                    public String call(String s, Long aLong) {
                        return s;
                    }
                });
        subscribePrint(timedZip, "Timed zip");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    /*
    The combineLatest() operator has the same parameters and overloads as the zip()
operator but behaves a bit differently. The Observable instance it creates emits the first
item as soon as there is at least one of each source, taking the last of each. After that, the
Observable instance it creates emits an item whenever any of the source Observable
instances emits an item. The number of items emitted by the combineLatest() operator
depends entirely on the order of items emitted, since multiple items could be emitted
from a single source before there is one of each source.
The combineLatest() operator is very useful when we need computation or
notification when any of the data sources we depend on changes.
     */
    @Test
    public void combineLatest() {
        Observable<Boolean> validObservable = Observable.combineLatest(
                Observable.just(1, 2, 3).zipWith(Observable.interval(300L, TimeUnit.MILLISECONDS),
                                                 new Func2<Integer, Long, Integer>() {
                                                     @Override
                                                     public Integer call(Integer integer, Long aLong) {
                                                         return integer;
                                                     }
                                                 }),
                Observable.just("1", "2", "3").zipWith(Observable.interval(400L, TimeUnit.MILLISECONDS),
                                                       new Func2<String, Long, String>() {
                                                           @Override
                                                           public String call(String s, Long aLong) {
                                                               return s;
                                                           }
                                                       }),
                new Func2<Integer, String, Boolean>() {
                    @Override
                    public Boolean call(Integer integer, String s) {
                        System.out.println("integer=" + integer + ", s=" + s);
                        return (integer + Integer.parseInt(s)) % 2 == 0;
                    }
                }
        );
        subscribePrint(validObservable, "validObservable");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

        /*
        When we want to get feeds from multiple sources as one stream, we can use the
merge() operator. For example, we can have many Observable instances emitting data
from different log files. We don't care which log file is the source of the current
emission, we just want to see all the logs.
        Emissions will continue to take place until the source
Observable instance, which takes the most time, completes.
        It is worth mentioning that if any of the sources emits an OnError notification, the merge
Observable instance emits the error too and completes with it. There is a form of
merge() operator that delays emitting errors until all the error-free source Observable instances are completed.
It is called mergeDelayError().
         */
        @Test
        public void merge() {
            Observable<String> merged = Observable
                    .merge(Observable.just("1", "2", "3"), Observable.just("11", "21", "31"));
            subscribePrint(merged, "merge");
        }

        @Test
        public void merge_002() {
            Observable<Runnable> observable1 = Observable.just(new Runnable() {
                @Override
                public void run() {
                    System.out.println("observable1 Runnable1 ");
                }
            }, new Runnable() {
                @Override
                public void run() {
                    Utils.sleep(1000, TimeUnit.MILLISECONDS);
                    System.out.println("observable1 Runnable2 ");
                }
            });

            Observable<Runnable> observable2 = Observable.just(new Runnable() {
                @Override
                public void run() {
                    System.out.println("observable2 Runnable1 ");
                }
            }, new Runnable() {
                @Override
                public void run() {
                    Utils.sleep(1000, TimeUnit.MILLISECONDS);
                    System.out.println("observable2 Runnable2 ");
                }
            });

            Observable<Runnable> merge = Observable.merge(observable1, observable2);

            merge.subscribe(new Subscriber<Runnable>() {
                @Override
                public void onCompleted() {
                    System.out.println(" ended!");
                }

                @Override
                public void onError(Throwable e) {
                    System.err.println("Error from :");
                    System.err.println(e.getMessage());
                }

                @Override
                public void onNext(Runnable t) {
                    System.out.println("onNext : " + t
                                               + ", thread name=" + Thread.currentThread().getName());
                    t.run();
                }
            });
        }

    @Test
    public void merge_003() {
        Observable<Long> merge = Observable
                .merge(Observable.interval(1, TimeUnit.SECONDS, Schedulers.immediate()).take(5),
                        Observable.interval(100, TimeUnit.MILLISECONDS, Schedulers.immediate()).take(1));
        subscribePrint(merge, "merge_003");
    }

    @Test
    public void merge_004() {
        Observable<Long> merge = Observable
                .merge(Observable.interval(1, TimeUnit.SECONDS).take(5).map(i -> i * 100),
                       Observable.interval(100, TimeUnit.MILLISECONDS).take(1));
        subscribePrint(merge, "merge_003");

        Utils.sleep(1, TimeUnit.MINUTES);
    }

        /*
        If we want to combine our sources in such a way that their items don't interleave in time
and the emissions of the first passed source take precedence over the next one, we will
be using the last combinator that this chapter introduces—the concat() operator.
        The main difference between the merge() and concat() operators is that merge()subscribes to
all source Observable instances at the same time, whereas concat()has exactly one
subscription at any time.
         */
        @Test
        public void concat_001() {
            Observable<String> concat = Observable
                    .concat(Observable.just("1", "2", "3"), Observable.just("11", "21", "31"));
            subscribePrint(concat, "concat");
        }

        @Test
        public void concat_002() {
            Observable<Runnable> observable1 = Observable.just(new Runnable() {
                @Override
                public void run() {
                    System.out.println("observable1 Runnable1 ");
                }
            }, new Runnable() {
                @Override
                public void run() {
                    Utils.sleep(100, TimeUnit.MILLISECONDS);
                    System.out.println("observable1 Runnable2 ");
                }
            });

            Observable<Runnable> observable2 = Observable.just(new Runnable() {
                @Override
                public void run() {
                    Utils.sleep(100, TimeUnit.MILLISECONDS);
                    System.out.println("observable2 Runnable1 ");
                }
            }, new Runnable() {
                @Override
                public void run() {
                    System.out.println("observable2 Runnable2 ");
                }
            });

            Observable<Runnable> concat = Observable.concat(observable1, observable2);

            concat.subscribe(new Subscriber<Runnable>() {
                @Override
                public void onCompleted() {
                    System.out.println(" ended!");
                }

                @Override
                public void onError(Throwable e) {
                    System.err.println("Error from :");
                    System.err.println(e.getMessage());
                }

                @Override
                public void onNext(Runnable t) {
                    System.out.println("onNext : " + t
                                               + ", thread name=" + Thread.currentThread().getName());
                    t.run();
                }
            });
        }

        @Test
        public void concat_003() {
            Observable<Long> concat = Observable
                    .concat(Observable.interval(50, TimeUnit.MILLISECONDS, Schedulers.immediate()).take(5),
                            Observable.interval(100, TimeUnit.MILLISECONDS, Schedulers.immediate()).take(1));
            subscribePrint(concat, "concat_003");
        }

        /*
        startWith操作符通过传递一个参数来先发射一个数据序列。
         */
        @Test
        public void startWith() {
            Observable<String> startWith = Observable.just("11", "21", "31").startWith(Observable.just("1", "2", "3"));
            subscribePrint(startWith, "startWith");
        }


    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                                           + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }
}
