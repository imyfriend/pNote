package iyf.exdroid.support.common.guava;

import com.google.common.eventbus.DeadEvent;
import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;

import org.junit.Test;

/**
 * 类名称：GuavaEventBusTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/30
 * 修改者， 修改日期， 修改内容
 */
public class GuavaEventBusTest {

    @Test
    public void EventBus_single() {
        // given
        EventBus eventBus = new EventBus("test");
        EventListener listener = new EventListener();

        eventBus.register(listener);

        // when
        eventBus.post(new OurTestEvent(200));

        System.out.println("lastMessage=" + listener.getLastMessage() + ", bus=" + eventBus); //
    }

    @Test
    public void EventBus_multiple() {
// given
        EventBus eventBus = new EventBus("test");
        MultipleListener multiListener = new MultipleListener();

        eventBus.register(multiListener);

        // when
        eventBus.post(new Integer(100));
        eventBus.post(new Long(800));

        // then
        System.out.println("getLastInteger=" + multiListener.getLastInteger() + ", bus=" + eventBus);
        System.out.println("getLastLong=" + multiListener.getLastLong() + ", bus=" + eventBus);
    }

    @Test
    public void EventBus_deadEvent() {
        // given
        EventBus eventBus = new EventBus("test");

        DeadEventListener deadEventListener = new DeadEventListener();
        eventBus.register(deadEventListener);

        // when
        eventBus.post(new OurTestEvent(200));

        System.out.println("deadEvent=" + deadEventListener.isNotDelivered()); // deadEvent=true
    }

    /*
    EventBus will call event-handling methods serially, so it's important that those methods complete quickly.
    If any extended processing needs to be done as a result of receiving an event,
    it's best to run that code in a separate thread.
     */
    // 如果Listener A监听Event A, 而Event A有一个子类Event B, 此时Listener A将同时接收Event A和B消息
    @Test
    public void EventBus_event() {
        // given
        EventBus eventBus = new EventBus("test");
        IntegerListener integerListener = new IntegerListener();
        NumberListener numberListener = new NumberListener();
        eventBus.register(integerListener);
        eventBus.register(numberListener);

        System.out.println("Thread name: " + Thread.currentThread().getName());
        // when
        eventBus.post(new Integer(100));

        // then
        System.out.println(integerListener.getLastMessage()); // 100
        System.out.println(numberListener.getLastMessage()); // 100

        //when
        eventBus.post(new Long(200L));

        // then
        // this one should has the old value as it listens only for Integers
        System.out.println(integerListener.getLastMessage()); // 100
        System.out.println(numberListener.getLastMessage()); // 200
    }

    public class EventListener {

        public int lastMessage = 0;

        // 使用Guava之后, 如果要订阅消息, 就不用再继承指定的接口, 只需要在指定的方法上加上@Subscribe注解即可:
        @Subscribe
        public void listen(OurTestEvent event) {
            lastMessage = event.getMessage();
        }

        public int getLastMessage() {
            return lastMessage;
        }
    }

    public class OurTestEvent {

        private final int message;

        public OurTestEvent(int message) {
            this.message = message;
        }

        public int getMessage() {
            return message;
        }
    }

    // 在要订阅消息的方法上加上@Subscribe注解即可实现对多个消息的订阅
    public class MultipleListener {

        public Integer lastInteger;
        public Long lastLong;

        @Subscribe
        public void listenInteger(Integer event) {
            lastInteger = event;
        }

        @Subscribe
        public void listenLong(Long event) {
            lastLong = event;
        }

        public Integer getLastInteger() {
            return lastInteger;
        }

        public Long getLastLong() {
            return lastLong;
        }
    }

    /*
    When EventBus receives a notification of an event through the post method,
    and there are no registered subscribers, the event is wrapped in an instance of a
    DeadEvent class. Having a class that subscribes for DeadEvent instances can be
    very helpful when trying to ensure that all events have registered subscribers.
    The DeadEvent class exposes a getEvent method that can be used to inspect the
    original event that was undelivered.
     */
    // 如果EventBus发送的消息都不是订阅者关心的称之为Dead Event.
    public class DeadEventListener {

        boolean notDelivered = false;

        @Subscribe
        public void listen(DeadEvent event) {
            notDelivered = true;
            System.out.println("in DeadEventListener.listen(), original event=" + event.getEvent()); // 100
        }

        public boolean isNotDelivered() {
            return notDelivered;
        }
    }

    public class NumberListener {

        private Number lastMessage;

        @Subscribe
        public void listen(Number integer) {
            lastMessage = integer;
        }

        public Number getLastMessage() {
            return lastMessage;
        }
    }


    public class IntegerListener {

        private Integer lastMessage;

        @Subscribe
        public void listen(Integer integer) {
            lastMessage = integer;
            System.out.println("IntegerListener Thread name: " + Thread.currentThread().getName());
        }

        public Integer getLastMessage() {
            return lastMessage;
        }
    }

    /*
    EventBus will not call the handler methods from multiple threads, unless the handler
    method is marked with the @AllowConcurrentEvent annotation. By marking a
    handler method with the @AllowConcurrentEvent annotation, we are asserting
    that our handler method is thread-safe.
     */


}
