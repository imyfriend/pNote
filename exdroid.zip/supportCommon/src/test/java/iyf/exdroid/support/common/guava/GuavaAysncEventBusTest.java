package iyf.exdroid.support.common.guava;

import com.google.common.eventbus.AsyncEventBus;
import com.google.common.eventbus.Subscribe;

import org.junit.Test;

import java.util.concurrent.Executors;

/**
 * Created by ii on 2017/3/27.
 */

public class GuavaAysncEventBusTest {

    @Test
    public void AysncEventBus_test01() {
        AsyncEventBus eventBus = new AsyncEventBus(Executors.newFixedThreadPool(3));
        eventBus.register(new Event());
        eventBus.post("ssdf");
        System.out.println("Thread name: " + Thread.currentThread().getName());
    }

    public static class Event {

        @Subscribe
        public void sub(String message) {
            System.out.println("in Event.sub(), message=" + message
                              + ". Thread name: " + Thread.currentThread().getName());
        }

    }


}
