package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Func1;
import rx.functions.Func2;import static rx.Observable.just;

/**
 * 类名称：ConditionalTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/5/17
 * 修改者， 修改日期， 修改内容
 */
public class ConditionalTest {
    /*
    The amb() operator has overloads that take from two up to nine source Observable
instances or an Iterable instance of the Observable instances. It emits the items of the
source Observable instance that starts emitting first. It doesn't matter what this is,
whether OnError, OnCompleted notification, or data.
该操作函数可以用于如下情况：

你有多个廉价的资源提供方，但是这些资源提供方返回数据的时间是不一样的。
例如一个天气预报应用，可以从多个数据源获取数据，当其中一个数据源返回数据的时候，就丢弃其的请求，而使用这个数据源。
     */
    @Test
    public void amb() {
        Observable<String> words = just("Some", "Other");
        Observable<Long> interval = Observable
                .interval(500L, TimeUnit.MILLISECONDS)
                .take(2);
        subscribePrint(Observable.amb(words, interval), "Amb 1");
    }

    /*
    ambWith通过链式调用每个 Observable，让代码看起来更优雅一些
     */
    @Test
    public void ambWith() {
        Observable<String> ambWith = Observable.timer(100, TimeUnit.MILLISECONDS)
                .map(new Func1<Long, String>() {
                    @Override
                    public String call(Long aLong) {
                        return "First";
                    }
                })
                .ambWith(Observable.timer(50, TimeUnit.MILLISECONDS).map(new Func1<Long, String>() {
                    @Override
                    public String call(Long aLong) {
                        return "Second";
                    }
                }))
                .ambWith(Observable.timer(70, TimeUnit.MILLISECONDS).map(new Func1<Long, String>() {
                    @Override
                    public String call(Long aLong) {
                        return "Third";
                    }
                }));
        subscribePrint(ambWith, "ambWith 1");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    /*
    The takeUntil() operator takes another Observable instance, and until this other
Observable instance emits, the source's items are emitted; after that, the Observable
instance created by the takeUntil() operator completes.
    These conditional operators can be used, for example, for displaying loading animation
in GUI applications. The code can be something like this:
loadingAnimationObservable.takeUntil(requestObservable);
On every emission of the loadingAnimationObservable variable, some short-lived
animation will be displayed to the user. When the request is returned, the animation will
no longer be displayed. This is another way of branching the logic of a program.
     */
    @Test
    public void takeUntil() {
        Observable<String> words = // (1)
                just("one", "way", "or", "another", "I'll", "learn", "RxJava")
                .zipWith(Observable.interval(200L, TimeUnit.MILLISECONDS), new Func2<String, Long, String>() {
                    @Override
                    public String call(String s, Long aLong) {
                        return s;
                    }
                });
        Observable<Long> interval = Observable
                .interval(500L, TimeUnit.MILLISECONDS);
        subscribePrint(words.takeUntil(interval), "takeUntil"); // (2)
        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }

        subscribePrint( // (3)
                        words.takeWhile(new Func1<String, Boolean>() {
                            @Override
                            public Boolean call(String s) {
                                return s.length() > 2;
                            }
                        }), "takeWhile 1"
                      );
        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }

        subscribePrint(words.skipUntil(interval), "skipUntil"); // (4)

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    /*
    The idea of the defaultIfEmpty() operator is to return something useful if an unknown
source turns out to be empty.
     */
    @Test
    public void defaultIfEmpty() {
        Observable<Object> test = Observable
                .empty()
                .defaultIfEmpty(5);
        subscribePrint(test, "defaultIfEmpty");

        Observable<Integer> test1 = just(1,2).defaultIfEmpty(5);
        subscribePrint(test1, "defaultIfEmpty 1");
    }

    /*
    all： 判断所有的数据项是否满足某个条件，内部通过OperatorAll实现
     */
    @Test
    public void all() {
        Observable<Boolean> all = Observable.just(2,3,4,5)
                .all(new Func1<Integer, Boolean>() {
                    @Override
                    public Boolean call(Integer integer) {
                        return integer>3;
                    }
                });

        subscribePrint(all, "all");
    }

    /*
    exists： 判断是否存在数据项满足某个条件。内部通过OperatorAny实现
     */
    @Test
    public void exists() {
        Observable exists = Observable.just(2,3,4,5)
                .exists(new Func1<Integer, Boolean>() {
                    @Override
                    public Boolean call(Integer integer) {
                        return integer > 3;
                    }
                });
        subscribePrint(exists, "exists");
    }

    /*
    contains： 判断在发射的所有数据项中是否包含指定的数据，内部调用的其实是exists
     */
    @Test
    public void contains() {
        Observable contains = Observable.just(2,3,4,5)
                .contains(3);
        subscribePrint(contains, "contains");
    }

    /*
    sequenceEqual： 用于判断两个Observable发射的数据是否相同（数据，发射顺序，终止状态）
     */
    @Test
    public void sequenceEqual() {
        Observable sequenceEqual = Observable.sequenceEqual(Observable.just(2,3,4,5),
                                                            Observable.just(2,3,4,5,6));
        subscribePrint(sequenceEqual, "sequenceEqual");
    }

    /*
    isEmpty： 用于判断Observable发射完毕时，有没有发射数据。有数据false，如果只收到了onComplete通知则为true。
     */
    @Test
    public void isEmpty() {
        Observable isEmpty = Observable.just(3,4,5,6)
                .isEmpty();
        subscribePrint(isEmpty, "isEmpty");
    }

    /*
    switchIfEmpty： 如果原始Observable正常终止后仍然没有发射任何数据，就使用备用的Observable。
     */
    @Test
    public void switchIfEmpty() {

    }

    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                                           + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }
}
