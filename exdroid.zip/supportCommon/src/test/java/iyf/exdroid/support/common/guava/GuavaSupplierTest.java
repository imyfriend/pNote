package iyf.exdroid.support.common.guava;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;

import org.junit.Test;

/**
 * 类名称：GuavaSupplierTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/2/10
 * 修改者， 修改日期， 修改内容
 */
public class GuavaSupplierTest {
    // The get method returns an instance of type T and only of that type. The Supplier
    // interface helps us implement several of the typical creational patterns. When get
    // is called, we could always return the same instance (singleton) or a new instance
    // with each invocation. A Supplier interface also gives you the ﬂexibility to use lazy
    // instantiation by not constructing an instance until the get method is called. Also,
    // since the Supplier is an interface, unit testing becomes much easier, as compared
    // to other approaches for creating objects such as a static factory method. In short,
    // the power of the Supplier interface is that it abstracts the complexity and details of
    // how an object needs to be created, leaving the developer free to create an object in
    // whatever way he/she feels is the best approach. Let's take a look at how we might
    // use a Supplier interface

    public class StringSupplier implements Supplier<String> {

        @Override
        public String get() {
            return "StringSupplierGet";
        }
    }

    // The Suppliers.memoize method returns a Supplier instance that wraps a provided
    // delegate Supplier instance. When the frst call to get is executed, the call is passed
    // to the delegate Supplier instance; it creates and returns the instance to the wrapping
    // Supplier object. The wrapping Supplier object caches the instance before returning
    // it to the caller. All subsequent calls to the get method return the cached instance.
    @Test
    public void Suppliers_memoize() {
        Supplier<String> supplier = Suppliers.memoize(new StringSupplier());
        System.out.println(supplier.get());
    }


}
