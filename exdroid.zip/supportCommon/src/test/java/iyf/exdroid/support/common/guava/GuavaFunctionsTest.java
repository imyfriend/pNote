package iyf.exdroid.support.common.guava;

import com.google.common.base.Function;
import com.google.common.base.Functions;
import com.google.common.base.Joiner;
import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;

import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 类名称：GuavaFunctionsTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/27
 * 修改者， 修改日期， 修改内容
 */
// https://my.oschina.net/indestiny/blog/215041
public class GuavaFunctionsTest {
    // Functions其功能就是将输入类型转换为输出类型
    // the Function interface is used to transform objects

    // A good Function implementation should have no side effects, meaning the
    // object passed as an argument should remain unchanged after the apply method has
    // been called.
    // One advantage to having a class implement the Function interface is that you
    // could use dependency injection to pass a Function interface into a collaborating
    // class and increase your code's cohesion.

    @Test
    public void Functions_apply() {
        class DateFormatFunction implements Function<Date, String> {
            @Override
            public String apply(Date input) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/mm/yyyy");
                return dateFormat.format(input);
            }
        }

        System.out.println(new DateFormatFunction().apply(new Date()));
    }

    @Test
    public void Functions_forMap() {
        Map<String, State> states = new HashMap<String, State>();
        //Function<String, State> lookup = Functions.forMap(states);

        //你也可以给不存在的key指定一个默认值
        Function<String, State> lookup = Functions.forMap(states, null);

        System.out.println(lookup.apply("dalian"));//key不存在会抛异常
    }

    @Test
    public void Functions_compose() {
        /**
         * 将州的城市转换为字符串
         */
        class StateToCityString implements Function<State, String> {
            @Override
            public String apply(State input) {
                return Joiner.on(",").join(input.mainCities);
            }
        }

        Map<String, State> states = new HashMap<>();
        State state = new State("code", "liNing");
        state.mainCities.add(new City("ShenYang", "110000", 1300));
        state.mainCities.add(new City("DaLian", "110001", 1400));
        states.put("liNing", state);

        Function<String, State> lookup = Functions.forMap(states);
        Function<State, String> stateFunction = new StateToCityString(); //州到城市的转换
        Function<String, String> stateCitiesFunction = Functions.compose(stateFunction, lookup); //组合Function
        System.out.println(stateCitiesFunction.apply("liNing"));

        Suppliers.memoize(null);
    }

    /**
     * 州类
     */
    public class State {
        private String name;
        private String code;
        private Set<City> mainCities = new HashSet<City>();

        State(String name, String code) {
            this.name = name;
            this.code = code;
        }
    }

    /**城市类**/
    public class City {
        City(String name, String zipCode, int population) {
            this.name = name;
            this.zipCode = zipCode;
            this.population = population;
        }

        private String name;
        private String zipCode;
        private int population;

        @Override
        public String toString() {
            return name;
        }
    }


}
