package iyf.exdroid.support.common.Java8Lambda;

import com.android.internal.util.Predicate;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by imyfriend on 2017/6/24.
 */

public class Chapter2 {
    @Test
    public void test_001() {
        Predicate<Integer> atLeast5 = x -> x>5;

        List<String> strings = new ArrayList<>();
        strings.stream().filter(str -> str.length() > 5).count();

        //System.out.println();
    }
}
