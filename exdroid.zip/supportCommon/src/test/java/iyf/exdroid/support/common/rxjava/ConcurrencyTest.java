package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import rx.Notification;
import rx.Observable;
import rx.Scheduler;
import rx.Scheduler.Worker;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * 类名称：ConcurrencyTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/5/19
 * 修改者， 修改日期， 修改内容
 */
public class ConcurrencyTest {
    /*
    RxJava is single-threaded by default. This means that, in the most cases,
    when the subscribe method is called on an Observable instance,
    the current thread blocks until everything is emitted.(This is not true for the
    Observable instances created by the interval or timer factory methods, for
    example.).
    One of the hardest things to manage in a multi-threaded environment is the shared data
    between the threads. One thread could read from a data source while another is
    modifying it, which leads to different versions of the same data being used by the
    different threads. If an Observable chain is constructed the right way, there is no shared
    state. This means that synchronization is not so complex.
    The schedulers are the RxJava's way of achieving concurrency. They are in charge of
    creating and managing the threads for us (internally relying on Java's thread-pool
    facilities).
    RxJava is single-threaded by default, so in most cases, calling the
    subscribe method on the Observable instance will block the current thread. But that is
    not the case with the interval Observable instances. If we look at the JavaDoc of the
    Observable<Long> interval(long interval, TimeUnit unit) method, we'll see
    that it says that the Observable instance created by it operates on something called 'the
    computation Scheduler'.
     */

    /*
    The doOnEach() operator. We can log everything from it because it receives all the notifications emitted,
    which combines doOnNext()、doOnError() and doOnCompleted() operators, regardless of their type.
     */
    @Test
    public void doOnEach_001() {
        Observable.range(5, 5)
                .doOnEach(ConcurrencyTest.<Integer>debug("Test", ""))
                .subscribe();
    }

    @Test
    public void doOnEach_002() {
        /*
        the interval() operates on the computation scheduler.
         */
        Observable.interval(500L, TimeUnit.MILLISECONDS)
                .take(5)
                .doOnEach(ConcurrencyTest.<Long>debug("Default interval"))
                .subscribe();

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void doOnEach_003() {
        /*
        Schedulers.immediate() executes the work immediately on the currently running thread.
         */
        Observable.interval(500L, TimeUnit.MILLISECONDS, Schedulers.immediate())
                .take(5)
                .doOnEach(ConcurrencyTest.<Long>debug("immediate interval"))
                .subscribe();

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    /*
    the Scheduler class turns out that the class is quite simple. It has only two methods, as follows:
1, long now()
2, abstract Worker createWorker()
The first one returns the current time in milliseconds, and the second creates a Worker
instance. These Worker instances are used for executing actions on a single thread or
event loop (depending on the implementation). Scheduling actions for execution is done
using the Worker's schedule* methods. The Worker class implements the
Subscription interface, so it has an unsubscribe() method. Unsubscribing the
Worker unschedules all outstanding work and allows a resource cleanup.

We can use the workers to perform scheduling outside the Observable context. For
every Scheduler type, we can do the following:
1, scheduler.createWorker().schedule(Action0);
This will schedule the passed action and execute it. In most cases, this method shouldn't
be used directly for scheduling work, we just pick the right scheduler and schedule
actions on it instead.In a real-world scenario, once all the work has been done, we should always invoke the
worker.unsubscribe() method.
     */

    /*
    The Schedulers.immediate scheduler executes work here and now. When an action is
passed to its worker's schedule(Action0) method, it is just called.
Schedulers.immediate 在当前线程立即开始执行任务
     */
    @Test
    public void schedule_001() {
        schedule(Schedulers.immediate(), 2, false);
    }

    @Test
    public void schedule_002() {
        schedule(Schedulers.immediate(), 2, true);
    }

    /*
    The scheduler, retrieved by the Schedulers.trampoline method enqueues sub-tasks
on the current thread. The enqueued work is executed after the work currently in
progress completes. The trampoline scheduler is useful for avoiding a StackOverflowError exception
while running many tasks recursively. However, the trampoline scheduler is usually slower than the
immediate one. So, using the correct one depends on the use case.
Schedulers.trampoline( )	当其它排队的任务完成后，在当前线程排队开始执行
     */
    @Test
    public void schedule_003() {
        /*
        the result will be the same as with the immediate scheduler, because all
the tasks are executed in their own Worker instances and, therefore, there is only one
task to be enqueued for execution in every worker.
         */
        schedule(Schedulers.trampoline(), 2, false);
    }

    @Test
    public void schedule_004() {
        /*
        it will first execute the entire main action and after that, the sub-tasks;
thus, the List instance will be filled in (the sub-tasks were enqueued) but never
emptied. That's because, while executing the main task, the List instance was still
empty and the while loop was not triggered.
         */
        schedule(Schedulers.trampoline(), 2, true);
    }

    /*
    This schedule creates a new Thread instance (a single-threaded
ScheduledThreadPoolExecutor instance to be precise) for every new Worker instance.
Additionally, each worker enqueues the actions it receives through its
schedule() method, much like the trampoline scheduler does.
     */
    @Test
    public void schedule_005() {
        schedule(Schedulers.newThread(), 2, true);

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void schedule_006() {
        schedule(Schedulers.newThread(), 2, false);

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

     /*
    The computation scheduler is very similar to the new thread one, but it takes into
account the number of processors/cores that the machine on which it runs has, and uses a
thread pool that can reuse a limited number of threads. Every new Worker instance
schedules sequential actions on one of these Thread instances. If the thread is not used
at the moment they are executed, and if it is active, they are enqueued to execute on it
later.
    If we use the same Worker instance, we'll just enqueue all the actions on its thread and
the result will be the same as scheduling with one Worker instance, using the new
thread Scheduler instance.
    Everything is executed using only four Thread instances from a pool (note that there is a
way to limit the number of Thread instances to be less than the available processor
count).
    The computation Scheduler instance is your real choice for doing background work—
computations or processing thus its name. You can use it for everything that should run
in the background and is not an IO related or blocking operation.
     */
     @Test
     public void schedule_007() {
         schedule(Schedulers.computation(), 5, false);
         try {
             Thread.sleep(4000L);
         } catch (Exception e) {

         }
     }

     /*
     The Input-Output (IO) scheduler uses a ScheduledExecutorService instance to
retrieve the threads from a thread pool for its workers. Unused threads are cached and
reused on demand. It can spawn an arbitrary number of threads if it is necessary.
    The IO scheduler is reserved for blocking IO operations. Use it for requests to servers,
reading from files and sockets, and other similar blocking tasks. Note that its thread
pool is unbounded; if its workers are not unsubscribed, the pool will grow indefinitely.
      */
     @Test
     public void schedule_008() {
         schedule(Schedulers.io(), 5, false);
         try {
             Thread.sleep(4000L);
         } catch (Exception e) {

         }
     }

     /*
     The Schedulers.from(Executor) method
This can be used to create a custom Scheduler instance. If none of the predefined
schedulers work for you, use this method, passing it to a
java.util.concurrent.Executor instance, to implement the behavior you need.
      */

     /*
     The Observable<T> subscribeOn(Scheduler) method
The subscribeOn() method creates an Observable instance, whose subscribe
method causes the subscription to occur on a thread retrieved from the passed
scheduler.
      */
    @Test
    public void subscribeOn_001() {
        /*
        构造器中的计数值（count）实际上就是闭锁需要等待的线程数量。
        这个值只能被设置一次，而且CountDownLatch没有提供任何机制去重新设置这个计数值。
         */
        final CountDownLatch latch = new CountDownLatch(1);
        Observable<Integer> range = Observable
                .range(20, 4)
                .doOnEach(ConcurrencyTest.<Integer>debug("Source"))
                .subscribeOn(Schedulers.computation())
                .doAfterTerminate(new Action0() {
                    @Override
                    public void call() {
                        latch.countDown();
                    }
                });

        range.subscribe();
        System.out.println("Hey!");
        try {
            /*
            与CountDownLatch的第一次交互是主线程等待其他线程。主线程必须在启动其他线程后立即调用CountDownLatch.await()方法。
            这样主线程的操作就会在这个方法上阻塞，直到其他线程完成各自的任务。
             */
            latch.await();
        } catch (Exception e) {

        }
    }

    /*
    The call to it that is the closest to the beginning of the chain matters. Here we subscribe
on the computation scheduler first, then on the IO scheduler, but our code will be executed on
the computation scheduler because this is specified first in the chain.
    In conclusion, don't specify a scheduler in methods producing Observable instances;
leave this choice to the callers of your methods. Alternatively, make your methods
receive a Scheduler instance as a parameter; like the Observable.interval method,
for example.
    The subscribeOn() operator is usable with Observable instances that block the caller
thread when one subscribes to them. Using the subscribeOn() method with such
sources lets the caller thread progress concurrently with the Observable instance logic.
     */
    @Test
    public void subscribeOn_002() {
        final CountDownLatch latch = new CountDownLatch(1);
        Observable<Integer> range = Observable
                .range(20, 4)
                .doOnEach(ConcurrencyTest.<Integer>debug("Source"))
                .subscribeOn(Schedulers.computation());

        Observable<Character> chars = range
                .map(new Func1<Integer, Character>() {
                    @Override
                    public Character call(Integer n) {
                        char c = (char)(n + 48);
                        return new Character(c);
                    }
                })
                .subscribeOn(Schedulers.io())
                .doOnEach(ConcurrencyTest.<Character>debug("Chars ", " "))
                .doAfterTerminate(new Action0() {
                    @Override
                    public void call() {
                        latch.countDown();
                    }
                });

        chars.subscribe();
        System.out.println("Hey!");
        try {
            /*
            与CountDownLatch的第一次交互是主线程等待其他线程。主线程必须在启动其他线程后立即调用CountDownLatch.await()方法。
            这样主线程的操作就会在这个方法上阻塞，直到其他线程完成各自的任务。
             */
            latch.await();
        } catch (Exception e) {

        }
    }

    /*
    The Observable<T> observeOn(Scheduler) operator
The observeOn() operator is similar to the subscribeOn() operator, but instead of
executing the entire chain on the passed Scheduler instances, it executes the part of the
chain from its place within it, onwards.
     */
    @Test
    public void observeOn_001() {
        final CountDownLatch latch = new CountDownLatch(1);
        Observable<Integer> range = Observable
                .range(20, 4)
                .doOnEach(ConcurrencyTest.<Integer>debug("Source"))
                ;

        Observable<Character> chars = range
                .map(new Func1<Integer, Character>() {
                    @Override
                    public Character call(Integer n) {
                        char c = (char)(n + 48);
                        return new Character(c);
                    }
                })
                /*
                Here, we tell the Observable chain to execute on the main thread after subscribing until
it reaches the observeOn() operator. At this point, it is moved on the computation
scheduler.
    As we can see, the part of the chain before the call to the operator blocks the main
thread, preventing printing Hey!. However, after all the notifications pass through the
observeOn() operator, 'Hey!' is printed and the execution continues on the
computation thread.
                 */
                .observeOn(Schedulers.computation())
                .doOnEach(ConcurrencyTest.<Character>debug("Chars ", " "))
                .doAfterTerminate(new Action0() {
                    @Override
                    public void call() {
                        latch.countDown();
                    }
                });

        chars.subscribe();
        System.out.println("Hey!");
        try {
            /*
            与CountDownLatch的第一次交互是主线程等待其他线程。主线程必须在启动其他线程后立即调用CountDownLatch.await()方法。
            这样主线程的操作就会在这个方法上阻塞，直到其他线程完成各自的任务。
             */
            latch.await();
        } catch (Exception e) {

        }
    }

    /*
    Of course, the observeOn() operator can be used together with the subscribeOn()
operator. That way, part of the chain could be executed on one thread and the rest of it
on another (in most cases). This is especially useful if you code a client-side
application because, normally, these applications run on one event enqueueing thread.
You can read from files/servers using the IO scheduler with
subscribeOn()/observeOn() operator and then observe the result on the event thread.
    using the observeOn() operator, we can change the threads multiple times; using
the subscribeOn() operator, we can do this one time—on subscription.
     */
    @Test
    public void observeOn_002() {
        final CountDownLatch latch = new CountDownLatch(1);
        Observable<Integer> range = Observable
                .range(20, 4)
                .doOnEach(ConcurrencyTest.<Integer>debug("Source"))
                .subscribeOn(Schedulers.newThread())
                ;

        Observable<Character> chars = range
                .observeOn(Schedulers.computation())
                .map(new Func1<Integer, Character>() {
                    @Override
                    public Character call(Integer n) {
                        char c = (char)(n + 48);
                        return new Character(c);
                    }
                })
                .doOnEach(ConcurrencyTest.<Character>debug("Chars ", " "))
                .observeOn(Schedulers.io())
                .map(new Func1<Character, Character>() {
                    @Override
                    public Character call(Character character) {
                        return new Character((char)(character.charValue()+1));
                    }
                })
                .doOnEach(ConcurrencyTest.<Character>debug("Chars 2", " "))
                .doAfterTerminate(new Action0() {
                    @Override
                    public void call() {
                        latch.countDown();
                    }
                });

        chars.subscribe();
        System.out.println("Hey!");
        try {
            latch.await();
        } catch (Exception e) {

        }
    }

    /*
    onTheSameWorker: an option to specify whether it should use the same Worker instance for every task, or spawn a new
one for every sub-task.
     */
    static void schedule(final Scheduler scheduler, final int numberOfSubTasks, final boolean onTheSameWorker) {
        final List<Integer> list    = new ArrayList<>(0);
        final AtomicInteger current = new AtomicInteger(0);
        final Random        random  = new Random();
        final Worker        worker  = scheduler.createWorker();
        final Action0       addWork = new Action0() {
            @Override
            public void call() {
                synchronized (current) {
                    System.out.println(" Add : " +
                                               Thread.currentThread().getName() + " " + current.get());
                    list.add(random.nextInt(current.get()));
                    System.out.println(" End add : " +
                                               Thread.currentThread().getName() + " " + current.get());
                }
            }
        };
        final Action0 removeWork = new Action0() {
            @Override
            public void call() {
                synchronized (current) {
                    if (!list.isEmpty()) {
                        System.out.println(" Remove : " +
                                                   Thread.currentThread().getName());
                        list.remove(0);
                        System.out.println(" End remove : " +
                                                   Thread.currentThread().getName());
                    }
                }
            }
        };
        Action0 work = new Action0() {
            @Override
            public void call() {
                System.out.println(Thread.currentThread().getName());
                for (int i = 1; i <= numberOfSubTasks; i++) {
                    current.set(i);
                    System.out.println("Begin add!");
                    if (onTheSameWorker) {
                        worker.schedule(addWork);
                    } else {
                        scheduler.createWorker().schedule(addWork);
                    }
                    System.out.println("End add!");
                }
                while (!list.isEmpty()) {
                    System.out.println("Begin remove!");
                    if (onTheSameWorker) {
                        worker.schedule(removeWork);
                    } else {
                        scheduler.createWorker().schedule(removeWork);
                    }
                    System.out.println("End remove!");
                }

                //worker.unsubscribe();
            }
        };

        worker.schedule(work);
    }

    /*
    A very important requirement here is that its workers need to be unsubscribed to avoid
leaking threads and OS resources. Note that it is expensive to create new threads each
time, so in most cases, the computation and the IO Scheduler instances should be
used.
     */

    static <T> Action1<Notification<? super T>> debug(String description) {
        return debug(description, "");
    }

    static <T> Action1<Notification<? super T>> debug(final String description, final String offset) {
        final AtomicReference<String> nextOffset = new AtomicReference<>(">");
        return new Action1<Notification<? super T>>() {
            @Override
            public void call(Notification<? super T> notification) {
                switch (notification.getKind()) {
                    case OnNext:
                        System.out.println(
                                Thread.currentThread().getName() +
                                        "|" + description + ": " + offset +
                                        nextOffset.get() + notification.getValue()
                                          );
                        break;
                    case OnError:
                        System.err.println(
                                Thread.currentThread().getName() +
                                        "|" + description + ": " + offset +
                                        nextOffset.get() + " X " + notification.getThrowable()
                                          );
                        break;
                    case OnCompleted:
                        System.out.println(
                                Thread.currentThread().getName() +
                                        "|" + description + ": " + offset +
                                        nextOffset.get() + "|"
                                          );
                    default:
                        break;
                }
                nextOffset.getAndSet("-" + nextOffset.get());
            }
        };
    }


}
