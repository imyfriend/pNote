package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.math.BigDecimal;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Observable.Transformer;
import rx.Subscriber;
import rx.Subscription;
import rx.observables.ConnectableObservable;
import rx.schedulers.Schedulers;

import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static java.util.concurrent.TimeUnit.SECONDS;
import static rx.Observable.defer;
import static rx.Observable.interval;

/**
 * Created by admin on 2017/7/24.
 */

public class RxJava_004 {

    @Test
    public void test_001() {
        ConnectableObservable<Long> upstream = interval(99, MILLISECONDS)
                .publish();

        subscribePrint(timedDebounce(upstream), "test_001");
        //subscribePrint(upstream, "upstream");
        upstream.connect();

        sleep(10, SECONDS);
    }

    @Test
    public void test_002() {
        Observable observable = Observable
                .interval(100, MILLISECONDS)
                .doOnNext(x -> log("doOnNext x=" + x))
                .take(1);
        subscribePrint(observable, "test_001");

        sleep(10, SECONDS);
    }

    @Test
    public void test_003() {
        Subscriber s;
        subscribePrint(timedDebounce(interval(99, MILLISECONDS)), "test_003");
        //subscribePrint(upstream, "upstream");
        //upstream.connect();

        sleep(10, SECONDS);

    }

    @Test
    public void test_004() {
        Observable<Long> observable = Observable.interval(1, TimeUnit.SECONDS);
        //使用publish操作符将普通Observable转换为可连接的Observable
        ConnectableObservable<Long> connectableObservable = observable.publish();

        //第一个订阅者订阅，不会开始发射数据
        connectableObservable.subscribe(new Subscriber<Long>() {
            @Override
            public void onCompleted() {
                System.out.println("1.onCompleted");
            }
            @Override
            public void onError(Throwable e) {
                System.out.println("1.onError");
            }
            @Override
            public void onNext(Long value) {
                System.out.println("1.onNext value :"+ value);
            }
        });

        //如果不调用connect方法，connectableObservable则不会发射数据
        connectableObservable.connect();
        //第二个订阅者延迟2s订阅，这将导致丢失前面2s内发射的数据
        connectableObservable
                .delaySubscription(2, TimeUnit.SECONDS)// 0、1数据丢失
                .subscribe(new Subscriber<Long>() {
                    @Override
                    public void onCompleted() {
                        System.out.println("2.onCompleted");
                    }
                    @Override
                    public void onError(Throwable e) {
                        System.out.println("2.onError");
                    }
                    @Override
                    public void onNext(Long value) {
                        System.out.println("2.onNext value :"+ value);
                    }
                });
        //eclipse下运行加上下面代码，Android Studio则不需要
        sleep(6, SECONDS);
    }

    @Test
    public void test_005() {
        Observable observable = interval(99, MILLISECONDS)
                .debounce(50, MILLISECONDS)
                .doOnNext(x -> log("doOnNext x=" + x))
                .doOnCompleted(() -> log("doOnCompleted"))
                .take(1);
        subscribePrint(observable, "test_005");
        sleep(6, SECONDS);
    }

    static void sleep(int timeout, TimeUnit unit) {
        try {
            unit.sleep(timeout);
        } catch (InterruptedException ignored) {
            //intentionally ignored
        }
    }

    private static void log(Object msg) {
        System.out.println(
                Thread.currentThread().getName() +
                        ": " + msg);
    }

    Observable<Long> timedDebounce(Observable<Long> upstream) {
        Observable<Long> onTimeout = upstream.take(1)
                .doOnNext(x -> log("take " + x))
                .doOnCompleted(() -> log("take doOnCompleted"))
                .concatWith(defer(() -> timedDebounce(upstream)));
        return upstream
                .debounce(100, MILLISECONDS, Schedulers.newThread())
                .doOnNext(x -> log("debounce doOnNext: " + x))
                //.doOnError(e -> log("debounce doOnError:" + e))
                //.doOnCompleted(() -> log("debounce doOnCompleted"))
                .timeout(1, SECONDS, onTimeout);
    }

    Observable<Long> timedDebounce2(Observable<Long> upstream) {
        Observable<Long> onTimeout = upstream.compose(new Transformer<Long, Long>() {
            @Override
            public Observable<Long> call(Observable<Long> longObservable) {
                return longObservable.take(1);
            }
        })
                .doOnNext(x -> log("take " + x))
                .doOnCompleted(() -> log("take doOnCompleted"))
                .concatWith(defer(() -> timedDebounce(upstream)));
        return upstream
                .debounce(100, MILLISECONDS, Schedulers.newThread())
                .doOnNext(x -> log("debounce doOnNext: " + x))
                //.doOnError(e -> log("debounce doOnError:" + e))
                //.doOnCompleted(() -> log("debounce doOnCompleted"))
                .timeout(1, SECONDS, onTimeout);
    }

    Observable<BigDecimal> pricesOf(String ticker) {
        return interval(50, MILLISECONDS)
                .flatMap(this::randomDelay)
                .map(this::randomStockPrice)
                .map(BigDecimal::valueOf);
    }
    Observable<Long> randomDelay(long x) {
        return Observable
                .just(x)
                .delay((long) (Math.random() * 100), MILLISECONDS);
    }
    double randomStockPrice(long x) {
        return 100 + Math.random() * 10 +
                (Math.sin(x / 100.0)) * 60.0;
    }

    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                                           + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }

}
