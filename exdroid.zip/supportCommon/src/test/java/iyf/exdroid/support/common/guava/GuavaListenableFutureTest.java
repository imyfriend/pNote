package iyf.exdroid.support.common.guava;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.FutureFallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import com.google.common.util.concurrent.RateLimiter;
import com.google.common.util.concurrent.SettableFuture;

import org.junit.Test;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * 类名称：GuavaListenableFutureTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/30
 * 修改者， 修改日期， 修改内容
 */
public class GuavaListenableFutureTest {
    // A Future object represents the result of an asynchronous operation.
    // To retrieve the result, we call future.get(), which may block if the task is not completed.

    // The ListenableFuture interface extends the Future interface by allowing us to register a callback to be
    // executed automatically once the submitted task is completed. We accomplish this by
    // calling the ListenableFuture.addListener method that takes a Runnable instance
    // and an ExecutorService object, which could be the same Executor instance the
    // original task was submitted to or another ExecutorService instance entirely.

    @Test
    public void ListenableFuture_get() {
        try {
            // the MoreExecutors class contains static methods for working
            // with Executor, ExecutorService and ThreadPool instances.
            ListeningExecutorService executorService = MoreExecutors.listeningDecorator(Executors.newCachedThreadPool());
            // ListenableFuture对Future进行了扩展，允许注册一个回调函数，task执行完后自动调用
            final ListenableFuture<Integer> listenableFuture = executorService.submit(new Callable<Integer>() {
                @Override
                public Integer call() throws Exception {
                    System.out.println("call execute.2.");
                    TimeUnit.SECONDS.sleep(1);
                    return 7;
                }
            });

            System.out.println("get: " + listenableFuture.get()); //7
        } catch (Exception e) {
            System.out.println("Exception: e" + e);
        }
    }

    @Test
    public void ListenableFuture_addListener() {
        try {
            final CountDownLatch    cdl             = new CountDownLatch(1);

            ListeningExecutorService executorService = MoreExecutors.listeningDecorator(Executors.newCachedThreadPool());
            // ListenableFuture对Future进行了扩展，允许注册一个回调函数，task执行完后自动调用
            final ListenableFuture<Integer> listenableFuture = executorService.submit(new Callable<Integer>() {
                @Override
                public Integer call() throws Exception {
                    System.out.println("call execute.2.");
                    return 7;
                }
            });

            listenableFuture.addListener(new Runnable() {
                @Override
                public void run() {
                    try {
                        System.out.println("1 get listenable future's result: " + listenableFuture.get());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }
                }
            }, MoreExecutors.sameThreadExecutor());

            listenableFuture.addListener(new Runnable() {
                @Override
                public void run() {
                    try {
                        System.out.println("2 get listenable future's result: " + listenableFuture.get());
                        cdl.countDown();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }
                }
            }, executorService);

            cdl.await();
        } catch (Exception e) {
            System.out.println("Exception: e" + e);
        }
    }

    // The FutureCallback interface specifies the onSuccess and onFailure methods.
    // The onSuccess method takes the result of the Future instance as an argument
    // so we have access to the result of our task.

    // Typically, we would not want to access the result
    // from the FutureCallback instance but would rather let FutureCallback handle the
    // result asynchronously on its own. If the FutureCallback instance you are providing
    // is going to perform any expensive operations, it's a good idea to use the following
    // signature for the Futures.addCallback method:
    //        Futures.addCallback(futureTask,callback,executorService);
    @Test
    public void ListenableFuture_addCallback() {
        try {
            ListeningExecutorService executorService = MoreExecutors.listeningDecorator(Executors.newCachedThreadPool());
            // ListenableFuture对Future进行了扩展，允许注册一个回调函数，task执行完后自动调用
            final ListenableFuture<Integer> listenableFuture = executorService.submit(new Callable<Integer>() {
                @Override
                public Integer call() throws Exception {
                    System.out.println("call execute.2.");
                    return 7;
                }
            });

            // The Futures class is a collection of static-utility methods for working with Future instances.

            // The thread that executed the initial ListenableFuture instance would execute the FutureCallback operation
            // behaving much like the ThreadPoolExecutor.CallerRunsPolicy executor service,
            // which states that the task will be run on the caller's thread.
            Futures.addCallback(listenableFuture, new FutureCallback<Integer>() {
                @Override
                public void onSuccess(Integer result) {
                    System.out.println("get listenable future's result with callback " + result);
                }

                @Override
                public void onFailure(Throwable t) {
                    t.printStackTrace();
                }
            });

        } catch (Exception e) {
            System.out.println("Exception: e" + e);
        }
    }

    @Test
    public void ListenableFuture_FutureFallback() {
        ListeningExecutorService executorService = MoreExecutors.listeningDecorator(Executors.newCachedThreadPool());
        // ListenableFuture对Future进行了扩展，允许注册一个回调函数，task执行完后自动调用
        final ListenableFuture<Integer> listenableFuture = executorService.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                System.out.println("call execute.");
                throw new NullPointerException("test");
            }
        });

        // The FutureFallback interface is used as a backup or a default value for a Future
        // instance that has failed. FutureFallback is an interface with one method,
        // create(Throwable t).
        ListenableFuture<Integer> faultTolerantFuture = Futures.withFallback(listenableFuture,
                new FutureFallback<Integer>() {

                    @Override
                    public ListenableFuture<Integer> create(Throwable t) throws Exception {
                        System.out.println("FutureFallback " + t);
                        // The SettableFuture class is a ListenableFuture interface that we can use
                        // to set the value to be returned, or we can set ListenableFuture to Fail with a
                        // given exception.
                        // if we wanted to set a value to be returned, we would call the set method and pass in an instance of
                        // the type expected to be returned by the Future instance. Or, if we wanted to set an
                        // exception that caused an error for this Future instance, we would pass in an instance
                        // of the appropriate exception.
                        SettableFuture<Integer> sf = SettableFuture.create();
                        sf.set(1);
                        return sf;
                    }
                });

        Futures.addCallback(faultTolerantFuture, new FutureCallback<Integer>() {
            @Override
            public void onSuccess(Integer result) {
                System.out.println("get listenable future's result with callback " + result);
            }

            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
            }
        });

    }

    // The RateLimiter class operates somewhat like a semaphore but instead of
    // restricting access by the number of concurrent threads, the RateLimiter class
    // restricts access by time, meaning how many threads can access a resource per
    // second.
    @Test
    public void RateLimiter_test00() {
        try {
            ListeningExecutorService executorService = MoreExecutors
                    .listeningDecorator(Executors.newCachedThreadPool());

            RateLimiter limiter = RateLimiter.create(5.0); // 每秒不超过4个任务被提交

            for (int i=0; i<10; i++) {
                limiter.acquire(); // 请求RateLimiter, 超过permits会被阻塞

                final ListenableFuture<Integer> listenableFuture = executorService
                        .submit(new Task("is " + i));
            }

            TimeUnit.SECONDS.sleep(2);

            for (int i=0; i<10; i++) {
                if (limiter.tryAcquire()) {
                    executorService.submit(new Task("in tryAcquire, is " + i));
                } else {
                    System.out.println("tryAcquire, is " + i);
                }
            }

        } catch (Exception e) {
            System.out.println("Exception: e" + e);
        }
    }

    class Task implements Callable<Integer> {
        String str;

        public Task(String str) {
            this.str = str;
        }

        @Override
        public Integer call() throws Exception {
            System.out.println("call execute.." + str);
            TimeUnit.SECONDS.sleep(1);
            return 7;
        }
    }

}
