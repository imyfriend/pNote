package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.schedulers.TimeInterval;
import rx.schedulers.Timestamped;

/**
 * Created by imyfriend on 2017/5/14.
 */

public class TransformationOtherTest {

    /*
    cast() operator, which is a shortcut for the map(v -> someClass.cast(v))
     */
    @Test
    public void cast() {
        List<Number> list = Arrays.<Number>asList(1, 2, 3);
        Observable<Integer> iObs = Observable
                .from(list)
                .cast(Integer.class);
        subscribePrint(iObs, "iObs");
    }

    /*
    Another helpful operator is the timestamp() operator. It adds a timestamp to each
emitted value by transforming it into an instance of the Timestamped<T> class.
     */
    @Test
    public void timestamp() {
        List<Number> list = Arrays.<Number>asList(3, 2);
        Observable<Timestamped<Number>> timestamp = Observable
                .from(list)
                .timestamp();
        subscribePrint(timestamp, "Timestamps");
    }

    /*
    A similar operator is the timeInterval operator, but it transforms a value to an
instance of the TimeInterval<T> operator instead. A TimeInterval<T> instance
represents an item emitted by an Observable along with the amount of time that elapsed
either since the emission of the previous item, or (if there was no previous item) since
the subscription.
     */
    @Test
    public void timeInterval() {
        Observable<TimeInterval<Long>> timeInterval = Observable
                .interval(0L, 150L, TimeUnit.MILLISECONDS)
                .timeInterval();
        subscribePrint(timeInterval, "Time intervals");
        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                        + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }
}
