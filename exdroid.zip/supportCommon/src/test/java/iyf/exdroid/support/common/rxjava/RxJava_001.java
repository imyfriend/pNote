package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.functions.Action1;
import rx.schedulers.Schedulers;
import rx.subscriptions.Subscriptions;

import static java.util.concurrent.TimeUnit.SECONDS;

/**
 * Created by admin on 2017/7/10.
 */

public class RxJava_001 {

    @Test
    public void test_001() {
        Observable<String> a = Observable.create(s -> {
            new Thread(() -> {
                s.onNext("one");
                Utils.sleep(2, TimeUnit.SECONDS);
                s.onNext("two");
                s.onCompleted();
            }).start();
        });
        Observable<String> b = Observable.create(s -> {
            new Thread(() -> {
                s.onNext("three");
                s.onNext("four");
                s.onCompleted();
            }).start();
        });
        Observable<String> c = Observable.merge(a, b);
        c.subscribe(new Action1<String>() {
            @Override
            public void call(String s) {
                System.err.println("" + s);
            }
        });

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void test_concat_0011() {
        Observable<String> a = Observable.create(s -> {
            new Thread(() -> {
                s.onNext("one");
                Utils.sleep(2, TimeUnit.SECONDS);
                s.onNext("two");
                s.onCompleted();
            }).start();
        });
        Observable<String> b = Observable.create(s -> {
            new Thread(() -> {
                s.onNext("three");
                s.onNext("four");
                s.onCompleted();
            }).start();
        });
        Observable<String> c = Observable.concat(a, b);
        c.subscribe(new Action1<String>() {
            @Override
            public void call(String s) {
                System.err.println("" + s);
            }
        });

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void test_002() {
        Observable<Integer> ints =
                Observable.create(subscriber -> {
                                      log("Create");
                                      subscriber.onNext(42);
                                      subscriber.onCompleted();
                                  }
                                 );
        log("Starting");
        ints.subscribe(i -> log("Element A: " + i));
        ints.subscribe(i -> log("Element B: " + i));
        log("Exit");
    }

    @Test
    public void test_003() {
        Observable<Integer> ints =
                Observable.<Integer>create(subscriber -> {
                                      log("Create");
                                      subscriber.onNext(42);
                                      subscriber.onCompleted();
                                  }
                                 ).cache();
        log("Starting");
        ints.subscribe(i -> log("Element A: " + i));
        ints.subscribe(i -> log("Element B: " + i));
        log("Exit");
    }

    @Test
    public void test_004() {
        Subscriber<Integer> subscriber = new Subscriber<Integer>() {
            @Override
            public void onCompleted() {
                log("onCompleted");
            }

            @Override
            public void onError(Throwable e) {
                log("onError " + e.getMessage());
            }

            @Override
            public void onNext(Integer integer) {
                log("onNext: integer=" + integer);
            }
        };
        delayed(5).subscribe(subscriber);
        subscriber.unsubscribe();
    }

    @Test
    public void test_005() {
        Observable.fromCallable(() -> 5).subscribe(it -> log(it));
    }

    @Test
    public void test_006() {
        Observable.timer(1, TimeUnit.SECONDS)
                .subscribe((Long zero) -> log(zero));

        sleep(5, TimeUnit.SECONDS);
    }

    @Test
    public void test_007() {
        Observable.just(getValue())
                .observeOn(Schedulers.io())
                .subscribe();

        Utils.sleep(10, TimeUnit.SECONDS);
    }

    @Test
    public void test_list_001() {
        Observable.fromCallable(() -> {
            List<String> strings = new ArrayList<>();
            strings.add("1");
            strings.add("2");
            strings.add("3");
            return strings;
        })
                .flatMap(strings -> Observable.from(strings))
                .subscribe(string -> log(string));
    }

    @Test
    public void test_list_002() {
        List<String> strings = new ArrayList<>();
        strings.add("1");
        strings.add("2");
        strings.add("3");

    }

    @Test
    public void test_list_003() {
        List<String> strings = null;

        Observable.from(strings)
                .subscribe(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        log(s);
                    }
                });
    }

    @Test
    public void test_008() {
        Observable<String> observable1 = Observable.just("observable1-1", "observable1-2", "observable1-3");

        Observable<String> observable2 = Observable.fromCallable(() -> {
                    Utils.sleep(2, TimeUnit.SECONDS);
                    return "observable2";
                })
                .observeOn(Schedulers.io());

        Observable<String> observable3 = Observable.interval(100, TimeUnit.MILLISECONDS)
                .take(50)
                .map(i -> "observable3-" + i);

        Subscriber<String> subscriber = new Subscriber<String>() {
            @Override
            public void onCompleted() {
                System.out.println("subscriber onCompleted");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("subscriber onError");
            }

            @Override
            public void onNext(String s) {
                System.out.println("subscriber onNext s=" + s + ", thread=" + Thread.currentThread().getName());
            }
        };

        /*observable1.subscribe(subscriber);
        observable2.subscribe(subscriber);
        observable3.subscribe(subscriber);*/
        Observable.merge(observable2, observable1, observable3).subscribe(subscriber);

        Utils.sleep(60, TimeUnit.SECONDS);
    }

    @Test
    public void test_009() {
        List<String> stringList = new ArrayList<>();
        stringList.add("1");
        stringList.add("2");
        Observable observable = Observable.from(stringList)
            .flatMap(string -> {
                List<String> strings = new ArrayList<>();
                strings.add(string + "-1");
                strings.add(string + "-2");
                return Observable.from(strings);
            });
        observable.subscribe(string -> log(string));
    }

    @Test
    public void test_010() {
        List<Integer> integerList = new ArrayList<>();
        for (int i=0; i<100; i++) {
            integerList.add(i);
        }

        Subscriber<String> subscriber = new Subscriber<String>() {
            @Override
            public void onCompleted() {
                log("onCompleted");
            }

            @Override
            public void onError(Throwable e) {
                log("onError e=" + e);
            }

            @Override
            public void onNext(String s) {
                log("onNext s=" + s);
            }
        };

        Observable.from(integerList)
                .filter(integer -> 1 > integer)
                .map(integer -> "value=" + integer)
                .subscribe(subscriber);
    }

    static <T> Observable<T> delayed(T x) {
        return Observable.create(
                subscriber -> {
                    Runnable r = () -> {
                        sleep(10, SECONDS);
                        if (!subscriber.isUnsubscribed()) {
                            subscriber.onNext(x);
                            subscriber.onCompleted();
                        }
                    };
                    final Thread thread = new Thread(r);
                    thread.start();
                    subscriber.add(Subscriptions.create(thread::interrupt));
                });
    }
    static void sleep(int timeout, TimeUnit unit) {
        try {
            unit.sleep(timeout);
        } catch (InterruptedException ignored) {
            //intentionally ignored
        }
    }

    private static void log(Object msg) {
        System.out.println(
                Thread.currentThread().getName() +
                        ": " + msg);
    }

    private int getValue() {
        Utils.findCaller();
        return 1;
    }

}
