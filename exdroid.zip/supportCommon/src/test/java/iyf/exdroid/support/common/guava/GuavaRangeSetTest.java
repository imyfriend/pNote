package iyf.exdroid.support.common.guava;

import com.google.common.collect.Range;
import com.google.common.collect.RangeSet;
import com.google.common.collect.TreeRangeSet;

import org.junit.Test;

/**
 * 类名称：GuavaRangeSetTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/30
 * 修改者， 修改日期， 修改内容
 */
public class GuavaRangeSetTest {
    /**
     * RangeSet用来处理一系列不连续，非空的range。
     * 当添加一个range到一个RangeSet之后，任何有连续的range将被自动合并，而空的range将被自动去除
     */
    @Test
    public void RangeSet_test() {
        RangeSet<Integer> rangeSet = TreeRangeSet.create();
        rangeSet.add(Range.closed(1, 10));
        System.out.println(rangeSet); // [[1‥10]]
        rangeSet.add(Range.openClosed(11, 15)); // [[1‥10], (11‥15]]
        System.out.println(rangeSet);
        rangeSet.add(Range.closedOpen(18, 20)); // [[1‥10], (11‥15], [18‥20)]
        System.out.println(rangeSet);
        rangeSet.add(Range.open(13, 21)); // [[1‥10], (11‥21)]
        System.out.println(rangeSet);
    }
}
