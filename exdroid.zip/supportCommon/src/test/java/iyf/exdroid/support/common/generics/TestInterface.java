package iyf.exdroid.support.common.generics;

import org.junit.Test;

public class TestInterface {
    @Test
    public void test01() {
        Impl impl = new Impl();
        impl.join("Test");
        impl.join(1);
    }

    static interface IParent {
        <T> void join(T group);
    }

    static interface IChildren extends IParent {
        // 和IParent的join不同
        default <T extends String> void join(T group) {
            System.out.println("default <T extends String> void join group=" + group);
        }
    }

    static class Impl implements IChildren {
        @Override
        public <T> void join(T group) {
            System.out.println("public <T> void join group=" + group);
        }
    }

}
