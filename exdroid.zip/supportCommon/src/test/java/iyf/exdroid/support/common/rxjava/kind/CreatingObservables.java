package iyf.exdroid.support.common.rxjava.kind;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import iyf.exdroid.support.common.rxjava.TestSubscriberEx;
import iyf.exdroid.support.common.rxjava.Utils;
import rx.Observable;
import rx.Observable.Operator;
import rx.Observable.Transformer;
import rx.Subscriber;
import rx.observers.TestSubscriber;
import rx.schedulers.Timestamped;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

/**
 * Created by admin on 2017/7/27.
 */

public class CreatingObservables {

    @Test
    public void create_001() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();

        /*
        从头开始创建一个Observable，给这个操作符传递一个接受观察者作为参数的函数，
        编写这个函数让它的行为表现为一个Observable--恰当的调用观察者的onNext，onError和onCompleted方法。
         */
        Observable observable = Observable.create(new Observable.OnSubscribe<Integer>() {
            @Override
            public void call(Subscriber<? super Integer> observer) {
                if (observer.isUnsubscribed()) {
                    return;
                }

                try {
                    for (int i = 1; i < 5; i++) {
                        observer.onNext(i);
                    }
                } catch (Exception e) {
                    observer.onError(e);
                    return;
                }

                if (observer.isUnsubscribed()) {
                    return;
                }

                observer.onCompleted();
            }
        });

        observable.subscribe(subscriber);
    }

    @Test
    public void create_002() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Utils.log("isUnsubscribed: " + subscriber.isUnsubscribed());

        Observable.create((Subscriber<? super Integer> observer) -> {
            try {
                Utils.onSafeNext(observer,1);
                Utils.onSafeCompleted(observer);
            } catch (Exception e) {
                Utils.onSafeError(observer, e);
            }
        }).subscribe(subscriber);

        subscriber.assertCompleted();
    }

    @Test
    public void defer_001() {
        /*
        直到有观察者订阅时才创建Observable，并且为每个观察者创建一个新的Observable
         */
        TestSubscriberEx<Integer> subscriber1 = new TestSubscriberEx<>();
        TestSubscriberEx<Integer> subscriber2 = new TestSubscriberEx<>();

        Observable observable = Observable.just(1, 2, 3, 4, 5, 6);
        Observable observable2 = observable.defer(() -> observable);
        observable2.subscribe(subscriber1);
        observable2.subscribe(subscriber2);
    }

    private List<Integer> list;
    @Test
    public void defer_002() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        list = Arrays.asList(1, 2, 3, 4, 5, 6);
        Observable observable = Observable.from(list);
        list = Arrays.asList(11, 22, 33, 44, 55, 66);
        observable.subscribe(subscriber);

        subscriber = new TestSubscriberEx<>();
        Observable observable2 = observable.defer(() -> Observable.from(list)); // 保证数据是最新的
        observable2.subscribe(subscriber);
    }

    @Test
    public void empty_001() {
        /*
        This one emits no items, but it emits a OnCompleted notification immediately.
         */
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.<Integer>empty().subscribe(subscriber);

        subscriber.assertCompleted();

        /*
        The Observable.never() does nothing. It sends no notifications to its Observer instances,
        and even the OnCompleted notification is not sent.
         */
        //Observable.never();
    }

    @Test
    public void error_001() {
        /*
        This emits just the error passed to it as an OnError notification.
        This is similar to the 'throw' keyword in the classical, imperative Java world.
         */
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.<Integer>error(new Throwable()).subscribe(subscriber);

        subscriber.assertError(Throwable.class);
    }

    @Test
    public void from_001() {
        /*
        from操作符可以转换Future、Iterable和数组。对于Iterable和数组，
        产生的Observable会发射Iterable或数组的每一项数据。
         */
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] items = { 0, 1, 2, 3, 4, 5 };
        Observable myObservable = Observable.from(items);
        myObservable.subscribe(subscriber);
    }

    @Test
    public void interval_001() {
        /*
        interval返回一个Observable，它按固定的时间间隔发射一个无限递增的整数序列(从0开始).
        It can be used to implement periodic polling, or continuous status
        logging, by just ignoring the number emitted and emitting useful messages.
         */
        TestSubscriberEx<Timestamped<Long>> subscriber = new TestSubscriberEx<>();
        Observable.interval(10, 20, TimeUnit.MILLISECONDS).timestamp().take(10).subscribe(subscriber);
        subscriber.awaitTerminalEvent();
    }

    @Test
    public void interval_002() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.just(11).interval(10, TimeUnit.MILLISECONDS).take(3).subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(3);
        List<Long> expected = Arrays.asList(0L, 1L, 2L);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void just_001() {
        /*
        Just类似于From，但是From会将数组或Iterable的数据取出然后逐个发射，
        而Just只是简单的原样发射，将数组或Iterable当做单个数据。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3,4).subscribe(subscriber);
        subscriber.assertCompleted();
        subscriber.assertValueCount(4);
        List<Integer> expected = Arrays.asList(1,2,3,4);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));

        subscriber = new TestSubscriberEx<>();
        Observable.just(Arrays.asList(1, 2, 3, 4)).subscribe(subscriber);
    }

    @Test
    public void range_001() {
        /*
        Range操作符发射一个范围内的有序整数序列，你可以指定范围的起始和长度.
        This method sends sequential numbers beginning with the first parameter passed.
        The second parameter is the number of the emissions.
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.range(2, 4).subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertValueCount(4);
        List<Integer> expected = Arrays.asList(2,3,4,5);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void repeat_001() {
        /*
        repeat方法。它不是创建一个Observable，而是重复发射原始Observable的数据序列，
        这个序列或者是无限的，或者通过repeat(n)指定重复次数
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3,4).repeat(2).subscribe(subscriber);
    }

    @Test
    public void repeatWhen_002() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.range(1, 5).repeatWhen(x -> x.timer(1, TimeUnit.SECONDS)).subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(10);
    }

    @Test
    public void timer_001() {
        /*
        timer返回一个Observable，它在延迟一段给定的时间后发射一个简单的数字0L。
         */
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Observable.just(11).timer(1,TimeUnit.SECONDS).subscribe(subscriber);

        subscriber.awaitTerminalEvent();

        subscriber.assertCompleted();
        subscriber.assertValueCount(1);
        List<Long> expected = Arrays.asList(0L);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void using_001() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();

        Observable observable = Observable.using(() -> new ClosableObject(),
                         (ClosableObject co) -> Observable.just(co.getValue()),
                         (ClosableObject co) -> co.close());

        observable.subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
    }

    static class ClosableObject {
        public ClosableObject() {
            Utils.log("ClosableObject");
        }

        public void close() {
            Utils.log("close");
        }

        public int getValue() {
            return 1;
        }
    }

    @Test
    public void testGeneratesSequentialIndexes() {
        Observable<Pair<Long, String>> observable = Observable
                .just("a", "b", "c", "d", "e")
                .lift(new Indexed<>());
        List<Pair<Long, String>> expected = Arrays.asList(
                new Pair<>(0L, "a"),
                new Pair<>(1L, "b"),
                new Pair<>(2L, "c"),
                new Pair<>(3L, "d"),
                new Pair<>(4L, "e"));

        List<Pair<Long, String>> actual = observable
                .toList()
                .toBlocking()
                .single();
        assertEquals(expected, actual);
        // Assert that it is the same result for a second subscribtion.
        TestSubscriber<Pair<Long, String>> testSubscriber = new TestSubscriberEx<>();
        observable.subscribe(testSubscriber);
        testSubscriber.assertReceivedOnNext(expected);
    }

    @Test
    public void testFiltersOddOfTheSequence() {
        Observable<String> tested = Observable
                .just("One", "Two", "Three", "Four", "Five", "June", "July")
                .compose(new OddFilter<>());
        List<String> expected =
                Arrays.asList("One", "Three", "Five", "July");
        List<String> actual = tested
                .toList()
                .toBlocking()
                .single();
        assertEquals(expected, actual);

        TestSubscriber<String> testSubscriber = new TestSubscriberEx<>();
        tested.subscribe(testSubscriber);
        testSubscriber.assertReceivedOnNext(expected);
    }

    public static class Pair<L, R> {
        final L left;
        final R right;
        public Pair(L left, R right) {
            this.left = left;
            this.right = right;
        }
        public L getLeft() {
            return left;
        }
        public R getRight() {
            return right;
        }

        @Override
        public String toString() {
            return String.format("%s : %s", this.left, this.right);
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((left == null) ? 0 : left.hashCode());
            result = prime * result + ((right == null) ? 0 : right.hashCode());
            return result;
        }

        @SuppressWarnings("rawtypes")
        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (!(obj instanceof Pair)) {
                return false;
            }
            Pair other = (Pair) obj;
            if (left == null) {
                if (other.left != null) {
                    return false;
                }
            } else if (!left.equals(other.left)) {
                return false;
            }
            if (right == null) {
                if (other.right != null) {
                    return false;
                }
            } else if (!right.equals(other.right)) {
                return false;
            }
            return true;
        }
    }

    public static class Indexed<T> implements Operator<Pair<Long, T>, T> {
        private final long initialIndex;

        public Indexed() {
            this(0L);
        }

        public Indexed(long initial) {
            this. initialIndex = initial;
        }

        @Override
        public Subscriber<? super T> call(Subscriber<? super Pair<Long, T>> s) {
            return new Subscriber<T>(s) {
                private long index = initialIndex;

                @Override
                public void onCompleted() {
                    s.onCompleted();
                }

                @Override
                public void onError(Throwable e) {
                    s.onError(e);
                }

                @Override
                public void onNext(T t) {
                    s.onNext(new Pair<>(index++, t));
                }
            };
        }
    }

    public static class OddFilter<T> implements Transformer<T, T> {
        @Override
        public Observable<T> call(Observable<T> observable) {
            return observable
                    .lift(new Indexed<T>(1L))
                    .filter(pair -> pair.getLeft() % 2 == 1)
                    .map(pair -> pair.getRight());
        }
    }


}
