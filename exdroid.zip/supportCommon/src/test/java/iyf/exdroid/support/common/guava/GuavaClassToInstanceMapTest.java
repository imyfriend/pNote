package iyf.exdroid.support.common.guava;

import com.google.common.collect.ImmutableClassToInstanceMap;
import com.google.common.collect.MutableClassToInstanceMap;

import org.junit.Test;

/**
 * 类名称：GuavaClassToInstanceMapTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/28
 * 修改者， 修改日期， 修改内容
 */
// ClassToInstanceMap<B>实现了Map<Class<? extends B>, B> -- 换句话说, 他是一个由B的子类和B的实例构成的Map.
// ClassToInstanceMap提供了一种是用Class作为Key, 对应实例作为Value的途径
// http://www.cnblogs.com/zemliu/p/3335982.html
public class GuavaClassToInstanceMapTest {
    @Test
    public void MutableClassToInstanceMap_test() {
        // 一般来说,使用ClassToInstanceMap应该调用getInstance和putInstance, 而不是get()和put()
        MutableClassToInstanceMap<Number> map = MutableClassToInstanceMap.create();
        map.putInstance(Integer.class, 100);
        map.putInstance(Integer.class, 80);

        map.putInstance(Float.class, 10.01f);
        System.out.println(map.getInstance(Integer.class)); // 80
        System.out.println(map.getInstance(Float.class)); // 10.01
    }

    @Test
    public void ImmutableClassToInstanceMap_test() {
        ImmutableClassToInstanceMap<Number> map =
                new ImmutableClassToInstanceMap.Builder<Number>()
                        .put(Integer.class, 100)
                        .put(Float.class, 10.01f)
                        .build();
        ImmutableClassToInstanceMap<Number> map2 = ImmutableClassToInstanceMap.copyOf(map);
        // 在构造完成后在调用put()或者putInstance()会抛出UnsupportedOperationException
        // throws UnsupportedOperationException
        // map.putInstance(Integer.class, 1000);
        // map.put(Integer.class, 1000);
        System.out.println(map.getInstance(Integer.class)); // 100
        System.out.println(map2.getInstance(Float.class)); // 10.01
    }

}
