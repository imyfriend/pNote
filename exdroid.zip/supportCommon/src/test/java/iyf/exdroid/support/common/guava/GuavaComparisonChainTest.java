package iyf.exdroid.support.common.guava;

import com.google.common.collect.ComparisonChain;

import org.junit.Test;

/**
 * 类名称：GuavaComparisonChainTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/27
 * 修改者， 修改日期， 修改内容
 */
public class GuavaComparisonChainTest {
    @Test
    public void ComparisonChain_start() {
        int result = ComparisonChain.start() //链式比较,在第一个非0处返回
                .compare("title", "Title")
                .compare(5, 5)
                .result();
        System.out.println("result=" + result); //1
    }
}
