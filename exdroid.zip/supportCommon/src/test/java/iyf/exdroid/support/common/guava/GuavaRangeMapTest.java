package iyf.exdroid.support.common.guava;

import com.google.common.collect.Range;
import com.google.common.collect.RangeMap;
import com.google.common.collect.TreeRangeMap;

import org.junit.Test;

/**
 * 类名称：GuavaRangeMapTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/30
 * 修改者， 修改日期， 修改内容
 */
public class GuavaRangeMapTest {
    /**
     * RangeMap代表了非连续非空的range对应的集合。
     * 不像RangeSet，RangeMap不会合并相邻的映射，甚至相邻的range对应的是相同的值
     */
    @Test
    public void RangeMap_test() {
        RangeMap<Integer, String> rangeMap = TreeRangeMap.create();
        rangeMap.put(Range.closed(1, 10), "foo");
        System.out.println("rangeMap:"+rangeMap); // rangeMap:[[1‥10]=foo]
        rangeMap.put(Range.open(3, 6), "bar");
        System.out.println("rangeMap:"+rangeMap); // rangeMap:[[1‥3]=foo, (3‥6)=bar, [6‥10]=foo]
        rangeMap.put(Range.open(10, 20), "foo");
        System.out.println("rangeMap:"+rangeMap); // rangeMap:[[1‥3]=foo, (3‥6)=bar, [6‥10]=foo, (10‥20)=foo]
        rangeMap.remove(Range.closed(5, 11));
        System.out.println("rangeMap:"+rangeMap); // rangeMap:[[1‥3]=foo, (3‥5)=bar, (11‥20)=foo]
    }
}
