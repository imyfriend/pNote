package iyf.exdroid.support.common.guava;

import com.google.common.base.Charsets;
import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.io.ByteSink;
import com.google.common.io.ByteSource;
import com.google.common.io.Closer;
import com.google.common.io.Files;
import com.google.common.io.LineProcessor;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Created by ii on 2017/3/27.
 */

public class GuavaFilesTest {
    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    private File output = null;

    @Before
    public void setup() {
        try {
            output = temporaryFolder.newFile("output.txt");
            // 向文件写入内容(输出流)
            String str = "亲爱的小南瓜！\n";
            String str1 = "\"Savage, Tom\",Being A Great Cook,Acme Publishers,ISBN-" + "123456,29.99,1\n";
            String str2 = "\"Smith, Jeff\",Art is Fun,Acme Publishers,ISBN-456789,19.99,2\n";
            String str3 = "\"Vandeley, Art\",Be an Architect,Acme Publishers,ISBN-" + "234567,49.99,3\n";
            String str4 = "\"Jones, Fred\",History of Football,Acme Publishers,ISBN-" + "345678,24.99,4\n";
            String str5 = "\"Timpton, Patty\",Gardening My Way,Acme Publishers,ISBN-" + "4567891,34.99,5\n";
            ArrayList<String> arrayList = new ArrayList<>();
           // arrayList.add(str);
            arrayList.add(str1);
            arrayList.add(str2);
            arrayList.add(str3);
            arrayList.add(str4);
            arrayList.add(str5);

            byte[] bt;

            try {
                FileOutputStream in = new FileOutputStream(output);
                try {
                    for (String string : arrayList) {
                        bt = string.getBytes();
                        in.write(bt, 0, bt.length);
                        // boolean success=true;
                        // System.out.println("写入文件成功");
                    }
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        } catch (Exception e) {

        }
    }

    @Test
    public void Files_test01() {
        try {
            File copy = new File(temporaryFolder.getRoot() + "/copy.txt");
            Files.copy(output, copy);
            List<String> readLines = Files.readLines(copy, Charsets.UTF_8);
            if (null != readLines) {
                for (String line : readLines) {
                    System.out.println("line: " + line);
                }
            }
        } catch (Exception e) {

        }
    }

    @Test
    public void Files_test02() {
        try {
            List<String> readLines = Files.readLines(output, Charsets.UTF_8, new ToListLineProcessor());
            if (null != readLines) {
                for (String line : readLines) {
                    System.out.println("line: " + line);
                }
            }
        } catch (Exception e) {

        }
    }

    public static class ToListLineProcessor implements LineProcessor<List<String>> {
        private static final Splitter     splitter    = Splitter.on(",");
        private              List<String> bookTitles  = Lists.newArrayList();
        private static final int          TITLE_INDEX = 2;

        @Override
        public List<String> getResult() {
            return bookTitles;
        }

        @Override
        public boolean processLine(String line) throws IOException {
            bookTitles.add(Iterables.get(splitter.split(line), TITLE_INDEX));
            return true;
        }
    }

    @Test
    public void Files_test03() {
        try {
            String hamletQuoteStart = "To be, or not to be";
            Files.write(hamletQuoteStart, output, Charsets.UTF_8);
            System.out.println(Files.toString(output, Charsets.UTF_8));

            String hamletQuoteEnd = ",that is the question";
            Files.append(hamletQuoteEnd, output, Charsets.UTF_8);
            System.out.println(Files.toString(output, Charsets.UTF_8));

            String overwrite = "Overwriting the file";
            Files.write(overwrite, output, Charsets.UTF_8);
            System.out.println(Files.toString(output, Charsets.UTF_8));

        } catch (Exception e) {

        }
    }

    @Test
    public void Files_test04() {
        try {
            ByteSource byteSource = Files.asByteSource(output);
            byte[]     readBytes  = byteSource.read();
            assertThat(readBytes,is(Files.toByteArray(output)));
        } catch (Exception e) {

        }
    }

    @Test
    public void Files_test05() {
        try {
            File     dest     = new File(temporaryFolder.getRoot() + "/dest.txt");
            dest.deleteOnExit();
            ByteSink byteSink = Files.asByteSink(dest);
            byteSink.write(Files.toByteArray(output));
            assertThat(Files.toByteArray(dest), is(Files.toByteArray(output)));
        } catch (Exception e) {

        }
    }

    /*
    The Closer class in Guava is used to ensure that all the registered Closeable
    objects are properly closed when the Closer.close method is called. The Closer
    class emulates the behavior found with Java 7's try-with-resources idiom, but can
    be used in a Java 6 environment.
     */
    /*
    try
    catch
    finally
    Files_test06 catch
     */
    @Test
    public void Files_test06() {
        try {
            func();
        } catch (Exception e) {
            System.out.println("Files_test06 catch");
        }
    }

    private void func() throws IOException {
        Closer closer = Closer.create();
        try {
            ByteSource byteSource = Files.asByteSource(output);
            closer.register(byteSource.openStream());
            System.out.println("try");
            String str = null;
            str.charAt(1);
        } catch (Exception e) {
            System.out.println("catch");
            throw closer.rethrow(e);
        } finally {
            System.out.println("finally");
            closer.close();
        }
    }



}
