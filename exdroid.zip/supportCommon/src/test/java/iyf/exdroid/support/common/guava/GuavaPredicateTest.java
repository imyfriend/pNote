package iyf.exdroid.support.common.guava;

import com.google.common.base.Function;
import com.google.common.base.Functions;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;

import org.junit.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 类名称：GuavaPredicateTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/2/10
 * 修改者， 修改日期， 修改内容
 */
public class GuavaPredicateTest {
    // the Predicate(断言，断定) interface is used to filter objects.

    public class PopulationPredicate implements Predicate<City> {
        @Override
        public boolean apply(City input) {
            return input.getPopulation() <= 500000;
        }
    }

    public class NamePredicate implements Predicate<City> {
        @Override
        public boolean apply(City input) {
            return input.getName().equals("DaLian");
        }
    }

    @Test
    public void Predicates_and() {
        City city = new City("DaLian", "116023", 500000);
        Predicate predicate = Predicates.and(new PopulationPredicate(), new NamePredicate());
        System.out.println(predicate.apply(city)); //true

        city.setPopulation(600000);
        System.out.println(predicate.apply(city)); //false
    }

    // The Predicates.not method takes a Predicate object and performs a logical
    // negation of the component Predicate.
    @Test
    public void Predicates_not() {
        City city = new City("DaLian", "116023", 600000);
        Predicate predicate = Predicates.not(new PopulationPredicate());
        System.out.println(predicate.apply(city)); //true
    }

    // The Predicates.compose method takes Function and Predicate as arguments
    // and evaluates the given Predicate instance on the output returned from Function.
    @Test
    public void Predicates_compose() {
        Map<String, City> states = new HashMap<>();
        states.put("ShenYang", new City("ShenYang", "110000", 1300));
        states.put("DaLian", new City("DaLian", "116023", 1300));

        Function<String, City> lookup = Functions.forMap(states);

        Predicate<String> predicate = Predicates.compose(new PopulationPredicate(), lookup);
        System.out.println(predicate.apply("DaLian")); //true
    }


    /**
     * 州类
     */
    public class State {
        private String name;
        private String code;
        public Set<City> mainCities = new HashSet<City>();

        State(String name, String code) {
            this.name = name;
            this.code = code;
        }
    }

    /**城市类**/
    public class City {
        City(String name, String zipCode, int population) {
            this.name = name;
            this.zipCode = zipCode;
            this.population = population;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getZipCode() {
            return zipCode;
        }

        public void setZipCode(String zipCode) {
            this.zipCode = zipCode;
        }

        public int getPopulation() {
            return population;
        }

        public void setPopulation(int population) {
            this.population = population;
        }

        private String name;
        private String zipCode;
        private int population;

        @Override
        public String toString() {
            return name;
        }
    }

}
