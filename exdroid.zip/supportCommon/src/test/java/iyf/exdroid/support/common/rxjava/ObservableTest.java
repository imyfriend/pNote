package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Action1;
import rx.functions.Func1;

/**
 * Created by imyfriend on 2017/4/29.
 */

public class ObservableTest {
    @Test
    public void subscribe_list() {
        List<String> list = Arrays.asList(
                "blue", "red", "green", "yellow", "orange", "cyan", "purple"
        );
        Observable<String> listObservable = Observable.from(list).doOnNext(s -> System.out.println(s));
        listObservable.subscribe(new Action1<String>() {
            @Override
            public void call(String s) {
                System.out.println(s);
            }
        });
    }

    @Test
    public void subscribe_array() {
        Observable<Integer> arrayObservable = Observable.from(new Integer[] {
                3, 5, 8 });
        arrayObservable.subscribe(new Action1<Integer>() {
            @Override
            public void call(Integer integer) {
                System.out.println(integer);
            }
        });
    }

    @Test
    public void just_001() {
        Observable
                .just('R', 'x', 'J', 'a', 'v', 'a')
                .subscribe(new Action1<Character>() {
                    @Override
                    public void call(Character character) {
                        System.out.println(character);
                    }
                });
    }

    static class User {
        private final String forename;
        private final String lastname;
        public User(String forename, String lastname) {
            this.forename = forename;
            this.lastname = lastname;
        }
        public String getForename() {
            return this.forename;
        }
        public String getLastname() {
            return this.lastname;
        }
    }

    @Test
    public void just_user() {
        Observable
                .just(new User("Dali", "Bali"))
                .map(new Func1<User, String>() {
                    @Override
                    public String call(User user) {
                        return user.getForename() + " " + user.getLastname();
                    }
                })
                .subscribe(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        System.out.println(s);
                    }
                });
    }

    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                        + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }

    @Test
    public void subscribeIntervalObservable() {
        subscribePrint(
                // it's running on a computation thread by default
                Observable.interval(500L, TimeUnit.MILLISECONDS),
                "Interval Observable"
        );

        try {
            Thread.sleep(2000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void subscribeTimedIntervalObservable() {
        subscribePrint(
                /*
                 What if we want to tell it at what
time exactly to begin working? We can do this using this interval() method. Its first
argument is the starting time, and the second and the third are for interval setup.
                 */
                Observable.interval(0L, 1L, TimeUnit.SECONDS),
                "Timed Interval Observable"
        );
        try {
            Thread.sleep(2000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void subscribeTimerObservable() {
        subscribePrint(
                /*
                This one just emits the output '0' after a given amount of time on the computation
thread (by default).
                 */
                Observable.timer(1L, TimeUnit.SECONDS),
                "Timer Observable"
        );
        try {
            Thread.sleep(2000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void subscribeErrorObservable() {
        subscribePrint(
                /*
                This emits just the error
passed to it as an OnError notification. This is similar to the 'throw' keyword in
the classical, imperative Java world.
                 */
                Observable.error(new Exception("Test Error!")),
                "Error Observable"
        );
    }

    @Test
    public void subscribeEmptyObservable() {
        /*
         This one emits no items, but it emits
a OnCompleted notification immediately.
         */
        subscribePrint(Observable.empty(), "Empty Observable");
    }

    @Test
    public void subscribeNeverObservable() {
        /*
        This does nothing. It sends no
notifications to its Observer instances, and even the OnCompleted notification is
not sent.
         */
        subscribePrint(Observable.never(), "Never Observable");
    }

    @Test
    public void subscribeRangeObservable() {
        /*
        This
method sends sequential numbers beginning with the first parameter passed.
The second parameter is the number of the emissions.
         */
        subscribePrint(Observable.range(1, 3), "Range Observable");
    }

    @Test
    public void refCount() {
        /*
        Nothing will happen until the connect() method is called. After that, we'll see the
same sequential numbers outputted twice—once for each Subscriber. The third
Subscriber will join the other two, printing the numbers emitted after the first 500
milliseconds, but it won't print the numbers emitted before its subscription.
         */
        Observable<Long> interval = Observable.interval(100L,
                TimeUnit.MILLISECONDS);
        /*
        There is a share() method, which is an alias for the
publish().refCount() call.
         */
        Observable<Long> refCount = interval.publish().refCount();
        Subscription sub1 = subscribePrint(refCount, "First");
        Subscription sub2 = subscribePrint(refCount, "Second");
        try {
            Thread.sleep(300L);
        } catch (InterruptedException e) {}
        sub1.unsubscribe();
        sub2.unsubscribe();
        Subscription sub3 = subscribePrint(refCount, "Third");
        try {
            Thread.sleep(300L);
        }catch (InterruptedException e) { }
        sub3.unsubscribe();
    }

}
