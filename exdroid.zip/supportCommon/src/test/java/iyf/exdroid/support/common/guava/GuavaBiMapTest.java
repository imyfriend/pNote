package iyf.exdroid.support.common.guava;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * 类名称：GuavaBiMapTest
 * 作者：David
 * 内容摘要：BiMap提供了一种新的集合类型，它提供了key和value的双向关联的数据结构。
 * 创建日期：2016/12/28
 * 修改者， 修改日期， 修改内容
 */
// http://www.cnblogs.com/peida/p/Guava_Bimap.html

// The bimap gives us that functionality.
// The bimap is unique, in that it keeps the values unique in the map as well as the
// keys, which is a prerequisite to invert the map and navigate from a value to a key.
public class GuavaBiMapTest {
    @Test
    public void BiMap_reverse() {
        BiMap<Integer,String> logfileMap = HashBiMap.create();
        logfileMap.put(1,"a.log");
        logfileMap.put(2,"b.log");
        logfileMap.put(3,"c.log");
        System.out.println("logfileMap:"+logfileMap); // logfileMap:{3=c.log, 2=b.log, 1=a.log}
        // inverse方法会返回一个反转的BiMap，但是注意这个反转的map不是新的map对象，它实现了一种视图关联，
        // 这样你对于反转后的map的所有操作都会影响原先的map对象
        BiMap<String,Integer> filelogMap = logfileMap.inverse();
        System.out.println("filelogMap:"+filelogMap); // filelogMap:{c.log=3, b.log=2, a.log=1}

        logfileMap.put(4,"d.log");

        System.out.println("logfileMap:"+logfileMap); // logfileMap:{4=d.log, 3=c.log, 2=b.log, 1=a.log}
        System.out.println("filelogMap:"+filelogMap); // filelogMap:{d.log=4, c.log=3, b.log=2, a.log=1}
    }

    @Test
    public void BiMap_put() {
        BiMap<Integer,String> logfileMap = HashBiMap.create();
        logfileMap.put(1,"a.log");
        logfileMap.put(2,"b.log");
        logfileMap.put(3,"c.log");
        logfileMap.put(4,"d.log");
        logfileMap.put(5,"d.log"); // 在使用BiMap时，会要求Value的唯一性。如果value重复了则会抛出错误：java.lang.IllegalArgumentException
    }

    @Test
    public void BiMap_forcePut() {
        BiMap<Integer,String> logfileMap = HashBiMap.create();
        logfileMap.put(1,"a.log");
        logfileMap.put(2,"b.log");
        logfileMap.put(3,"c.log");

        // when using a BiMap, inserting a new key with a value that already exists in the map
        // causes IllegalArgumentException to be thrown.
        logfileMap.put(4,"d.log");

        // In order to add the same value with a different key, we need to call
        // forcePut(key,value). The BiMap.forcePut call will quietly remove the map entry
        // with the same value before placing the key-value pair in the map.
        logfileMap.forcePut(5,"d.log"); // 如果确实需要插入重复的value值，那可以选择forcePut方法。但是我们需要注意的是前面的key也会被覆盖了。

        System.out.println("logfileMap:"+logfileMap); // logfileMap:{5=d.log, 3=c.log, 2=b.log, 1=a.log}
    }

    // there are also implementations of EnumBiMap, EnumHashBiMap, and ImmutableBiMap.
    // HashBiMap: key 集合与 value 集合都有 HashMap 实现
    // EnumBiMap: key 与 value 都必须是 enum 类型
    // ImmutableBiMap: 不可修改的 BiMap

}
