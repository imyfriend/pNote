package iyf.exdroid.support.common.guava;


import com.google.common.base.Preconditions;
import com.google.common.collect.ComparisonChain;

import org.junit.Test;

/**
 * 类名称：GuavaPreconditionsTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/27
 * 修改者， 修改日期， 修改内容
 */
// https://my.oschina.net/indestiny/blog/214668
public class GuavaPreconditionsTest {
    @Test
    public void Preconditions_checkNotNull() {
        Object obj = null;
        Preconditions.checkNotNull(obj, "检查对象不能为空");
    }

    @Test
    public void Preconditions_checkArgument() {
        int i = 5;
        Preconditions.checkArgument(i < 4, "检查参数值");
    }


}
