package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.concurrent.atomic.AtomicReference;

import rx.Notification;
import rx.Observable;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * Created by imyfriend on 2017/5/20.
 */

public class ParallelismTest {
    /*
    If we call the  subscribeOn() operator with a  Scheduler instance on
these  Observable instances, each one of them will be scheduled on a new  Worker
instance, and they'll work in parallel (if the host machine allows that).
     */
    @Test
    public void subscribeOn() {
        Observable<Integer> range = Observable
                .range(20, 5)
                .flatMap(new Func1<Integer, Observable<Integer>>() {
                    @Override
                    public Observable<Integer> call(Integer n) {
                        return Observable
                                .range(n, 3)
                                .subscribeOn(Schedulers.computation())
                                .doOnEach(ParallelismTest.<Integer>debug("Source"));
                    }
                });
        range.subscribe();

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    static <T> Action1<Notification<? super T>> debug(String description) {
        return debug(description, "");
    }

    static <T> Action1<Notification<? super T>> debug(final String description,
                                                      final String offset) {
        final AtomicReference<String> nextOffset = new AtomicReference<>(">");
        return new Action1<Notification<? super T>>() {
            @Override
            public void call(Notification<? super T> notification) {
                switch (notification.getKind()) {
                    case OnNext:
                        System.out.println(
                                Thread.currentThread().getName() +
                                        "|" + description + ": " + offset +
                                        nextOffset.get() + notification.getValue()
                        );
                        break;
                    case OnError:
                        System.err.println(
                                Thread.currentThread().getName() +
                                        "|" + description + ": " + offset +
                                        nextOffset.get() + " X " + notification.getThrowable()
                        );
                        break;
                    case OnCompleted:
                        System.out.println(
                                Thread.currentThread().getName() +
                                        "|" + description + ": " + offset +
                                        nextOffset.get() + "|"
                        );
                    default:
                        break;
                }
                nextOffset.getAndSet("-" + nextOffset.get());
            }
        };
    }

}
