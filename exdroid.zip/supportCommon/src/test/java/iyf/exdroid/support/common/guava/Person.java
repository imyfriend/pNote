package iyf.exdroid.support.common.guava;

import com.google.common.base.Objects;
import com.google.common.collect.ComparisonChain;

/**
 * 类名称：Person
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/2/13
 * 修改者， 修改日期， 修改内容
 */
public class Person implements Comparable<Person> {
    private int id;
    private String name;
    private int age;

    public Person(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this) //toString
                .omitNullValues() //忽略null属性
                .add("id", id)
                .add("name", name)
                .add("age", age)
                .toString();
    }

    @Override
    public int compareTo(Person o) {
        return ComparisonChain.start()
                .compare(this.name, o.name)
                .compare(this.age, o.age)
                .result();
    }
}
