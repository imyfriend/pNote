package iyf.exdroid.support.common.guava;


import com.google.common.base.Function;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.collect.Ordering;
import com.google.common.primitives.Ints;

import org.junit.Test;

import java.util.Comparator;
import java.util.List;

/**
 * 类名称：GuavaOrderingTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/27
 * 修改者， 修改日期， 修改内容
 */
public class GuavaOrderingTest {
    /*
    There are two ways in which you can create an instance of Ordering:
        • Creating a new instance and providing an implementation for the compare
method.
        • Using the static Ordering.from method that creates an instance of Ordering
from an existing Comparator.
     */

    @Test
    public void Ordering_natural() {
        ImmutableList<String> list = ImmutableList.of("1", "2", "c", "a", "f", "3", "2");
        System.out.println(Ordering.natural().sortedCopy(list));//[1, 2, 2, 3, a, c, f]
    }

    @Test
    public void Ordering_from() {
        ImmutableList<String> list = ImmutableList.of("123", "26", "cdfadf", "addd", "ffffffff", "3", "2");

        // If we were to use the byLengthOrdering comparator to sort a collection of String
        // objects, the list would be sorted in its natural order, from smallest to largest.
        Ordering<String> byLengthOrdering = new Ordering<String>() {
            public int compare(String left, String right) {
                return Ints.compare(left.length(), right.length());
            }
        };

        // 用compound方法包装排序器时，不应遵循从后往前读的原则，它是从前往后的。
        // 下面例子里，在byLengthOrdering比较结果相同时，才会进行stringComparator
        // 为了避免理解上的混乱，请不要把compound写在一长串链式调用的中间，你可以另起一行，在链中最先或最后调用compound。
        Comparator<String> stringComparator = new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o1.compareTo(o2);
            }
        };
        Ordering<String> ordering = byLengthOrdering.compound(stringComparator);

        System.out.println(byLengthOrdering.sortedCopy(list));//[3, 2, 26, 123, addd, cdfadf, ffffffff]

        // The Ordering.greatestOf method will return the n
        // greatest elements (three greatest elements in this case).
        System.out.println(byLengthOrdering.greatestOf(list, 3));//[ffffffff, cdfadf, addd]

        System.out.println(ordering.sortedCopy(list));//[2, 3, 26, 123, addd, cdfadf, ffffffff]
        System.out.println(ordering.min(list));//2

        Ordering<String> byLengthOrderingReverse = byLengthOrdering.reverse();
        System.out.println(byLengthOrderingReverse.sortedCopy(list));//[ffffffff, cdfadf, addd, 123, 26, 3, 2]
    }

    @Test
    public void Ordering_nullsFirst() {
        List<String> list = Lists.newArrayList("123", "26", null, "cdfadf", "addd", "ffffffff", "3", "2");
        Ordering<String> ordering = Ordering.from(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                if (null == o1) {
                    return -1;
                } else if (null == o2) {
                    return -1;
                }
                return Ints.compare(o1.length(), o2.length());
            }
        });

        System.out.println(ordering.sortedCopy(list));//[3, 2, addd, cdfadf, ffffffff, null, 26, 123]
        System.out.println(ordering.nullsFirst().sortedCopy(list));//[null, 3, 2, 26, 123, addd, cdfadf, ffffffff]
    }




}
