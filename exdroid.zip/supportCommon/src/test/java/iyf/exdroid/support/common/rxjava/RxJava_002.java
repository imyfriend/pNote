package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Scheduler;
import rx.schedulers.Schedulers;

/**
 * Created by admin on 2017/7/17.
 */

public class RxJava_002 {
    @Test
    public void test_001() {
        Observable
                .just(8, 9, 10)
                .doOnNext(i -> System.out.println("A: " + i))
                .filter(i -> i % 3 > 0)
                .doOnNext(i -> System.out.println("B: " + i))
                .map(i -> "#" + i * 10)
                .doOnNext(s -> System.out.println("C: " + s))
                .filter(s -> s.length() < 4)
                .subscribe(s -> System.out.println("D: " + s));
    }

    @Test
    public void test_002() {
        Scheduler        scheduler = Schedulers.immediate();
        Scheduler.Worker worker    = scheduler.createWorker();
        log("Main start");
        worker.schedule(() -> {
            log(" Outer start");
            sleepOneSecond();
            worker.schedule(() -> {
                log(" Inner start");
                sleepOneSecond();
                log(" Inner end");
            });
            log(" Outer end");
        });
        log("Main end");
        worker.unsubscribe();
    }

    @Test
    public void test_003() {
        Scheduler        scheduler = Schedulers.trampoline();
        Scheduler.Worker worker    = scheduler.createWorker();
        log("Main start");
        worker.schedule(() -> {
            log(" Outer start");
            sleepOneSecond();
            worker.schedule(() -> {
                log(" Inner start");
                sleepOneSecond();
                log(" Inner end");
            });
            log(" Outer end");
        });
        log("Main end");
        worker.unsubscribe();
    }

    static void sleepOneSecond() {
        sleep(1, TimeUnit.SECONDS);
    }

    static void sleep(int timeout, TimeUnit unit) {
        try {
            unit.sleep(timeout);
        } catch (InterruptedException ignored) {
            //intentionally ignored
        }
    }

    private static void log(Object msg) {
        System.out.println(
                Thread.currentThread().getName() +
                        ": " + msg);
    }

}
