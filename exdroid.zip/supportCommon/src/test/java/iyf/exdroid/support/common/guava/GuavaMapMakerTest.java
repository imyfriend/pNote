package iyf.exdroid.support.common.guava;

import com.google.common.base.Function;
import com.google.common.collect.MapMaker;

import org.junit.Test;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertTrue;

/**
 * Created by ii on 2017/3/20.
 */

public class GuavaMapMakerTest {

    @Test
    public void MapMaker_weakKeys() {
        ConcurrentMap<String, String> map = new MapMaker().weakKeys().makeMap();

        String key1 = new String("key1");
        map.put(key1, "value1");
        System.out.println(map);
        key1 = null; // key变成了WeakReference

        System.gc();// 触发垃圾回收
        try {
            TimeUnit.SECONDS.sleep(1L);
        } catch (Exception e) {

        }

        System.out.println(map);
        System.out.println(map.isEmpty());
        System.out.println(map.size());
        //assertTrue(map.isEmpty()); // map空了，因为WeakReference被回收
    }

}
