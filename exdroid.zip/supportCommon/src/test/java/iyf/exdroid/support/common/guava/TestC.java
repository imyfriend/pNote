package iyf.exdroid.support.common.guava;

/**
 * 类名称：TestC
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/28
 * 修改者， 修改日期， 修改内容
 */
public class TestC {
    public TestC() {
        System.out.println("TestC()" );
    }

    public int func(String str) {
        System.out.println("in func(), str=" + str );
        return 1;
    }
}
