package iyf.exdroid.support.common.guava;

import com.google.common.base.CharMatcher;

import org.junit.Test;

/**
 * 类名称：GuavaCharMatcherTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/27
 * 修改者， 修改日期， 修改内容
 */

// https://my.oschina.net/indestiny/blog/214668
public class GuavaCharMatcherTest {
    @Test
    public void CharMatcher_collapseFrom() {
        String tabsAndSpaces = "String  with      spaces     and tabs";
        //将多个连续的空格替换为一个
        String scrubbed = CharMatcher.WHITESPACE.collapseFrom(tabsAndSpaces, ' ');
        System.out.println(scrubbed); //String with spaces and tabs
    }

    @Test
    public void CharMatcher_trimAndCollapseFrom() {
        String tabsAndSpaces = "    String  with     spaces     and tabs";
        String scrubbed = CharMatcher.WHITESPACE.trimAndCollapseFrom(tabsAndSpaces, ' ');
        System.out.println(scrubbed); //String with spaces and tabs
    }

    @Test
    public void CharMatcher_retainFrom() {
        String lettersAndNumbers = "foo989yxbar234";
        String retained = CharMatcher.JAVA_DIGIT.retainFrom(lettersAndNumbers); //保留数字
        System.out.println(retained); //989234
    }

    @Test
    public void CharMatcher_or() {
        CharMatcher cm = CharMatcher.JAVA_DIGIT.or(CharMatcher.WHITESPACE);
        String retained = cm.retainFrom("foo9 89y xbar 234");//保留数字和空格
        System.out.println(retained); //9 89  234
    }

    @Test
    public void CharMatcher_is() {
        CharMatcher cm = CharMatcher.is('a');
        String retained = cm.retainFrom("foo9 89y xbar 234");//a
        System.out.println(retained); //a
    }


}
