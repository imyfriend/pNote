package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Func2;
import rx.subjects.AsyncSubject;
import rx.subjects.BehaviorSubject;
import rx.subjects.PublishSubject;
import rx.subjects.ReplaySubject;
import rx.subjects.Subject;

/**
 * Created by imyfriend on 2017/4/30.
 */

public class subjectTest {
    /*
    The Subject instances are both Observable instances and Observer instances. Like
Observable instances, they can have multiple Observer instances, receiving the same
notifications. That's why they can be used to turn cold Observable instances into hot
ones. Like Observer instances, they give us access to their onNext(), onError(), or
onCompleted() methods.
     */

    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                        + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }

    @Test
    public void PublishSubject_001() {
        Observable<Long> interval = Observable.interval(100L,
                TimeUnit.MILLISECONDS);
        /*
        PublishSubject: This is the one we saw in the previous example, behaving like
        ConnectableObservable, created using the publish() method.
         */
        Subject<Long, Long> publishSubject = PublishSubject.create();
        interval.subscribe(publishSubject);
        Subscription sub1 = subscribePrint(publishSubject, "First");
        Subscription sub2 = subscribePrint(publishSubject, "Second");
        Subscription sub3 = null;
        try {
            Thread.sleep(300L);
            publishSubject.onNext(555L);
            //publishSubject.onCompleted();
            sub3 = subscribePrint(publishSubject, "Third");
            Thread.sleep(500L);
        }catch (InterruptedException e) {}
        sub1.unsubscribe();
        sub2.unsubscribe();
        sub3.unsubscribe();
    }

    /*
    ReplaySubject: This emits to any observer all of the items that were emitted by
the source Observable instance, regardless of when the observer subscribes. So,
it behaves like ConnectableObservable, created using the replay() method.
The ReplaySubject class has many factory methods. The default one caches
everything; keep this in mind, because it can eat up memory. There are factory
methods for creating it with size-bound and/or time-bound buffers. As with the
PublishSubject class, this one can be used without a source Observable
instance. All of the notifications emitted using its onNext(), onError(), and
onCompleted() methods will be emitted to every Subscriber, even if it is
subscribed after invoking the on* methods.
     */
    @Test
    public void ReplaySubject_001() {
        Observable<Long> interval = Observable.interval(100L,
                                                        TimeUnit.MILLISECONDS);
        Subject<Long, Long> replaySubject = ReplaySubject.create();
        interval.subscribe(replaySubject);

        Subscription sub1 = subscribePrint(replaySubject, "First");
        Subscription sub2 = subscribePrint(replaySubject, "Second");

        Utils.sleep(300, TimeUnit.MILLISECONDS);
        replaySubject.onNext(555L);
        Subscription sub3 = subscribePrint(replaySubject, "Third");
        Utils.sleep(500, TimeUnit.MILLISECONDS);

        sub1.unsubscribe();
        sub2.unsubscribe();
        sub3.unsubscribe();
    }

    /*
    BehaviorSubject: When an observer subscribes to it, it emits the item most
recently emitted by the source Observable instance (or a seed/default value if
none have yet been emitted) and then continues to emit any other items emitted later
by the source Observable instance. The BehaviorSubject class is almost like
the ReplaySubjects class with a buffer size of one. The BehaviorSubject class
can be used to implement a stateful reactive instance—a reactive property. Again,
a source Observable instance is not needed.
     */
    @Test
    public void BehaviorSubject_001() {
        class ReactiveSum {
            private BehaviorSubject<Double> a = BehaviorSubject.create(0.0);
            private BehaviorSubject<Double> b = BehaviorSubject.create(0.0);
            private BehaviorSubject<Double> c = BehaviorSubject.create(0.0);
            public ReactiveSum() {
                //Observable.combineLatest(a, b, (x, y) -> x + y).subscribe(c);
                Observable.combineLatest(a, b, new Func2<Double, Double, Double>() {
                    @Override
                    public Double call(Double aDouble, Double aDouble2) {
                        return aDouble + aDouble2;
                    }
                }).subscribe(c);
            }
            public double getA() {
                return a.getValue();
            }
            public void setA(double a) {
                this.a.onNext(a);
            }
            public double getB() {
                return b.getValue();
            }
            public void setB(double b) {
                this.b.onNext(b);
            }
            public double getC() {
                return c.getValue();
            }
            public Observable<Double> obsC() {
                return c.asObservable();
            }
        }

        ReactiveSum sum = new ReactiveSum();
        subscribePrint(sum.obsC(), "Sum");
        sum.setA(5);
        sum.setB(4);
    }

    /*
    AsyncSubject: This emits the last value (and only that) emitted by the source
Observable instance, and only after the source Observable instance completes. If
the source Observable instance does not emit any values, the AsyncSubject
instance also completes without emitting any values. This is something like a
promise in RxJava's world. A source Observable instance is not needed; the
value, the error, or the OnCompleted notification can be passed to it by invoking
the on* methods.
     */
    @Test
    public void AsyncSubject_001() {
        Observable<Integer> observable = Observable.just(1,2,3);
        Subject<Integer, Integer> asyncSubject = AsyncSubject.create();
        observable.subscribe(asyncSubject);

        Subscription sub1 = subscribePrint(asyncSubject, "First");
        Subscription sub2 = subscribePrint(asyncSubject, "Second");

        Utils.sleep(300, TimeUnit.MILLISECONDS);

        Subscription sub3 = subscribePrint(asyncSubject, "Third");
        Utils.sleep(500, TimeUnit.MILLISECONDS);

        sub1.unsubscribe();
        sub2.unsubscribe();
        sub3.unsubscribe();
    }

    @Test
    public void AsyncSubject_002() {
        Subject<Integer, Integer> asyncSubject = AsyncSubject.create();

        asyncSubject.onNext(555);

        Subscription sub1 = subscribePrint(asyncSubject, "First");
        Subscription sub2 = subscribePrint(asyncSubject, "Second");

        asyncSubject.onNext(666);
        Utils.sleep(300, TimeUnit.MILLISECONDS);

        asyncSubject.onNext(777);

        Subscription sub3 = subscribePrint(asyncSubject, "Third");
        Utils.sleep(500, TimeUnit.MILLISECONDS);

        asyncSubject.onCompleted();

        sub1.unsubscribe();
        sub2.unsubscribe();
        sub3.unsubscribe();
    }

    @Test
    public void AsyncSubject_003() {
        Observable<Integer> observable = Observable.just(1,2,3);
        Subject<Integer, Integer> asyncSubject = AsyncSubject.create();
        observable.subscribe(asyncSubject);

        asyncSubject.onNext(555);
        Subscription sub1 = subscribePrint(asyncSubject, "First");
        Subscription sub2 = subscribePrint(asyncSubject, "Second");
        Utils.log("sub1 & sub2");

        asyncSubject.onNext(666);
        Utils.sleep(300, TimeUnit.MILLISECONDS);
        asyncSubject.onNext(777);
        Subscription sub3 = subscribePrint(asyncSubject, "Third");
        Utils.log("sub3");
        Utils.sleep(500, TimeUnit.MILLISECONDS);

        asyncSubject.onCompleted();

        sub1.unsubscribe();
        sub2.unsubscribe();
        sub3.unsubscribe();
    }

    @Test
    public void AsyncSubject_004() {
        Observable<Integer> observable = Observable.just(1,2,3);
        Subject<Integer, Integer> asyncSubject = AsyncSubject.create();
        observable.subscribe(asyncSubject);

        Subscription sub1 = subscribePrint(asyncSubject, "First");
        Subscription sub2 = subscribePrint(asyncSubject, "Second");

        Utils.sleep(300, TimeUnit.MILLISECONDS);

        Observable<Integer> observable1 = Observable.just(11,12,13);
        observable1.subscribe(asyncSubject);
        Subscription sub3 = subscribePrint(asyncSubject, "Third");
        Utils.sleep(500, TimeUnit.MILLISECONDS);

        sub1.unsubscribe();
        sub2.unsubscribe();
        sub3.unsubscribe();

        Observable<Integer> observable2 = Observable.just(21,22,23);
        observable2.subscribe(asyncSubject);
        Subscription sub4 = subscribePrint(asyncSubject, "Fourth");
        Utils.sleep(500, TimeUnit.MILLISECONDS);
        sub4.unsubscribe();

    }

    @Test
    public void AsyncSubject_005() {
        Observable<Long> interval = Observable.interval(100L,
                                                        TimeUnit.MILLISECONDS);
        Subject<Long, Long> asyncSubject = AsyncSubject.create();
        interval.subscribe(asyncSubject);

        Subscription sub1 = subscribePrint(asyncSubject, "First");

        Observable<Long> observable = Observable.just(111L,222L,333L);
        observable.subscribe(asyncSubject);
        Subscription sub2 = subscribePrint(asyncSubject, "Second");

        sub1.unsubscribe();
        sub2.unsubscribe();

        Utils.sleep(500, TimeUnit.MILLISECONDS);

        /*
        First : 333, thread name=main
        First ended!
        Second : 333, thread name=main
        Second ended!
         */
    }

    /*
    Using subjects may seem a cool way to solve various problems, but you should avoid
using them. Or, at least implement them and their behavior in a method that returns a
result of type Observable.
The danger with the Subject instance is that they give access to the onNext(),
onError(), and onCompleted() methods, and your logic can get messy (they need to
be called following the Rx contract, cited earlier in this chapter). They can be misused
very easily.
     */




}
