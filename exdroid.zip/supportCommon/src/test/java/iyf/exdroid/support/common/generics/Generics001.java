package iyf.exdroid.support.common.generics;

import com.google.common.base.Joiner;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Created by imyfriend on 2017/6/13.
 */

public class Generics001 {
    @Test
    public void iterator_remove() {
        List<Integer> ints = new ArrayList<>();
        ints.add(1);
        ints.add(-1);
        System.out.println(Joiner.on(",").join(ints));
        for (Iterator<Integer> it = ints.iterator();
                it.hasNext();) {
            if (it.next() > 0) {
                it.remove();
            }
        }
        System.out.println("after remove(), " + Joiner.on(",").join(ints));
        Collections.max(ints);
    }

    @Test
    public void lists() {
        List<Integer> ints = Lists.toList();
        System.out.println(Joiner.on(",").join(ints));

        List<Object> objs = Lists.<Object>toList(1, "two");
        System.out.println(Joiner.on(",").join(objs));
    }

    @Test
    public void test_001() {
        List<Integer> ints = new ArrayList<>();
        ints.add(1);
        List<? extends Number> nums = ints;
        //nums.add(3);
        nums.remove(3.2);
    }

}

class Lists {
    /*public static <T> List<T> toList(T[] arr) {
        List<T> list = new ArrayList<>();
        for (T elt : arr) {
            list.add(elt);
        }
        return list;
    }*/

    public static <T> List<T> toList(T... arr) {
        List<T> list = new ArrayList<>();
        for (T elt : arr) {
            list.add(elt);
        }
        return list;
    }

    public static <T> List<T> newList() {
        List<T> ints = Lists.<T>toList();
        return ints;
    }
}
