package iyf.exdroid.support.common.rxjava;

import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;

/**
 * Created by admin on 2017/7/27.
 */

public class Utils {
    public static void sleep(int timeout, TimeUnit unit) {
        try {
            unit.sleep(timeout);
        } catch (InterruptedException ignored) {
            //intentionally ignored
        }
    }

    public static void log(Object msg) {
        System.out.println(
                Thread.currentThread().getName() +
                        ": " + msg);
    }

    public static <T> Subscription subscribePrint(Observable<T> observable, String name) {
        return observable.subscribe(
                (v) -> System.out.println(name + " : " + v),
                (e) -> {
                    System.err.println("Error from " + name + ":");
                    System.err.println(e.getMessage());
                },
                () -> System.out.println(name + " ended!")
            );
    }

    public static void findCaller() {
        final Throwable mThrowable = new Throwable();
        final StackTraceElement[] elements = mThrowable.getStackTrace();
        final int len = elements.length;
        StackTraceElement item;
        for (int i = 1; i < len; i++) {
            item = elements[i];
            log("StackTrace: " +
                    item.getClassName() + "." + item.getMethodName()
                    + " ---" + item.getLineNumber() + " line");
        }
    }

    public static <T> void onSafeCompleted(Subscriber<? super T> subscriber) {
        if (!subscriber.isUnsubscribed()) {
            subscriber.onCompleted();
        }
    }

    public static <T> void onSafeError(Subscriber<? super T> subscriber, Throwable e) {
        if (!subscriber.isUnsubscribed()) {
            subscriber.onError(e);
        }
    }

    public static <T> void onSafeNext(Subscriber<? super T> subscriber, T t) {
        if (!subscriber.isUnsubscribed()) {
            subscriber.onNext(t);
        }
    }

}
