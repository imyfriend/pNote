package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.functions.Func2;

import static rx.Observable.just;

/**
 * 类名称：ErrorTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/5/17
 * 修改者， 修改日期， 修改内容
 */
public class ErrorTest {
    /*
    The onErrorReturn operator can be used in order to prevent the Subscriber
instance's onError from being called. Instead, it will emit one last item and complete.
    The Integer::parseInt method will succeed in converting the strings 1 and 2 to
Integer values, but it will fail on three with a NumberFormatException exception.
This exception will be passed to the onErrorReturn() method, which will return the
number -1. The numbers Observable instance will emit the number -1 and complete.
So the output will be 1, 2, -1, OnCompleted notification.
     */
    @Test
    public void onErrorReturn() {
        Observable<Integer> numbers = just("1", "2", "three", "4", "5")
                .map(new Func1<String, Integer>() {
                    @Override
                    public Integer call(String s) {
                        return Integer.parseInt(s);
                    }
                })
                .onErrorReturn(new Func1<Throwable, Integer>() {
                    @Override
                    public Integer call(Throwable throwable) {
                        return -1;
                    }
                });
        subscribePrint(numbers, "Error returned");
    }

    /*
    This is fine, but sometimes we'll want to switch to another Observable chain of
operations on exception. For that, we can use the onExceptionResumeNext() operator,
which returns a backup Observable instance that will replace the source one when an
Exception occurs.
    Now this will output 1, 2, 5, 4, 3, 2, 1, OnCompleted notification because, after the
Exception raised on 'three', the defaultOnError Observable instance passed to
onExceptionResumeNext() method will begin emitting, replacing the source
Observable instance for all the Subscriber methods.
     */
    @Test
    public void onExceptionResumeNext() {
        Observable<Integer> defaultOnError =
                just(5, 4, 3, 2, 1);
        Observable<Integer> numbers = just("1", "2", "three", "4", "5")
                .map(new Func1<String, Integer>() {
                    @Override
                    public Integer call(String s) {
                        return Integer.parseInt(s);
                    }
                })
                .onExceptionResumeNext(defaultOnError);
        subscribePrint(numbers, "Exception resumed");
    }

    /*
    onErrorResumeNext： 当原始Observable在遇到错误时，使用备用Observable.
    当原始Observable在遇到异常时，使用备用的Observable。
    与onErrorResumeNext类似，区别在于onErrorResumeNext可以处理所有的错误，onExceptionResumeNext只能处理异常。
     */
    @Test
    public void onErrorResumeNext() {
        Observable onErrorResumeNext = Observable.just(1,"2",3)
                .cast(Integer.class)
                .onErrorResumeNext(just(1, 2, 3));
        subscribePrint(onErrorResumeNext, "Error resumed");

        Observable<Integer> defaultOnError = just(5, 4, 3, 2, 1);
        Observable<Integer> numbers = Observable.just("1", "2", "three", "4", "5")
                /*
                The doOnNext() operator used in this example is a side effect generator. It doesn't
change the items emitted by the Observable instance it is called upon. It can be used for
logging, caching, asserting, or adding additional logic. There are doOnError() and
doOnCompleted() operators too. In addition, there is a finallyDo() operator, which
executes the function passed to it when there is an error or when the Observable
instance has completed.
                 */
                .doOnNext(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        assert !s.equals("three");
                    }
                })
                .map(new Func1<String, Integer>() {
                    @Override
                    public Integer call(String s) {
                        return Integer.parseInt(s);
                    }
                })
                .onErrorResumeNext(defaultOnError);
        subscribePrint(numbers, "onErrorResumeNext resumed");
    }

    /*
Inserting the retry() operator into the Observable action chain means that if an error
occurs, the subscribers will resubscribe to the source Observable instance and try
everything from the beginning of the chain. If there is an error again, everything is
restarted once more. The retry() operator without parameters retries infinitely. There
is an overload retry(int) method, which takes the number of the maximum allowed
retry attempts.
     */
    @Test
    public void retry() {
        subscribePrint(Observable.create(new ErrorEmitter()).retry(),
                       "Retry");
    }

    @Test
    public void retry_001() {
        subscribePrint(Observable.create(new ErrorEmitter()).retry(new Func2<Integer, Throwable, Boolean>() {
                           @Override
                           public Boolean call(Integer integer, Throwable throwable) {
                               return (throwable instanceof BooException) && (integer > 2);
                           }
                       }),
                       "Retry 1");
    }

    /*
     retryWhen当原始Observable在遇到错误，将错误传递给另一个Observable来决定是否要重新订阅这个Observable,内部调用的是retry。
     */
    @Test
    public void retryWhen_001() {
        Observable<Long> when = Observable.create(new ErrorEmitter())
                .retryWhen(new Func1<Observable<? extends Throwable>, Observable<Long>>() {
                    @Override
                    public Observable<Long> call(Observable<? extends Throwable> observable) {
                        return observable.flatMap(new Func1<Throwable, Observable<Long>>() {
                            @Override
                            public Observable<Long> call(Throwable throwable) {
                                if (throwable instanceof FooException) {
                                    System.err.println("Delaying...");
                                    return Observable.timer(1L, TimeUnit.SECONDS);
                                }
                                return Observable.error(throwable);
                            }
                        });
                    }
                })
                .retry(new Func2<Integer, Throwable, Boolean>() {
                    @Override
                    public Boolean call(Integer integer, Throwable throwable) {
                        return (throwable instanceof BooException) && (integer < 3);
                    }
                });
        subscribePrint(when, "retryWhen");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    @Test
    public void retryWhen() {
        Observable retryWhen = Observable.just(1,"2",3)
                .cast(Integer.class)
                .retryWhen(new Func1<Observable<? extends Throwable>, Observable<Long>>() {
                    @Override
                    public Observable<Long> call(Observable<? extends Throwable> observable) {
                        return Observable.timer(1, TimeUnit.SECONDS);
                    }
                });
        subscribePrint(retryWhen,"retryWhen");

        try {
            Thread.sleep(4000L);
        } catch (Exception e) {

        }
    }

    class FooException extends RuntimeException {
        public FooException() {
            super("Foo!");
        }
    }

    class BooException extends RuntimeException {
        public BooException() {
            super("Boo!");
        }
    }

    class ErrorEmitter implements OnSubscribe<Long> {
        private int throwAnErrorCounter = 5;
        @Override
        public void call(Subscriber<? super Long> subscriber) {
            subscriber.onNext(1L);
            subscriber.onNext(2L);
            if (throwAnErrorCounter > 4) {
                throwAnErrorCounter--;
                subscriber.onError(new FooException());
                return;
            }
            if (throwAnErrorCounter > 0) {
                throwAnErrorCounter--;
                subscriber.onError(new BooException());
                return;
            }
            subscriber.onNext(3L);
            subscriber.onNext(4L);
            subscriber.onCompleted();
        }
    }




    private <T> Subscription subscribePrint(Observable<T> observable, final String name) {
        /*
        The method return results of type Subscription that can be used for
unsubscribing from the notifications emitted by the Observable instance.
Unsubscribing usually cleans up internal resources associated with a subscription; for
example, if we implement an HTTP request with the Observable.create() method
and want to cancel it by a particular time, or we have an Observable instance emitting
a sequence of numbers/words/arbitrary data infinitely and want to stop that.
The Subscription interface has two methods:
1:void unsubscribe(): This is used for unsubscribing.
2:boolean isUnsubscribed(): This is used to check whether the Subscription
instance is already unsubscribed.
         */
        return observable.subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                System.out.println(name + " ended!");
            }

            @Override
            public void onError(Throwable e) {
                System.err.println("Error from " + name + ":");
                System.err.println(e.getMessage());
            }

            @Override
            public void onNext(T t) {
                System.out.println(name + " : " + t
                                           + ", thread name=" + Thread.currentThread().getName());
            }
        });
    }



}
