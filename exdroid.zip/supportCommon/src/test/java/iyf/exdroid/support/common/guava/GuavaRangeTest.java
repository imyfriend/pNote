package iyf.exdroid.support.common.guava;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Range;

import org.junit.Test;

/**
 * 类名称：GuavaRangeTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2017/2/22
 * 修改者， 修改日期， 修改内容
 */
public class GuavaRangeTest {
    // The Range class allows us to create a specifc interval or span of values with
    // defned endpoints, and works with Comparable types. The Range objects can
    // defne endpoints that are either inclusive (closed), which includes the end value
    // of the Range instance, or exclusive (open), which does not include the end value
    // of the Range instance.
    @Test
    public void Range_closed() {
        Range<Integer> numberRange = Range.closed(1, 10);
        //both return true meaning inclusive
        System.out.println(numberRange.contains(10));
        System.out.println(numberRange.contains(1));
    }

    @Test
    public void Range_open() {
        Range<Integer> numberRange = Range.open(1,10);
        //both return false meaning exclusive
        System.out.println(numberRange.contains(10));
        System.out.println(numberRange.contains(1));
    }

    // We can create Range objects with a variety of boundary conditions such as
    // openClosed, closedOpen, greaterThan, atLeast, lessThan, and atMost.


    // the Range object implements the Predicate interface.
    @Test
    public void Range_predicate() {
        Range<Integer> ageRange = Range.closed(35, 50);

        Function<Person,Integer> ageFunction = new Function<Person,
                        Integer>() {
            @Override
            public Integer apply(Person person) {
                return person.getAge();
            }
        };

        Predicate<Person> predicate =
                Predicates.compose(ageRange, ageFunction);

        Person person = new Person(101, "Person1", 23);
        System.out.println(predicate.apply(person));//false

        person.setAge(35);
        System.out.println(predicate.apply(person));//true
    }


    // Since Range objects work with any object that implements the Comparable
    // interface, it makes it easy to create a filter for working with only those objects
    // that fall within our desired boundaries.
    @Test
    public void Range_comparable() {
        Person person1 = new Person(101, "Person1", 23);
        Person person2 = new Person(102, "Person3", 35);
        Range<Person> personRange = Range.closedOpen(person1, person2);

        final Range<String> nameRange = Range.closedOpen("Person1", "Person3");
        final Range<Integer> ageRange = Range.closedOpen(23, 35);
        Predicate predicate = new Predicate<Person>() {

            @Override
            public boolean apply(Person input) {
                return nameRange.contains(input.getName()) && ageRange.contains(input.getAge());
            }
        };

        Person person3 = new Person(10200, "Person3", 37);
        System.out.println(personRange.contains(person3));//false
        System.out.println(predicate.apply(person3));//false

        person3.setName("Person2");
        System.out.println(personRange.contains(person3));//true
        System.out.println(predicate.apply(person3));//false

        person3.setAge(33);
        System.out.println(personRange.contains(person3));//true
        System.out.println(predicate.apply(person3));//true

    }


}
