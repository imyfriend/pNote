package iyf.exdroid.support.common.rxjava;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.observers.TestSubscriber;
import rx.schedulers.Schedulers;
import rx.schedulers.TestScheduler;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.junit.Assert.assertTrue;

/**
 * Created by admin on 2017/8/24.
 */

public class TestSchedulerTest {
    private static final List<String> WORDS = Arrays.asList(
            "the",
            "quick",
            "brown",
            "fox",
            "jumped",
            "over",
            "the",
            "lazy",
            "dog");

    @Test
    public void testUsingTestScheduler() {
        // given:
        TestScheduler          scheduler  = new TestScheduler();
        TestSubscriber<String> subscriber = new TestSubscriber<>();
        Observable<Long>       tick       = Observable.interval(1, SECONDS, scheduler);

        Observable<String> observable = Observable.from(WORDS)
                .zipWith(tick, (string, index) -> String.format("%2d. %s", index, string));

        observable.subscribeOn(scheduler)
                .subscribe(subscriber);

        // expect:
        subscriber.assertNoValues();
        subscriber.assertNotCompleted();

        // when:
        scheduler.advanceTimeBy(1, SECONDS);

        // then:
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
        subscriber.assertValues(" 0. the");

        // when:
        scheduler.advanceTimeTo(9, SECONDS);
        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(9);
    }

    @Test
    public void advanceTimeTo() {
        /*
        如果不调用 advanceTimeTo 来使时间前进，则所有任务都不会执行，因为在 TestScheduler 中时间是停止的。
        当时间前进的时候， TestScheduler 会同步执行所有满足时间条件的任务。
        advanceTimeTo 可以设置时间为任意时刻。也可以回到过去（设置的时间比当前的时间还早）。
         */
        TestScheduler s = Schedulers.test();

        s.createWorker().schedule(
                () -> System.out.println("Immediate"));
        s.createWorker().schedule(
                () -> System.out.println("20s"),
                20, SECONDS);
        s.createWorker().schedule(
                () -> System.out.println("40s"),
                40, SECONDS);
        System.out.println("init: " + s.now());

        System.out.println("Advancing to 1ms");
        s.advanceTimeTo(1, TimeUnit.MILLISECONDS); // advanceTimeTo 函数就是把 TestScheduler 中的时钟前进指定的时间刻度
        System.out.println("Virtual time: " + s.now());

        System.out.println("Advancing to 10s");
        s.advanceTimeTo(10, SECONDS);
        System.out.println("Virtual time: " + s.now());

        System.out.println("Advancing to 40s");
        s.advanceTimeTo(40, SECONDS);
        System.out.println("Virtual time: " + s.now());
    }

    @Test
    public void advanceTimeBy() {
        TestScheduler s = Schedulers.test();

        s.createWorker().schedule(
                () -> System.out.println("Immediate"));
        s.createWorker().schedule(
                () -> System.out.println("20s"),
                20, SECONDS);
        s.createWorker().schedule(
                () -> System.out.println("40s"),
                40, SECONDS);

        System.out.println("Advancing by 1ms");
        s.advanceTimeBy(1, TimeUnit.MILLISECONDS); // advanceTimeBy 顾名思义，在当前时间基础上前进多少。
        System.out.println("Virtual time: " + s.now());

        System.out.println("Advancing by 10s");
        s.advanceTimeBy(10, SECONDS);
        System.out.println("Virtual time: " + s.now());

        System.out.println("Advancing by 40s");
        s.advanceTimeBy(40, SECONDS);
        System.out.println("Virtual time: " + s.now());
    }

    @Test
    public void triggerActions() {
        TestScheduler s = Schedulers.test();

        s.createWorker().schedule(
                () -> System.out.println("Immediate"));
        s.createWorker().schedule(
                () -> System.out.println("20s"),
                20, SECONDS);

        s.triggerActions(); // triggerActions 不会修改时间。只是用来执行当前可以调度的任务。
        /*
        All the actions scheduled on it
are wrapped in objects containing the time they should be executed at, and won't be
executed before the triggerActions() method of the Scheduler instance is called.
This method executes all of the actions that are not executed and are scheduled to be
executed at or before the Scheduler instance's present time.
         */
        System.out.println("Virtual time: " + s.now());
    }

    @Test
    public void conflict() {
        TestScheduler s = Schedulers.test();

        s.createWorker().schedule(
                () -> System.out.println("First"),
                20, SECONDS);
        s.createWorker().schedule(
                () -> System.out.println("Second"),
                20, SECONDS);
        s.createWorker().schedule(
                () -> System.out.println("Third"),
                20, SECONDS);

        s.advanceTimeTo(20, SECONDS);
    }

    @Test
    public void test_001() {
        TestScheduler scheduler = new TestScheduler();
        List<Long>    expected  = Arrays.asList(0L, 1L, 2L, 3L, 4L);
        List<Long>    result    = new ArrayList<>();
        Observable
                .interval(1, SECONDS, scheduler)
                .take(5)
                .subscribe(i -> result.add(i));
        assertTrue(result.isEmpty());
        scheduler.advanceTimeBy(5, SECONDS);
        assertTrue(result.equals(expected));
    }

    private static void log(Object msg) {
        System.out.println(
                Thread.currentThread().getName() +
                        ": " + msg);
    }


}
