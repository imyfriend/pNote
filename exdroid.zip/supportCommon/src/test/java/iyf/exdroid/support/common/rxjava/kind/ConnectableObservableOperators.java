package iyf.exdroid.support.common.rxjava.kind;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import iyf.exdroid.support.common.rxjava.TestSubscriberEx;
import rx.observables.ConnectableObservable;

import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static rx.Observable.interval;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

/**
 * Created by admin on 2017/7/27.
 */

public class ConnectableObservableOperators {

    @Test
    public void connectableObservable_001() {
        /*
        ConnectableObservable与普通的Observable差不多，不过它并不会在被订阅时开始发射数据，
        而是直到使用了Connect操作符时才会开始。用这个方法，你可以等待所有的观察者都订阅了Observable之后再开始发射数据。
         */
        ConnectableObservable<Long> upstream = interval(10, MILLISECONDS)
                .take(5)
                .publish();

        TestSubscriberEx subscriber1 = new TestSubscriberEx<>();
        TestSubscriberEx subscriber2 = new TestSubscriberEx<>();

        upstream.subscribe(subscriber1);
        upstream.connect();

        sleep(30, MILLISECONDS);

        upstream.subscribe(subscriber2);

        subscriber1.awaitTerminalEvent();
        List<Long> expected = Arrays.asList(0L, 1L, 2L, 3L, 4L);
        assertThat(subscriber1.getOnNextEvents(), equalTo(expected));

        subscriber2.awaitTerminalEvent();
        List<Long> expected2 = Arrays.asList(3L, 4L);
        assertThat(subscriber2.getOnNextEvents(), equalTo(expected2));
    }

    static void sleep(int timeout, TimeUnit unit) {
        try {
            unit.sleep(timeout);
        } catch (InterruptedException ignored) {
            //intentionally ignored
        }
    }

    private static void log(Object msg) {
        System.out.println(
                Thread.currentThread().getName() +
                        ": " + msg);
    }

}
