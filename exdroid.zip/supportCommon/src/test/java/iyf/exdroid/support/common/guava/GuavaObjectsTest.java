package iyf.exdroid.support.common.guava;

import com.google.common.base.Objects;

import org.junit.Test;

/**
 * 类名称：GuavaObjectsTest
 * 作者：David
 * 内容摘要：
 * 创建日期：2016/12/27
 * 修改者， 修改日期， 修改内容
 */
public class GuavaObjectsTest {
    @Test
    public void Objects_toStringHelper() {
        String res = Objects.toStringHelper(this) //toString
                .omitNullValues() //忽略null属性
                .add("title", "android")
                .add("author", "lubin").toString();
        System.out.println(res); //GuavaObjectsTest{title=android, author=lubin}
    }

    @Test
    public void Objects_firstNonNull() {
        String str = null;
        str = Objects.firstNonNull(str, "defaut value");
        System.out.println(str); //defaut value
    }



}
