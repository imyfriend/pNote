package iyf.exdroid.support.common.rxjava.kind;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import iyf.exdroid.support.common.rxjava.TestSubscriberEx;
import iyf.exdroid.support.common.rxjava.Utils;
import rx.Observable;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.junit.Assert.assertThat;

/**
 * Created by admin on 2017/7/27.
 */

public class FilteringObservables {

    @Test
    public void filter_001() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1,2,3,3,4};
        Observable.from(ints)
                .filter(x -> x>3) // 只发射满足条件的数据
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        List<Integer> expected = Arrays.asList(4);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void ofType_001() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3,3,4,true, 10.0f)
                .ofType(Integer.class) // 只发射满足条件的数据
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        List<Integer> expected = Arrays.asList(1,2,3,3,4);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void elementAt_001() {
        /*
        ElementAt操作符获取原始Observable发射的数据序列指定索引位置的数据项，然后当做自己的唯一数据发射
         */
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3,4)
                .elementAt(1) // 只发射满足条件的数据
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        List<Integer> expected = Arrays.asList(2);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void elementAt_002() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3,4)
                .elementAt(6)
                .subscribe(subscriber);

        // 如果你传递的是一个负数，或者原始Observable的数据项数小于index+1，将会抛出一个IndexOutOfBoundsException异常
        subscriber.assertError(IndexOutOfBoundsException.class);
    }

    @Test
    public void elementAt_003() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        try {
            Observable.just(1, 2, 3, 4).elementAt(-1).subscribe(subscriber);

            subscriber.assertError(IndexOutOfBoundsException.class);
        } catch (IndexOutOfBoundsException e) {
            Utils.log("!!! IndexOutOfBoundsException ERROR !!!");
        }
    }

    @Test
    public void elementAt_004() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3,4)
                .elementAtOrDefault(6, 0)
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        List<Integer> expected = Arrays.asList(0);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void debounce_001() {
        /*
        throttleWithTimeout/debounce的一个变体根据你指定的时间间隔进行限流，时间单位通过TimeUnit参数指定。
         */
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(20, TimeUnit.MILLISECONDS)
                .take(10)
                .debounce(10, TimeUnit.MILLISECONDS)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(10);
        List<Long> expected = Arrays.asList(Long.valueOf(0), Long.valueOf(1), Long.valueOf(2), Long.valueOf(3),
                                            Long.valueOf(4), Long.valueOf(5), Long.valueOf(6), Long.valueOf(7),
                                            Long.valueOf(8), Long.valueOf(9));
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void debounce_002() {
        /*
        对原始Observable的每一项应用一个函数进行限流，这个函数返回一个Observable。
        如果原始Observable在这个新生成的Observable终止之前发射了另一个数据，debounce会抑制(suppress)这个数据项。
        debounce的这个变体默认不在任何特定的调度器上执行。
         */
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(20, TimeUnit.MILLISECONDS)
                .take(10)
                .debounce(x -> Observable.just(x).delay(x * 10, TimeUnit.MILLISECONDS))
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
    }

    @Test
    public void throttleWithTimeout_001() {
        /*
        throttleWithTimeout/debounce的一个变体根据你指定的时间间隔进行限流，时间单位通过TimeUnit参数指定。
         */
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(20, TimeUnit.MILLISECONDS)
                .take(10)
                .throttleWithTimeout(10, TimeUnit.MILLISECONDS)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(10);
        List<Long> expected = Arrays.asList(Long.valueOf(0), Long.valueOf(1), Long.valueOf(2), Long.valueOf(3),
                                            Long.valueOf(4), Long.valueOf(5), Long.valueOf(6), Long.valueOf(7),
                                            Long.valueOf(8), Long.valueOf(9));
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void ignoreElements_001() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.just(1,2,3,4)
                .ignoreElements() // 不发射任何数据，只发射Observable的终止通知
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(0);
    }

    @Test
    public void ignoreElements_002() {
        TestSubscriberEx subscriber = new TestSubscriberEx<>();
        Throwable throwable = new Throwable();
        Observable.error(throwable)
                .ignoreElements() // 不发射任何数据，只发射Observable的终止通知
                .subscribe(subscriber);

        subscriber.assertError(Throwable.class);
        subscriber.assertError(throwable);
        subscriber.assertValueCount(0);
    }

    @Test
    public void distinct_001() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1,2,3,3,4};
        Observable.from(ints)
                .distinct() // 只允许还没有发射过的数据项通过
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(4);
        List<Integer> expected = Arrays.asList(1,2,3,4);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void distinct_002() {
        /*
        这个操作符有一个变体接受一个函数。这个函数根据原始Observable发射的数据项产生一个Key，
        然后，比较这些Key。如果两个数据的key相同，则只保留最先到达的数据。
         */
        TestSubscriberEx<Object> subscriber = new TestSubscriberEx<>();
        Observable.just(1, 2, 3, true, 4, 10.0f, false, 6.1f)
                .distinct(item -> {
                        if (item instanceof Integer) {
                            return "I";
                        } else if (item instanceof Boolean) {
                            return "B";
                        } else {
                            return "F";
                        }
                    })
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(3);
        List<Object> expected = Arrays.asList(1,true,10.0f);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void distinct_003() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1,2,1,1,3,3,4,5,1};
        Observable.from(ints)
                .distinctUntilChanged() // 只判定一个数据和它的直接前驱是否是不同的
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(7);
        List<Integer> expected = Arrays.asList(1,2,1,3,4,5,1);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void distinct_004() {
        TestSubscriberEx<Object> subscriber = new TestSubscriberEx<>();
        Observable.just(1, 2, 3, true, 4, 10.0f, false, 6.1f)
                .distinctUntilChanged(item -> {
                    if (item instanceof Integer) {
                        return "I";
                    } else if (item instanceof Boolean) {
                        return "B";
                    } else {
                        return "F";
                    }
                })
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        List<Object> expected = Arrays.asList(1,true,4,10.0f,false,6.1f);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void distinct_005() {
        class Test {
            Test(String s, int a) {
                name = s;
                age = a;
            }
            String name;
            int age;

            @Override
            public boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                } else if (obj instanceof Test) {
                    Test tmp = (Test)obj;
                    return name.equals(tmp.name) && (age==tmp.age);
                } else {
                    return false;
                }
            }

            @Override
            public String toString() {
                return "name=" + name + ", age=" + age;
            }

            @Override
            public int hashCode() {
                return name.hashCode() + age;
            }
        }

        Test t1 = new Test("t1", 1);
        Test t2 = new Test("t1", 1);
        Test t3 = new Test("t3", 3);

        TestSubscriberEx<Test> subscriber = new TestSubscriberEx<>();
        Observable.just(t1, t3, t2)
                .distinct() // 只允许还没有发射过的数据项通过
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(2);
        List<Test> expected = Arrays.asList(t1, t3);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void first_001() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1,2,3,4};
        Observable.from(ints)
                .first() // 发射第一个数据
                .subscribe(subscriber);

        assertThat(subscriber.getOnNextEvents(), hasItem(1));
        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
    }

    @Test
    public void first_002() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.just(1, 2, 3, 4, 5)
                .first(x -> x%2==0) // 发射第一个满足条件的数据
                .subscribe(subscriber);

        assertThat(subscriber.getOnNextEvents(), hasItem(2));
        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
    }

    @Test
    public void first_003() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={};
        Observable.from(ints)
                .firstOrDefault(-1) // 如果没有数据发射，则会发射默认数据-1
                .subscribe(subscriber);

        assertThat(subscriber.getOnNextEvents(), hasItem(-1));
        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
    }

    @Test
    public void first_004() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.just(1, 2, 3, 4, 5)
                .firstOrDefault(-1, x -> x % 6 == 0) // 判定条件是否满足，如果没有满足条件的数据时就发射一个默认值
                .subscribe(subscriber);

        assertThat(subscriber.getOnNextEvents(), hasItem(-1));
        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
    }

    @Test
    public void first_005() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={};
        Observable.from(ints)
                .first() // 发射第一个数据
                .subscribe(subscriber);

        // 如果原始Observable没有发射任何满足条件的数据，first会抛出一个NoSuchElementException
        subscriber.assertError(NoSuchElementException.class);
    }

    @Test
    public void takeFirst_001() {
        /*
        takeFirst与first类似，除了这一点：如果原始Observable没有发射任何满足条件的数据，
        first会抛出一个NoSuchElementException，takeFist会返回一个空的Observable（不调用onNext()但是会调用onCompleted）
         */
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={};
        Observable.from(ints)
                .takeFirst(x -> x%2==0) // 发射第一个满足条件的数据
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(0);

    }

    @Test
    public void takeFirst_002() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1,2,3,4};
        Observable.from(ints)
                .takeFirst(x -> x%2==0) // 发射第一个满足条件的数据
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
        List<Integer> expected = new ArrayList<>();
        expected.add(2);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void single_001() {
        /*
        single操作符也与first类似
         */
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1};
        Observable.from(ints)
                .single()
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
        List<Integer> expected = new ArrayList<>();
        expected.add(1);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void single_002() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1, 2};
        Observable.from(ints)
                .single() // if the source emits more than one item
                .subscribe(subscriber);

        subscriber.assertError(IllegalArgumentException.class);
    }

    @Test
    public void single_003() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={};
        Observable.from(ints)
                .single() // if the source emits no items
                .subscribe(subscriber);

        subscriber.assertError(NoSuchElementException.class);
    }

    @Test
    public void single_004() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1, 2};
        Observable.from(ints)
                .single(x -> x%2==0)
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
        List<Integer> expected = new ArrayList<>();
        expected.add(2);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void single_005() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1, 3};
        Observable.from(ints)
                .singleOrDefault(0, x -> x%2==0)
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
        List<Integer> expected = new ArrayList<>();
        expected.add(0);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void last_001() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1,2,3,4};
        Observable.from(ints)
                .last() // 发射最后一项数据
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
        List<Integer> expected = new ArrayList<>();
        expected.add(4);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void last_002() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1,2,3,4};
        Observable.from(ints)
                .last(x -> x%2==0) // 发射原始Observable中满足条件的最后一项数据
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
        List<Integer> expected = new ArrayList<>();
        expected.add(4);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void last_003() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Integer[] ints={1,2,3,4};
        Observable.from(ints)
                .lastOrDefault(0, x -> x%5==0) // 如果有数据满足条件，返回的Observable就发射原始Observable满足条件的最后一项数据，否则发射默认值
                .subscribe(subscriber);

        subscriber.assertCompleted();
        subscriber.assertNoErrors();
        subscriber.assertValueCount(1);
        List<Integer> expected = new ArrayList<>();
        expected.add(0);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void sample_001() {
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(10, TimeUnit.MILLISECONDS)
                .take(10)
                // sample定期扫描源Observable产生的结果，在指定的间隔周期内进行采样，然后发射自上次采样以来它最后发射的数据。
                .sample(20, TimeUnit.MILLISECONDS)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(6);
        List<Long> expected = Arrays.asList(Long.valueOf(0), Long.valueOf(2),
                                            Long.valueOf(4), Long.valueOf(6),
                                            Long.valueOf(8), Long.valueOf(9));
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void sample_002() {
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(10, TimeUnit.MILLISECONDS)
                .take(10)
                // sample每当参数Observable发射一个数据（或者当它终止）时就对原始Observable进行采样，然后发射自上次采样以来它最后发射的数据。
                .sample(Observable.interval(20, TimeUnit.MILLISECONDS))
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(6);
        List<Long> expected = Arrays.asList(Long.valueOf(0), Long.valueOf(2),
                                            Long.valueOf(4), Long.valueOf(6),
                                            Long.valueOf(8), Long.valueOf(9));
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void throttleLast_001() {
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(10, TimeUnit.MILLISECONDS)
                .take(10)
                // throttleLast定期扫描源Observable产生的结果，在指定的间隔周期内进行采样，然后发射自上次采样以来它最后发射的数据。
                .throttleLast(20, TimeUnit.MILLISECONDS)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(6);
        List<Long> expected = Arrays.asList(Long.valueOf(0), Long.valueOf(2),
                                            Long.valueOf(4), Long.valueOf(6),
                                            Long.valueOf(8), Long.valueOf(9));
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void throttleFirst_001() {
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(10, TimeUnit.MILLISECONDS)
                .take(10)
                // throttleLast定期扫描源Observable产生的结果，在指定的间隔周期内进行采样，然后发射自上次采样以来它最先发射的数据。
                .throttleFirst(20, TimeUnit.MILLISECONDS)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(5);
        List<Long> expected = Arrays.asList(Long.valueOf(0),
                                            Long.valueOf(3), Long.valueOf(5),
                                            Long.valueOf(7), Long.valueOf(9));
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void skip_001() {
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(10, TimeUnit.MILLISECONDS)
                .take(10)
                .skip(2) // skip忽略源Observable发射的前N项数据，只保留之后的数据
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(8);
        assertThat(subscriber.getOnNextEvents(), hasItem(2L));
    }

    @Test
    public void skip_002() {
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(10, TimeUnit.MILLISECONDS)
                .take(10)
                .skip(23, TimeUnit.MILLISECONDS) // skip丢弃原始Observable开始的那段时间发射的数据，时长和时间单位通过参数指定
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(8);
        assertThat(subscriber.getOnNextEvents(), hasItem(2L));
    }

    @Test
    public void skipLast_001() {
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(10, TimeUnit.MILLISECONDS)
                .take(10)
                .skipLast(2) // skipLast忽略源Observable发射的后N项数据，只保留之前的数据
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(8);
        assertThat(subscriber.getOnNextEvents(), hasItem(7L));
    }

    @Test
    public void skipLast_002() {
        /*
        skipLast丢弃在原始Observable的生命周期内最后一段时间内发射的数据。时长和时间单位通过参数指定
        这个机制是这样实现的：延迟原始Observable发射的任何数据项，直到自这次发射之后过了给定的时长。
         */
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(10, TimeUnit.MILLISECONDS)
                .take(10)
                .skipLast(23, TimeUnit.MILLISECONDS)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        subscriber.assertValueCount(7);
        assertThat(subscriber.getOnNextEvents(), hasItem(6L));
    }

    @Test
    public void take_001() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.just(1, 2, 3, 4)
                .take(2)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        List<Integer> expected = Arrays.asList(1,2);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void take_002() {
        TestSubscriberEx<Long> subscriber = new TestSubscriberEx<>();
        Observable.interval(10, TimeUnit.MILLISECONDS)
                .take(23, TimeUnit.MILLISECONDS)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        List<Long> expected = Arrays.asList(0L,1L);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void takeLast_001() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.just(1, 2, 3, 4)
                .takeLast(2)
                .subscribe(subscriber);

        subscriber.assertCompleted();
        List<Integer> expected = Arrays.asList(3,4);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void takeLast_002() {
        TestSubscriberEx<Integer> subscriber = new TestSubscriberEx<>();
        Observable.just(1, 2, 3, 4)
                .flatMap(x -> Observable.just(x).delay(x*10, TimeUnit.MILLISECONDS))
                .takeLast(13, TimeUnit.MILLISECONDS)
                .subscribe(subscriber);

        subscriber.awaitTerminalEvent();
        subscriber.assertCompleted();
        List<Integer> expected = Arrays.asList(3,4);
        assertThat(subscriber.getOnNextEvents(), equalTo(expected));
    }

    @Test
    public void takeLastBuffer_001() {
        TestSubscriberEx<List<Integer>> subscriber = new TestSubscriberEx<>();
        Observable.just(1, 2, 3, 4)
                .takeLastBuffer(2)
                .subscribe(subscriber);

        subscriber.assertCompleted();
    }

}
